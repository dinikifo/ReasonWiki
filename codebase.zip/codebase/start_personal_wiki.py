#!/usr/bin/env python3
"""Launch PERSONAL.WIKI with a local editable starter collection.

No historical research database is shipped or modified by this demo edition.
The first launch atomically creates MY_WIKI_DATA/personal_wiki.db from the
portable demonstration JSON. Existing databases are never regenerated.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import sqlite3
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parent
APP = ROOT / 'app'
sys.path.insert(0, str(APP))
DEMO = ROOT / 'demo' / 'STARTER_TIDDLERS.json'
WORKSPACE = ROOT / 'MY_WIKI_DATA'
WORKING = WORKSPACE / 'personal_wiki.db'
HOME = 'Welcome to PERSONAL.WIKI'

class SetupError(RuntimeError):
    pass


def check_environment() -> None:
    from wiki_core import WikiCore
    WikiCore.check_storage_environment()
    if not DEMO.is_file() or DEMO.is_symlink():
        raise SetupError('Missing bundled demo/STARTER_TIDDLERS.json')


def validate_existing(path: Path) -> dict:
    from wiki_core import WikiCore
    if path.is_symlink() or not path.is_file():
        raise SetupError(f'Working database is not a regular file: {path}')
    if not WikiCore.has_history(path):
        raise SetupError('Working database has no companion history file; restore the matching pair')
    with WikiCore(str(path), readonly=True) as db:
        report = db.integrity_report()
        if report['integrity'] != 'ok' or report['foreign_key_violations'] or not report['fts_matches']:
            raise SetupError('Working database failed SQLite / full-text integrity verification')
        protection = db.protection_report()
        if protection['violation_count']:
            raise SetupError('Working database failed protected record verification')
        return {'path':str(path), 'records':report['records'], 'schema':2}


def prepare() -> dict:
    from wiki_core import WikiCore
    check_environment()
    if WORKSPACE.is_symlink() or (WORKSPACE.exists() and not WORKSPACE.is_dir()):
        raise SetupError('MY_WIKI_DATA must be a regular directory, not a symlink')
    if WORKING.exists() or WORKING.is_symlink():
        return validate_existing(WORKING)
    if not WORKSPACE.exists():
        WORKSPACE.mkdir(mode=0o700)
    # Seed in a hidden staging directory on the same filesystem. Only publish
    # after the JSON import, integrity verification and SQLite close succeed.
    with TemporaryDirectory(prefix='.pw_demo_seed_',dir=WORKSPACE) as staging_dir:
        staging = Path(staging_dir)/'starter.db'
        WikiCore.create_database(staging)
        with WikiCore(staging) as db:
            count = db.import_json(str(DEMO), protect_imported=False)
            if count != 15:
                raise SetupError(f'Starter JSON should contain 15 entries; found {count}')
            if db.get_tiddler(HOME) is None:
                raise SetupError('Starter home page is missing')
            report = db.integrity_report()
            if report['integrity'] != 'ok' or report['foreign_key_violations'] or not report['fts_matches']:
                raise SetupError('Starter SQLite database did not pass integrity verification')
        # Stage BOTH complete databases before publishing either of them.
        # The filesystem cannot atomically link two files as one operation;
        # a crash between links leaves a detectable incomplete first launch,
        # never an invented or silently overwritten history.
        try:
            os.link(staging, WORKING)
        except FileExistsError:
            return validate_existing(WORKING)
        try:
            os.link(WikiCore.history_file(staging), WikiCore.history_file(WORKING))
        except BaseException:
            # Remove only the content file that this invocation created.
            # On next start, an incomplete publication must not be treated as
            # a healthy initialized notebook.
            if WORKING.exists() and os.stat(WORKING).st_ino == os.stat(staging).st_ino:
                WORKING.unlink()
            raise
        if os.name == 'posix':
            # create_new_database sets 0600; do not chmod a database
            # that was published by some other process.
            if WORKING.stat().st_mode & 0o077:
                raise SetupError('New working database has unsafe permissions')
        if hasattr(os, 'O_DIRECTORY'):
            dfd = os.open(WORKSPACE, os.O_RDONLY | os.O_DIRECTORY)
            try: os.fsync(dfd)
            finally: os.close(dfd)
    return validate_existing(WORKING)


def start_gui() -> None:
    info = prepare()
    try:
        from PySide6.QtWidgets import QApplication
    except ImportError as exc:
        raise SetupError('PySide6 is not installed. See README.md for setup.') from exc
    from main import TiddlyViewer, shutdown
    app = QApplication(sys.argv[:1])
    app.setApplicationName('PERSONAL.WIKI')
    window = TiddlyViewer()
    window._load_database(info['path'])
    if window.db is None:
        raise SetupError('Could not open the local database in the desktop viewer')
    if window.db.get_tiddler(HOME):
        window._show_tiddler(HOME)
    window.setWindowTitle('PERSONAL.WIKI — My Notebook')
    window.show()
    print('PERSONAL.WIKI database:',info['path'],flush=True)
    code = app.exec()
    shutdown(app, window)
    del window
    raise SystemExit(code)


def main(argv=None) -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group()
    group.add_argument('--check',action='store_true',help='Check Python/SQLite and bundled demo; create no database')
    group.add_argument('--prepare',action='store_true',help='Initialize or verify personal SQLite database without Qt')
    args=parser.parse_args(argv)
    try:
        if args.check:
            check_environment()
            print('PASS: Python and SQLite FTS5/JSON available; starter JSON present')
        elif args.prepare:
            print('Ready:',prepare())
        else:
            start_gui()
        return 0
    except (OSError,sqlite3.DatabaseError,ValueError,RuntimeError,PermissionError) as exc:
        print('PERSONAL.WIKI startup refused:',exc,file=sys.stderr)
        return 2

if __name__=='__main__':
    raise SystemExit(main())
