"""Two-way PVS workflow: refresh, reconcile, ownership, reasoning (needs PVS_SRC)."""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys
import tempfile
import unittest

from helpers import PVS_SRC
from wiki_core import WikiCore, SchemaError

V, H, P = 'versioner', 'dimitris', 'alpha'
PROJ, G1, G2, M1 = f'PVS/{V}/{P}', f'PVS/{V}/{P}/g1', f'PVS/{V}/{P}/g2', f'PVS/{V}/{P}/g1/m1'


@unittest.skipUnless(PVS_SRC, 'set PVS_SRC to the PVS-01 src folder')
class SyncCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        if PVS_SRC not in sys.path:
            sys.path.insert(0, PVS_SRC)
        from fd_oop_reconstruction.pvs import PVSWorkspace, argument
        self.argument = argument
        self.root = Path(self.tmp.name) / 'pvs'
        self.ws = PVSWorkspace(self.root)
        self.ws.create_target('target', {'language': 'python', 'entry': 'x.py'})
        self.ws.create_versioner(V, H)
        self.ws.add_project(V, H, P, 'target', 'Test')
        self.ws.add_goal(V, H, P, 'acceptance', 'g1', 'First goal', 'goal')
        self.ws.add_goal(V, H, P, 'acceptance', 'g2', 'Second goal', 'goal')
        self.ws.add_milestone(V, H, P, 'g1', 'm1', 'Milestone')
        self.ws.decide(V, H, P, 'ACCEPTED', 'go')
        self.path = os.path.join(self.tmp.name, 'w.db')
        WikiCore.create_database(self.path)
        self.w = WikiCore(self.path)
        self.first = self.w.refresh_from_pvs(self.root, pvs_src=PVS_SRC)

    def tearDown(self):
        self.w.close()
        self.tmp.cleanup()

    def edit(self, title, *, text=None, **fields):
        post = self.w.get_tiddler(title)
        self.w.update_tiddler(title, title, post['text'] if text is None else text, post['tags'],
                              reason='test edit', fields=dict(post['fields'], **fields))

    def refresh(self):
        return self.w.refresh_from_pvs(pvs_src=PVS_SRC)


class FirstRefresh(SyncCase):
    def test_creates_managed_posts_and_config(self):
        self.assertIn(G1, self.first['new'])
        post = self.w.get_tiddler(G1)
        self.assertIn('pvs', post['tags'])
        self.assertEqual((post['fields']['status'], post['fields']['parent']), ('planned', PROJ))
        self.assertEqual(json.loads(post['fields']['pvs_base']), {'status': 'planned'})
        self.assertEqual(post['text'], post['fields']['pvs_view'])  # seeded from PVS
        self.assertEqual(self.w.pvs_state()['root'], str(self.root.resolve()))
        self.assertEqual(len(self.first['workspace_id']), 64)
        self.assertIn('Change log', self.first['log'])
        self.assertTrue(self.w.verify_history()['verified'])

    def test_unchanged_refresh_writes_only_bookkeeping(self):
        before = len(self.w.events_since(0))
        report = self.refresh()
        self.assertEqual([report[k] for k in ('new', 'from_pvs', 'content', 'to_enter', 'conflicts', 'missing')],
                         [[], [], [], [], [], []])
        written = self.w.events_since(0)[before:]
        self.assertEqual(sorted({e['title'] for e in written}),
                         sorted({'$:/config/pvs', report['log']}))

    def test_other_workspace_refused(self):
        from fd_oop_reconstruction.pvs import PVSWorkspace
        other = Path(self.tmp.name) / 'other'
        ws = PVSWorkspace(other)
        ws.create_versioner(V, H)
        with self.assertRaisesRegex(Exception, 'different workspace'):
            self.w.refresh_from_pvs(other, pvs_src=PVS_SRC)

    def test_moved_workspace_is_recognised(self):
        import shutil
        moved = Path(self.tmp.name) / 'moved' / 'pvs'
        shutil.copytree(self.root, moved)
        shutil.rmtree(self.root)
        import pvs_sync
        with self.assertRaises(pvs_sync.WorkspaceMissing):
            self.refresh()
        self.w.refresh_from_pvs(moved, pvs_src=PVS_SRC)
        self.assertEqual(self.w.pvs_state()['root'], str(moved.resolve()))
        self.refresh()  # the new location is remembered

    def test_refresh_from_snapshot_file(self):
        import subprocess
        out = Path(self.tmp.name) / 'snap.json'
        exporter = Path(__file__).resolve().parents[1] / 'tools' / 'pvs_export.py'
        self.ws.set_goal_status(V, H, P, 'g1', 'COMPLETE', 'done')
        subprocess.run([sys.executable, str(exporter), str(self.root), '--pvs-src', PVS_SRC, '-o', str(out)],
                       check=True)
        report = self.w.refresh_from_pvs(snapshot_file=out)
        self.assertEqual(report['from_pvs'], [{'title': G1, 'from': 'planned', 'to': 'done'}])
        bad = Path(self.tmp.name) / 'bad.json'
        bad.write_text('{"format": "something-else"}')
        with self.assertRaisesRegex(Exception, 'Not a PVS snapshot'):
            self.w.refresh_from_pvs(snapshot_file=bad)

    def test_wiki_process_never_loads_pvs(self):
        import subprocess
        app = Path(__file__).resolve().parents[1] / 'app'
        self.w.close()
        code = ('import sys; sys.path.insert(0, %r)\n'
                'from wiki_core import WikiCore\n'
                'w = WikiCore(%r); w.refresh_from_pvs(pvs_src=%r); w.close()\n'
                'print(any(m.startswith("fd_oop_reconstruction") for m in sys.modules))') % (
                    str(app), self.path, PVS_SRC)
        done = subprocess.run([sys.executable, '-c', code], capture_output=True, text=True,
                              env={k: v for k, v in os.environ.items() if k != 'PVS_SRC'})
        self.w = WikiCore(self.path)
        self.assertEqual(done.stdout.strip(), 'False', done.stderr)


class StatusReconcile(SyncCase):
    def test_pvs_changed_wiki_unchanged_takes_pvs(self):
        self.ws.set_goal_status(V, H, P, 'g1', 'COMPLETE', 'done in PVS')
        report = self.refresh()
        self.assertEqual(report['from_pvs'], [{'title': G1, 'from': 'planned', 'to': 'done'}])
        self.assertEqual(self.w.get_tiddler(G1)['fields']['status'], 'done')
        self.assertEqual(self.w.pvs_state()['to_enter'], [])

    def test_wiki_changed_pvs_unchanged_is_to_enter(self):
        self.edit(G1, status='active')
        state = self.w.pvs_state()
        self.assertEqual([(t['title'], t['operation']) for t in state['to_enter']],
                         [(G1, 'set_goal_status ACTIVE')])
        report = self.refresh()
        self.assertEqual(self.w.get_tiddler(G1)['fields']['status'], 'active')  # kept
        self.assertEqual([t['title'] for t in report['to_enter']], [G1])

    def test_both_changed_to_same_value_is_in_sync(self):
        self.edit(G1, status='active')
        self.ws.set_goal_status(V, H, P, 'g1', 'ACTIVE', 'entered from the wiki')
        report = self.refresh()
        self.assertEqual(report['in_sync'], [G1])
        self.assertEqual(self.w.pvs_state()['to_enter'], [])

    def test_conflict_keeps_both_until_resolved(self):
        self.edit(G1, status='blocked')
        self.ws.set_goal_status(V, H, P, 'g1', 'COMPLETE', 'done')
        report = self.refresh()
        self.assertEqual(report['conflicts'], [{'title': G1, 'wiki': 'blocked', 'pvs': 'done'}])
        self.assertEqual(self.w.get_tiddler(G1)['fields']['status'], 'blocked')  # nothing overwritten
        self.assertEqual(len(self.w.pvs_state()['conflicts']), 1)
        self.refresh()  # still a conflict on the next refresh
        self.assertEqual(len(self.w.pvs_state()['conflicts']), 1)

    def test_resolve_take_pvs(self):
        self.edit(G1, status='blocked')
        self.ws.set_goal_status(V, H, P, 'g1', 'COMPLETE', 'done')
        self.refresh()
        self.w.resolve_pvs_conflict(G1, 'pvs', reason='PVS is right')
        state = self.w.pvs_state()
        self.assertEqual((state['conflicts'], state['to_enter']), ([], []))
        self.assertEqual(self.w.get_tiddler(G1)['fields']['status'], 'done')

    def test_resolve_keep_wiki_becomes_to_enter(self):
        self.edit(G1, status='blocked')
        self.ws.set_goal_status(V, H, P, 'g1', 'COMPLETE', 'done')
        self.refresh()
        self.w.resolve_pvs_conflict(G1, 'wiki', reason='I know better')
        state = self.w.pvs_state()
        self.assertEqual(state['conflicts'], [])
        self.assertEqual([(t['title'], t['operation']) for t in state['to_enter']], [(G1, 'set_goal_status BLOCKED')])
        with self.assertRaises(ValueError):
            self.w.resolve_pvs_conflict(G1, 'pvs', reason='again')


class Ownership(SyncCase):
    def test_text_tags_status_are_yours(self):
        post = self.w.get_tiddler(G1)
        self.w.update_tiddler(G1, G1, '! My notes', post['tags'] + ['mine'], reason='format',
                              fields=dict(post['fields'], status='active', note='mine'))
        self.ws.set_goal_status(V, H, P, 'g2', 'COMPLETE', 'x')
        self.ws.add_goal_argument(V, H, P, 'g1', 'for', self.argument('c', 'g', 'w'), 'changes g1 view')
        report = self.refresh()
        post = self.w.get_tiddler(G1)
        self.assertIn(G1, report['content'])
        self.assertEqual(post['text'], '! My notes')
        self.assertIn('mine', post['tags'])
        self.assertEqual(post['fields']['note'], 'mine')
        self.assertIn('PVS content changed since', self.w.render(G1))

    def test_pvs_owned_parts_refused(self):
        post = self.w.get_tiddler(G1)
        for bad in (dict(post['fields'], pvs_goal='zzz'), dict(post['fields'], parent='Elsewhere'),
                    {k: v for k, v in post['fields'].items() if k != 'pvs_view'}):
            with self.assertRaisesRegex(PermissionError, 'belong'):
                self.w.update_tiddler(G1, G1, '', post['tags'], reason='x', fields=bad)
        with self.assertRaisesRegex(PermissionError, 'title'):
            self.w.update_tiddler(G1, 'Renamed', '', post['tags'], reason='x')
        with self.assertRaisesRegex(PermissionError, 'tag'):
            self.w.update_tiddler(G1, G1, '', ['goal'], reason='x')
        with self.assertRaisesRegex(PermissionError, 'Remove it in PVS'):
            self.w.delete_tiddler(G1, reason='x')
        with self.assertRaisesRegex(PermissionError, 'Only Refresh'):
            self.w.save_tiddler('Fake', '', ['pvs'])
        self.w.save_tiddler('Plain', '', [])
        with self.assertRaisesRegex(PermissionError, 'Only Refresh'):
            self.w.update_tiddler('Plain', 'Plain', '', ['pvs'], reason='x')

    def test_restore_of_old_version_cannot_rewrite_pvs_fields(self):
        self.ws.set_goal_status(V, H, P, 'g1', 'COMPLETE', 'done')
        self.refresh()
        pid = [p for p in self.w.history_posts() if p['last_title'] == G1][0]['post_id']
        with self.assertRaises(PermissionError):
            self.w.restore_version(pid, self.w.post_history(pid)[0]['event_id'], reason='back')

    def test_missing_then_back_and_deletable_while_missing(self):
        import pvs_bridge
        original = pvs_bridge.records_from_snapshot

        def without_g2(*a, **k):
            records, summary = original(*a, **k)
            return [r for r in records if r['title'] != G2], summary
        pvs_bridge.records_from_snapshot = without_g2
        try:
            report = self.refresh()
        finally:
            pvs_bridge.records_from_snapshot = original
        self.assertEqual(report['missing'], [G2])
        self.assertEqual(self.w.pvs_state()['missing'], [G2])
        report = self.refresh()
        self.assertEqual((report['returned'], self.w.pvs_state()['missing']), ([G2], []))
        pvs_bridge.records_from_snapshot = without_g2
        try:
            self.refresh()
        finally:
            pvs_bridge.records_from_snapshot = original
        self.assertTrue(self.w.delete_tiddler(G2, reason='gone from PVS'))

    def test_contracts_still_apply_to_your_status(self):
        with self.assertRaises(SchemaError):
            self.edit(G1, status='finished')


class Reasoning(SyncCase):
    def argue(self, title, target, side, claim='Keep it small', warrant='Small code is easier to verify'):
        self.w.save_tiddler(title, '', ['note'], fields=dict(pvs_target=target, pvs_side=side, claim=claim,
                                                              grounds='g', warrant=warrant))

    def test_pending_until_entered_in_pvs(self):
        self.argue('A1', PROJ, 'acceptance')
        self.argue('A2', G1, 'against', claim='Too early')
        state = self.w.pvs_state()
        self.assertEqual(sorted((r['title'], r['operation']) for r in state['reasoning_pending']),
                         [('A1', 'add_rfc_argument acceptance'), ('A2', 'add_goal_argument against')])
        self.ws.add_rfc_argument(V, H, P, 'acceptance', self.argument('Keep it small', 'other grounds',
                                                                      'Small code is easier to verify'), 'from wiki')
        self.refresh()
        state = self.w.pvs_state()
        self.assertEqual([r['title'] for r in state['reasoning_entered']], ['A1'])
        self.assertEqual([r['title'] for r in state['reasoning_pending']], ['A2'])
        self.assertIn('Entered in PVS', self.w.render('A1'))
        self.assertIn('To enter in PVS', self.w.render('A2'))

    def test_bad_targets_reported(self):
        self.argue('B1', 'Nowhere', 'for')
        self.argue('B2', G1, 'acceptance')
        self.argue('B3', M1, 'for')
        problems = {r['title']: r['problem'] for r in self.w.pvs_state()['reasoning_problems']}
        self.assertEqual(set(problems), {'B1', 'B2', 'B3'})
        self.assertIn('for, against', problems['B2'])


class Atomicity(SyncCase):
    def test_failed_refresh_changes_nothing(self):
        self.ws.set_goal_status(V, H, P, 'g1', 'COMPLETE', 'done')
        schema = self.w.field_schemas()['goal']
        schema['properties']['status']['enum'] = ['planned', 'active', 'blocked', 'dropped']  # no 'done'
        self.w.save_field_schema('goal', schema, reason='test', acknowledge_contract_change=True)
        self.w.update_change_log()  # the refresh logs earlier edits first, in its own step
        before = len(self.w.events_since(0))
        with self.assertRaises(SchemaError):
            self.refresh()
        self.assertEqual(len(self.w.events_since(0)), before)
        self.assertEqual(self.w.get_tiddler(G1)['fields']['status'], 'planned')

    def test_every_refresh_has_one_chained_log_entry(self):
        self.ws.set_goal_status(V, H, P, 'g1', 'COMPLETE', 'done')
        self.edit(G2, status='active')
        second = self.refresh()
        log = self.w.verify_change_log()
        self.assertTrue(log['verified'], log['problems'])
        self.assertEqual(log['tip'], second['log'])
        text = self.w.get_tiddler(second['log'])['text']
        self.assertIn('Status taken from PVS (1)', text)
        self.assertIn('To enter in PVS (1)', text)


if __name__ == '__main__':
    unittest.main()
