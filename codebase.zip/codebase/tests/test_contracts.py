"""Field contracts enforced on every write path."""
from __future__ import annotations

import json
import os
import sqlite3
import unittest

from helpers import Notebook
import field_schema as fs
from wiki_core import ContractAcknowledgementRequired, SchemaError


class Contracts(Notebook):
    def test_kit_is_idempotent_and_versioned(self):
        created = self.w.install_project_kit()
        self.assertIn('$:/schema/task', created)
        self.assertEqual(self.w.install_project_kit(), [])
        self.assertEqual(self.reasons('$:/schema/task'), ['Install project kit'])

    def test_post_must_satisfy_contract(self):
        self.kit()
        self.w.save_tiddler('T', '', ['task'], fields={'status': 'active', 'due': '2026-12-01'})
        for bad in ({'status': 'wip'}, {}, {'status': 'done', 'due': 'tomorrow'},
                    {'status': 'done', 'priority': 'urgent'}):
            with self.assertRaises(SchemaError):
                self.w.save_tiddler('Bad', '', ['task'], fields=bad)
        self.assertIsNone(self.w.get_tiddler('Bad'))
        with self.assertRaises(SchemaError):
            self.w.update_tiddler('T', 'T', '', ['task'], reason='x', fields={'status': 'nope'})
        self.assertEqual(self.w.get_tiddler('T')['fields']['status'], 'active')
        self.w.verify_history()

    def test_untagged_posts_are_untyped(self):
        self.kit()
        self.w.save_tiddler('Note', 'free', ['journal'], fields={'status': 'whatever'})
        self.assertEqual(self.w.get_tiddler('Note')['fields']['status'], 'whatever')

    def test_tighten_free_loosen_needs_ack(self):
        self.kit()
        s = self.w.field_schemas()['task']
        s['required'] = ['status', 'parent']
        self.w.save_field_schema('task', s, reason='tasks need a parent')
        self.assertEqual(self.reasons('$:/schema/task')[-1], 'tasks need a parent')
        loose = json.loads(json.dumps(s)); loose['required'] = ['status']
        with self.assertRaises(ContractAcknowledgementRequired):
            self.w.save_field_schema('task', loose, reason='too strict')
        self.assertIn('parent', self.w.field_schemas()['task']['required'])
        self.w.save_field_schema('task', loose, reason='too strict', acknowledge_contract_change=True)
        self.assertTrue(self.reasons('$:/schema/task')[-1].endswith(fs.ACK_NOTE if hasattr(fs, 'ACK_NOTE') else
                                                                    '[contract change acknowledged by owner]'))

    def test_tightening_that_breaks_existing_posts_needs_ack(self):
        self.kit()
        self.w.save_tiddler('Loose task', '', ['task'], fields={'status': 'planned'})
        s = self.w.field_schemas()['task']; s['required'] = ['status', 'parent']
        with self.assertRaises(ContractAcknowledgementRequired) as ctx:
            self.w.save_field_schema('task', s, reason='stricter')
        self.assertEqual(ctx.exception.violations, ['Loose task'])
        self.w.save_field_schema('task', s, reason='stricter', acknowledge_contract_change=True)
        self.assertEqual([v['title'] for v in self.w.contract_violations()], ['Loose task'])
        # touching the violating post requires fixing it
        with self.assertRaises(SchemaError):
            self.w.update_tiddler('Loose task', 'Loose task', 'edit', ['task'], reason='edit')

    def test_deleting_or_renaming_contract_needs_ack(self):
        self.kit()
        with self.assertRaises(ContractAcknowledgementRequired):
            self.w.delete_tiddler('$:/schema/task', reason='no more types')
        with self.assertRaises(ContractAcknowledgementRequired):
            self.w.rename_tiddler('$:/schema/task', 'old task contract', reason='archive')
        self.assertIn('task', self.w.field_schemas())
        self.w.delete_tiddler('$:/schema/task', reason='no more types', acknowledge_contract_change=True)
        self.assertNotIn('task', self.w.field_schemas())
        self.w.verify_history()

    def test_malformed_contract_refused(self):
        with self.assertRaises(SchemaError):
            self.w.save_tiddler('$:/schema/x', '{not json', [])
        with self.assertRaises(SchemaError):
            self.w.save_tiddler('$:/schema/x', '{"type":"string"}', [])
        with self.assertRaises(SchemaError):
            self.w.save_tiddler('$:/schema/x', '{"type":"object","pattern":"a"}', [])

    def test_import_checks_contracts_atomically(self):
        self.kit()
        src = os.path.join(self.tmp.name, 'in.json')
        with open(src, 'w') as f:
            json.dump([{'title': 'ok', 'tags': 'task', 'status': 'done'},
                       {'title': 'bad', 'tags': 'task', 'status': 'later'}], f)
        before = self.w.count()
        with self.assertRaises(SchemaError):
            self.w.import_json(src)
        self.assertEqual(self.w.count(), before)
        # a batch may carry its own contract, in any order
        with open(src, 'w') as f:
            json.dump([{'title': 'n1', 'tags': 'note', 'kind': 'a'},
                       {'title': '$:/schema/note', 'text': json.dumps(
                           {'type': 'object', 'properties': {'kind': {'type': 'string', 'enum': ['a']}}})}], f)
        self.assertEqual(self.w.import_json(src), 2)
        self.w.verify_history()

    def test_update_fields_replace_and_can_remove(self):
        self.w.save_tiddler('P', 'x', [], fields={'a': '1', 'b': '2'})
        self.w.update_tiddler('P', 'P', 'x', [], reason='drop b', fields={'a': '1'})
        self.assertEqual(self.w.get_tiddler('P')['fields'], {'a': '1'})
        self.w.update_tiddler('P', 'P', 'y', [], reason='keep fields')
        self.assertEqual(self.w.get_tiddler('P')['fields'], {'a': '1'})
        with self.assertRaises(ValueError):
            self.w.update_tiddler('P', 'P', 'y', [], reason='bad', fields={'title': 'zz'})

    def test_broken_contract_post_blocks_tagged_writes(self):
        self.kit()
        con = sqlite3.connect(self.path)
        raw = json.loads(con.execute("select raw_json from tiddlers where title='$:/schema/task'").fetchone()[0])
        raw['text'] = '{broken'
        con.execute("update tiddlers set raw_json=?, text=? where title='$:/schema/task'",
                    (json.dumps(raw), raw['text']))
        con.commit(); con.close()
        with self.assertRaises(SchemaError):
            self.w.save_tiddler('t', '', ['task'], fields={'status': 'done'})


if __name__ == '__main__':
    unittest.main()
