"""Restoring recorded versions."""
from __future__ import annotations

import json
import os
import unittest

from helpers import Notebook
from wiki_core import SchemaError


class Restore(Notebook):
    def test_restore_active_post_appends_version(self):
        self.w.save_tiddler('A', 'one', ['x'], fields={'k': 'v1'})
        self.w.update_tiddler('A', 'A renamed', 'two', ['y'], reason='change', fields={'k': 'v2'})
        pid = self.post_id('A renamed')
        first = self.w.post_history(pid)[0]['event_id']
        result = self.w.restore_version(pid, first, reason='undo')
        self.assertEqual(result, {'title': 'A', 'mode': 'edit', 'source_event': first})
        post = self.w.get_tiddler('A')
        self.assertEqual((post['text'], post['tags'], post['fields']), ('one', ['x'], {'k': 'v1'}))
        self.assertIsNone(self.w.get_tiddler('A renamed'))
        types = [e['change_type'] for e in self.w.post_history(pid)]
        self.assertEqual(types, ['first_version', 'rename', 'rename'])
        self.assertIn('restored from event', self.w.post_history(pid)[-1]['reason'])
        with self.assertRaises(ValueError):
            self.w.restore_version(pid, first, reason='again')
        self.w.verify_history()

    def test_restore_deleted_post_creates_new_post(self):
        self.w.save_tiddler('D', 'keep me', [])
        pid = self.post_id('D')
        self.w.delete_tiddler('D', reason='oops')
        delete_event = self.w.post_history(pid)[-1]['event_id']
        result = self.w.restore_version(pid, delete_event, reason='bring back')
        self.assertEqual(result['mode'], 'new_post')
        self.assertEqual(self.w.get_tiddler('D')['text'], 'keep me')
        self.assertEqual(len([p for p in self.w.history_posts() if p['last_title'] == 'D']), 2)
        with self.assertRaises(ValueError):
            self.w.restore_version(pid, delete_event, reason='twice')  # title now taken
        self.w.verify_history()

    def test_restore_respects_current_contract_and_protection(self):
        self.kit()
        self.w.save_tiddler('T', '', ['task'], fields={'status': 'planned'})
        pid = self.post_id('T')
        s = self.w.field_schemas()['task']; s['required'] = ['status', 'parent']
        self.w.update_tiddler('T', 'T', '', ['task'], reason='parent', fields={'status': 'planned', 'parent': 'P'})
        self.w.save_field_schema('task', s, reason='stricter')
        with self.assertRaises(SchemaError):
            self.w.restore_version(pid, self.w.post_history(pid)[0]['event_id'], reason='old one')
        other = self.w.post_history(self.post_id('$:/schema/task'))[0]['event_id']
        with self.assertRaises(ValueError):
            self.w.restore_version(pid, other, reason='wrong post')
        src = os.path.join(self.tmp.name, 'p.json')
        with open(src, 'w') as f:
            json.dump([{'title': 'Evidence', 'text': 'v1'}], f)
        self.w.import_json(src, protect_imported=True)
        epid = self.post_id('Evidence')
        with self.assertRaises(PermissionError):
            self.w.restore_version(epid, self.w.post_history(epid)[0]['event_id'], reason='no')


if __name__ == '__main__':
    unittest.main()
