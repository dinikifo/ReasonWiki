"""PVS-01 snapshot notebooks (needs PVS_SRC)."""
from __future__ import annotations

import os
import sys
import tempfile
import unittest
from pathlib import Path

from helpers import PVS_SRC
from wiki_core import WikiCore


@unittest.skipUnless(PVS_SRC, 'set PVS_SRC to the PVS-01 src folder')
class PVSSnapshot(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        sys.path.insert(0, PVS_SRC)
        from fd_oop_reconstruction.pvs import PVSWorkspace, argument
        root = Path(self.tmp.name) / 'pvs'
        ws = PVSWorkspace(root)
        ws.create_target('target', {'language': 'python', 'entry': 'hello.py'})
        ws.create_versioner('versioner', 'human')
        ws.add_project('versioner', 'human', 'alpha', 'target', 'Test')
        ws.add_rfc_argument('versioner', 'human', 'alpha', 'acceptance',
                            argument('Track code', 'Breakage', 'Snapshots help'), 'why')
        ws.add_goal('versioner', 'human', 'alpha', 'acceptance', 'g1', 'Restore code', 'goal')
        ws.add_goal('versioner', 'human', 'alpha', 'rejection', 'r1', 'Measure cost', 'evidence')
        ws.add_milestone('versioner', 'human', 'alpha', 'g1', 'm1', 'Captured')
        ws.set_dependencies('versioner', 'human', 'alpha', 'g1', ['r1'], 'deps')
        ws.decide('versioner', 'human', 'alpha', 'ACCEPTED', 'go')
        self.root = root

    def tearDown(self):
        self.tmp.cleanup()

    def test_snapshot_notebook(self):
        nb = os.path.join(self.tmp.name, 'snap.db')
        summary = WikiCore.create_pvs_notebook(nb, self.root, pvs_src=PVS_SRC)
        self.assertEqual((summary['projects'], summary['violations'], summary['verified']), (1, 0, True))
        with WikiCore(nb, readonly=True) as w:
            ov = w.project_overview()
            self.assertEqual([p['title'] for p in ov['projects']], ['PVS/versioner/alpha'])
            self.assertEqual(ov['projects'][0]['total'], 2)  # g1 + m1; r1 is rejection evidence
            r1 = w.get_tiddler('PVS/versioner/alpha/r1')
            self.assertEqual((r1['tags'], r1['fields']['pvs_branch']), (['pvs', 'pvs-evidence'], 'rejection'))
            self.assertNotIn('PVS/versioner/alpha/r1', ov['items'])
            m = w.get_tiddler('PVS/versioner/alpha/g1/m1')
            self.assertEqual((m['fields']['parent'], m['fields']['pvs_status']), ('PVS/versioner/alpha/g1', 'PENDING'))
            self.assertTrue(w.is_protected('PVS/versioner/alpha'))
            self.assertIn('[[PVS/versioner/alpha/r1]]', w.get_tiddler('PVS/versioner/alpha')['text'])
        with WikiCore(nb) as w:
            with self.assertRaises(PermissionError):
                w.update_tiddler('PVS/versioner/alpha', 'PVS/versioner/alpha', 'x', ['project'], reason='no')

    def test_refuses_non_workspace_without_touching_it(self):
        empty = Path(self.tmp.name) / 'empty'; empty.mkdir()
        with self.assertRaises(Exception):
            WikiCore.create_pvs_notebook(os.path.join(self.tmp.name, 'x.db'), empty,
                                         pvs_src=PVS_SRC)
        self.assertEqual(list(empty.iterdir()), [])
        self.assertFalse(os.path.exists(os.path.join(self.tmp.name, 'x.db')))


if __name__ == '__main__':
    unittest.main()
