"""Change log: daily entries, the digest chain, and what verification catches."""
from __future__ import annotations

import sqlite3
import unittest

from helpers import Notebook
from wiki_core import WikiCore
import changelog


class ChangeLog(Notebook):
    def backdate(self, event_id, day):
        con = sqlite3.connect(self.path.replace('.db', '.history.sqlite'))
        con.execute('UPDATE events SET changed_at=? WHERE event_id=?', (f'{day}T10:00:00+00:00', event_id))
        con.commit()
        con.close()

    def three_days(self):
        self.w.save_tiddler('A', '1', [])
        self.w.save_tiddler('B', '1', [])
        self.w.close()
        self.backdate(1, '2026-11-07')
        self.backdate(2, '2026-11-08')
        self.w = WikiCore(self.path)
        self.w.update_tiddler('A', 'A', '2', [], reason='today')
        return self.w.update_change_log()

    def test_one_entry_per_day_chained_and_protected(self):
        written = self.three_days()
        today = self.w.events_since(2)[0]['changed_at'][:10]
        self.assertEqual(written, ['Change log 0001 — 2026-11-07 — edits', 'Change log 0002 — 2026-11-08 — edits',
                                   f'Change log 0003 — {today} — edits'])
        chain = changelog.entries(self.w)
        self.assertEqual([e['seq'] for e in chain], [1, 2, 3])
        self.assertEqual(chain[1]['record']['log_prev'], chain[0]['title'])
        self.assertTrue(self.w.is_protected(chain[0]['title']))
        self.assertTrue(self.w.is_protected(chain[1]['title']))
        self.assertFalse(self.w.is_protected(chain[2]['title']))  # the tip can still grow
        self.assertTrue(self.w.verify_change_log()['verified'])
        self.assertIn('[[A]]', self.w.get_tiddler(chain[0]['title'])['text'])

    def test_nothing_new_and_tip_grows(self):
        self.three_days()
        self.assertEqual(self.w.update_change_log(), [])
        self.w.update_tiddler('B', 'B', '2', [], reason='later today')
        tip = changelog.entries(self.w)[-1]['title']
        self.assertEqual(self.w.update_change_log(), [tip])
        self.assertIn('later today', self.w.get_tiddler(tip)['text'])
        self.assertEqual(len(changelog.entries(self.w)), 3)
        self.assertTrue(self.w.verify_change_log()['verified'])

    def test_log_edits_are_not_logged(self):
        self.three_days()
        self.w.update_tiddler('A', 'A', '3', [], reason='x')
        self.w.update_change_log()
        self.assertEqual(self.w.update_change_log(), [])

    def test_altered_earlier_entry_refuses_open(self):
        self.three_days()
        first = changelog.entries(self.w)[0]['title']
        self.w.close()
        con = sqlite3.connect(self.path)
        con.execute("UPDATE tiddlers SET raw_json=replace(raw_json,'First','FIRST'), "
                    "text=replace(text,'First','FIRST') WHERE title=?", (first,))
        con.commit()
        con.close()
        with self.assertRaisesRegex(Exception, 'source hash mismatch'):
            WikiCore(self.path)
        self.w = None

    def test_broken_link_on_tip_is_reported(self):
        self.three_days()
        tip = changelog.entries(self.w)[-1]['title']
        self.w.close()
        con = sqlite3.connect(self.path)
        con.execute("UPDATE tiddlers SET raw_json=json_set(raw_json,'$.log_prev_sha256','00') WHERE title=?", (tip,))
        con.commit()
        con.close()
        with WikiCore(self.path, readonly=True) as w:
            result = w.verify_change_log()
        self.assertFalse(result['verified'])
        self.assertIn('changed after it was linked', result['problems'][0])
        self.w = None


if __name__ == '__main__':
    unittest.main()
