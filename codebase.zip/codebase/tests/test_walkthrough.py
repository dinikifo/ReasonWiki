"""The user manual's walkthrough (chapter 12.2), checked through the API."""
from __future__ import annotations

import json
import tempfile
import unittest
from datetime import date
from pathlib import Path

from helpers import PVS_SRC, generate_test_data
from wiki_core import WikiCore, ContractAcknowledgementRequired, SchemaError


class Walkthrough(unittest.TestCase):
    """The user manual's chapter 11.2, checked through the API."""
    TODAY = date(2026, 11, 9)

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.tmp.name) / 'TEST_DATA'
        generate_test_data(cls.root)
        cls.w = WikiCore(cls.root / 'notebook' / 'test_notebook.db')

    @classmethod
    def tearDownClass(cls):
        cls.w.close()
        cls.tmp.cleanup()

    def pid(self, title, deleted=None):
        rows = [p for p in self.w.history_posts() if p['last_title'] == title
                and (deleted is None or bool(p['deleted']) == deleted)]
        return rows[-1]['post_id']

    def test_walkthrough(self):
        w, I = self.w, self.root / 'import'
        # 1 dashboard
        ov = w.project_overview(self.TODAY)
        self.assertEqual(ov['overdue'], ['Accessibility review', 'Export old posts'])
        self.assertEqual(sorted(ov['due_soon']), ['Build the landing page', 'Pilot run'])
        self.assertEqual(ov['blocked'], ['Accessibility review'])
        self.assertEqual([v['title'] for v in ov['violations']], ['Mockups approved'])
        self.assertIn('due', ov['violations'][0]['problem'])
        self.assertEqual(ov['orphans'], ['Fix printer'])
        self.assertEqual(ov['cycles'], ['Chicken', 'Egg'])
        cards = {p['title']: p for p in ov['projects']}
        self.assertEqual((cards['Website Relaunch']['total'], round(cards['Website Relaunch']['progress'] * 100)), (8, 29))
        self.assertEqual((cards['Thesis Chapter 3']['total'], round(cards['Thesis Chapter 3']['progress'] * 100)), (6, 50))
        self.assertEqual((cards['Home Server']['total'], cards['Home Server']['progress']), (0, None))
        self.assertEqual(cards['Old blog theme']['item']['status'], 'dropped')
        self.assertEqual(ov['unfiled'], ['Renew domain'])
        # 2 project page
        page = w.render('Website Relaunch')
        self.assertIn('contract project', page)
        self.assertEqual(len(w.titles_with_field_value(('project', 'scope'), 'Website Relaunch')), 6)
        self.assertIn('tw://tiddler/New%20design', page)
        # 4 new task under Pilot run
        w.save_tiddler('Write up pilot', '', ['task'], fields={'status': 'planned', 'parent': 'Pilot run'})
        thesis = {p['title']: p for p in w.project_overview(self.TODAY)['projects']}['Thesis Chapter 3']
        self.assertEqual((thesis['total'], round(thesis['progress'] * 100)), (7, 43))
        # 5 bad status refused, then done
        with self.assertRaisesRegex(SchemaError, "'finished' is not one of"):
            w.update_tiddler('Write up pilot', 'Write up pilot', '', ['task'], reason='x',
                             fields={'status': 'finished', 'parent': 'Pilot run'})
        w.update_tiddler('Write up pilot', 'Write up pilot', '', ['task'], reason='finished',
                         fields={'status': 'done', 'parent': 'Pilot run'})
        # 6 violation must be fixed on edit
        mock = w.get_tiddler('Mockups approved')
        with self.assertRaisesRegex(SchemaError, 'missing required field'):
            w.update_tiddler('Mockups approved', 'Mockups approved', 'new text', mock['tags'], reason='x')
        w.update_tiddler('Mockups approved', 'Mockups approved', 'new text', mock['tags'], reason='add date',
                         fields=dict(mock['fields'], due='2026-11-01'))
        self.assertEqual(w.contract_violations(), [])
        # 7/8 require parent for tasks
        task = w.field_schemas()['task']
        task['required'] = ['status', 'parent']
        with self.assertRaises(ContractAcknowledgementRequired) as ctx:
            w.save_field_schema('task', task, reason='tasks need parents')
        self.assertEqual(ctx.exception.violations, ['Renew domain'])
        w.save_field_schema('task', task, reason='tasks need parents', acknowledge_contract_change=True)
        self.assertTrue(w.post_history(self.pid('$:/schema/task'))[-1]['reason'].endswith(
            '[contract change acknowledged by owner]'))
        self.assertEqual([v['title'] for v in w.contract_violations()], ['Renew domain'])
        # 9 removing a property needs acknowledgement
        loose = json.loads(json.dumps(task)); del loose['properties']['priority']
        with self.assertRaises(ContractAcknowledgementRequired):
            w.save_field_schema('task', loose, reason='no priorities')
        # 10/11 history and restore
        pid = self.pid('Build the landing page')
        hist = w.post_history(pid)
        self.assertEqual([(e['change_type'], e['reason']) for e in hist],
                         [('first_version', 'First version — new post created'), ('edit', 'Started work'),
                          ('rename', 'Clearer title; added footer')])
        self.assertEqual(w.restore_version(pid, hist[0]['event_id'], reason='back')['title'], 'Build landing page')
        self.assertEqual(len(w.post_history(pid)), 4)
        # 12 restore a deleted post
        sid = self.pid('Scratch idea', deleted=True)
        r = w.restore_version(sid, w.post_history(sid)[-1]['event_id'], reason='want it')
        self.assertEqual((r['mode'], w.get_tiddler('Scratch idea')['text']), ('new_post', 'Delete me.'))
        # 13 protected
        self.assertTrue(w.is_protected('Client brief (original)'))
        # 14-18 imports
        self.assertEqual(w.import_json(I / '01_valid_tasks.json'), 2)
        self.assertEqual(w.get_tiddler('Make figures')['fields']['parent'], 'Experiments')
        with self.assertRaisesRegex(SchemaError, "'in progress' is not one of"):
            w.import_json(I / '02_invalid_status.json')
        self.assertIsNone(w.get_tiddler('Good imported task'))
        self.assertEqual(w.import_json(I / '03_bring_own_contract.json'), 3)
        self.assertIn('bug', w.field_schemas())
        with self.assertRaises(ContractAcknowledgementRequired):
            w.import_json(I / '04_loosen_task_contract.json', on_conflict='overwrite', reason='loosen')
        self.assertEqual(w.import_json(I / '04_loosen_task_contract.json', on_conflict='overwrite',
                                       reason='loosen', acknowledge_contract_change=True), 1)
        with self.assertRaisesRegex(PermissionError, 'Protected'):
            w.import_json(I / '05_overwrite_protected.json', on_conflict='overwrite', reason='x')
        # 19 verify
        self.assertTrue(w.verify_history()['verified'])
        # 21-23 a form from a template, linked to the project, needs its argument
        import views
        self.assertEqual(len(w.list_templates()), 9)
        pre = w.preset_from_template('$:/template/adr', project='Website Relaunch')
        self.assertEqual((pre['tags'], pre['fields']['adr_status'], pre['fields']['project'],
                          pre['fields']['qualifier']), (['adr'], 'proposed', 'Website Relaunch', 'provisional'))
        with self.assertRaisesRegex(SchemaError, 'missing required field\\(s\\): claim, grounds, warrant'):
            w.save_tiddler('ADR — Use a CDN', pre['text'], pre['tags'], fields=pre['fields'])
        w.save_tiddler('ADR — Use a CDN', pre['text'], pre['tags'],
                       fields=dict(pre['fields'], claim='Use a CDN', grounds='Visitors are worldwide',
                                   warrant='Edge caching cuts latency'))
        self.assertIn('class="toulmin"', w.render('ADR — Use a CDN'))
        self.assertEqual(len(w.titles_with_field_value(('project', 'scope'), 'Website Relaunch')), 7)
        # 24-25 kanban and WIP limit
        board = w.render('Kanban — Website Relaunch')
        for lane in ('Backlog (2)', 'Doing (0 / 1)', 'Blocked (1)', 'Done (1)', '1 dropped card(s) hidden'):
            self.assertIn(lane, board)
        for title in ('Build landing page', 'Export old posts'):
            post = w.get_tiddler(title)
            w.update_tiddler(title, title, post['text'], post['tags'], reason='started',
                             fields=dict(post['fields'], status='active'))
        board = w.render('Kanban — Website Relaunch')
        self.assertIn('Doing (2 / 1)', board)
        self.assertIn('over WIP limit', board)
        # 26-27 waterfall phases and gate reason
        plan = w.get_tiddler('Waterfall — Thesis Chapter 3')
        strip = views.waterfall_strip(plan, self.TODAY)
        self.assertIn('Requirements ✓', strip)
        self.assertIn('Design ✓', strip)
        self.assertIn('class="phase late"', strip)
        w.update_tiddler(plan['title'], plan['title'], plan['text'], plan['tags'],
                         reason='Gate: implementation complete', fields=dict(plan['fields'], phase='verification'))
        strip = views.waterfall_strip(w.get_tiddler(plan['title']), self.TODAY)
        self.assertIn('Implementation ✓', strip)
        self.assertIn('class="phase now"', strip)
        self.assertEqual(w.post_history(self.pid(plan['title']))[-1]['reason'], 'Gate: implementation complete')
        # 28 dropping the argument from a form is a loosening
        daily = w.field_schemas()['daily']
        daily['required'] = ['date']
        with self.assertRaises(ContractAcknowledgementRequired):
            w.save_field_schema('daily', daily, reason='too heavy')
        self.assertTrue(w.verify_history()['verified'])

    def test_generator_refuses_existing_folder(self):
        import make_test_data
        self.assertEqual(make_test_data.main(['--out', str(self.root), '--pvs-src', '']), 2)


@unittest.skipUnless(PVS_SRC, 'set PVS_SRC to the PVS-01 src folder')
class PVSWalkthrough(unittest.TestCase):
    """Manual steps 29-36 on TEST_DATA/pvs/pvs_loop.db."""

    def test_steps_29_to_36(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / 'TEST_DATA'
            generate_test_data(root, pvs=True)
            proj = 'PVS/versioner/typed-fields'
            with WikiCore(root / 'pvs' / 'pvs_loop.db') as w:
                # 29 dashboard sync card
                st = w.pvs_state()
                self.assertEqual([(c['title'], c['wiki'], c['pvs']) for c in st['conflicts']],
                                 [(proj + '/ratchet', 'blocked', 'active')])
                self.assertEqual([(t['title'], t['operation']) for t in st['to_enter']],
                                 [(proj + '/gui', 'set_goal_status ACTIVE')])
                self.assertEqual([(r['title'], r['operation']) for r in st['reasoning_pending']],
                                 [('Argument — The editor needs inline help', 'add_goal_argument for')])
                self.assertIn('PVS sync', w.render_dashboard())
                # 30 your text + changed PVS content
                page = w.render(proj)
                self.assertTrue(w.get_tiddler(proj)['text'].startswith('! Typed fields — my notes'))
                self.assertIn('PVS content changed since', page)
                self.assertIn('Start with a small checker', page)
                self.assertIn('Document field contracts', page)
                # 31 entered argument
                self.assertIn('Entered in PVS', w.render('Argument — Start with a small checker'))
                # 32 resolve conflict
                w.resolve_pvs_conflict(proj + '/ratchet', 'pvs', reason='PVS is right')
                self.assertEqual((w.pvs_state()['conflicts'], w.get_tiddler(proj + '/ratchet')['fields']['status']),
                                 ([], 'active'))
                # 33 deletion refused
                with self.assertRaisesRegex(PermissionError, 'Remove it in PVS'):
                    w.delete_tiddler(proj + '/gui', reason='x')
                # 34 change log chain
                log = w.verify_change_log()
                self.assertTrue(log['verified'], log['problems'])
                self.assertGreaterEqual(log['entries'], 4)
                # 35 refresh again
                before = log['entries']
                report = w.refresh_from_pvs(pvs_src=PVS_SRC)
                self.assertEqual((report['new'], report['from_pvs'], report['conflicts']), ([], [], []))
                pending = len(report['to_enter']) + sum(1 for r in report['reasoning']
                                                         if not r['entered'] and not r['problem'])
                self.assertEqual(pending, 2)
                self.assertGreater(w.verify_change_log()['entries'], before)
                self.assertTrue(w.verify_change_log()['verified'])
                self.assertTrue(w.verify_history()['verified'])
            # 36 archive export refuses a non-workspace and creates nothing
            with self.assertRaisesRegex(Exception, 'not a PVS workspace'):
                WikiCore.create_pvs_notebook(Path(tmp) / 'x.db', root, pvs_src=PVS_SRC)
            self.assertFalse((Path(tmp) / 'x.db').exists())


if __name__ == '__main__':
    unittest.main()
