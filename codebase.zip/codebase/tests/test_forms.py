"""Forms kit: templates, Toulmin arguments, kanban and waterfall."""
from __future__ import annotations

import unittest
from datetime import date

from helpers import Notebook
from wiki_core import ContractAcknowledgementRequired, SchemaError


class Forms(Notebook):
    def setUp(self):
        super().setUp()
        self.kit()
        self.created = self.w.install_forms_kit()
        self.w.save_tiddler('Site', '', ['project'], fields={'status': 'active'})

    def fill(self, tag, **extra):
        pre = self.w.preset_from_template('$:/template/' + tag, project='Site', today=date(2026, 11, 9))
        f = dict(pre['fields'], claim='c', grounds='g', warrant='w')
        f.update(extra)
        return pre, f

    def test_kit_installs_nine_forms_and_guide(self):
        import forms
        self.assertEqual(len(self.created), 2 * 9 + 1)
        self.assertEqual(self.w.install_forms_kit(), [])
        self.assertEqual(sorted(t['tag'] for t in self.w.list_templates()), sorted(forms.FORM_TAGS))
        for tag in forms.FORM_TAGS:
            self.assertEqual(self.w.field_schemas()[tag]['required'][-3:], ['claim', 'grounds', 'warrant'])

    def test_every_form_saves_when_filled_and_needs_its_argument(self):
        extra = {'5w1h': dict(what='a', why='b', how='c'),
                 'five-whys': dict(problem='p', root_cause='r', countermeasure='m')}
        for t in self.w.list_templates():
            pre, f = self.fill(t['tag'], **extra.get(t['tag'], {}))
            title = pre['title'] or 'Form ' + t['tag']
            no_warrant = {k: v for k, v in f.items() if k != 'warrant'}
            with self.assertRaisesRegex(SchemaError, 'warrant'):
                self.w.save_tiddler(title, pre['text'], pre['tags'], fields=no_warrant)
            self.w.save_tiddler(title, pre['text'], pre['tags'], fields=f)
        self.w.verify_history()

    def test_preset_substitutes_and_avoids_duplicate_titles(self):
        pre = self.w.preset_from_template('$:/template/daily', today=date(2026, 11, 9))
        self.assertEqual((pre['title'], pre['fields']['date'], pre['tags']), ('Daily — 2026-11-09', '2026-11-09', ['daily']))
        self.w.save_tiddler(pre['title'], '', ['daily'], fields=dict(pre['fields'], claim='c', grounds='g', warrant='w'))
        again = self.w.preset_from_template('$:/template/daily', today=date(2026, 11, 9))
        self.assertEqual(again['title'], 'Daily — 2026-11-09 (2)')
        kan = self.w.preset_from_template('$:/template/kanban', project='Site')
        self.assertEqual((kan['fields']['scope'], kan['title']), ('Site', 'Kanban — Site'))
        self.assertNotIn('project', kan['fields'])

    def test_edited_template_is_used_and_versioned(self):
        tpl = self.w.get_tiddler('$:/template/adr')
        self.w.update_tiddler('$:/template/adr', '$:/template/adr', tpl['text'] + '\n!! Review date\n',
                              tpl['tags'], reason='We review decisions')
        self.assertIn('Review date', self.w.preset_from_template('$:/template/adr')['text'])
        self.assertEqual(len(self.w.post_history(self.post_id('$:/template/adr'))), 2)

    def test_toulmin_box_and_documents(self):
        pre, f = self.fill('adr', adr_status='accepted', backing='b', rebuttal='r')
        self.w.save_tiddler('ADR — x', pre['text'], pre['tags'], fields=f)
        page = self.w.render('ADR — x')
        self.assertIn('class="toulmin"', page)
        for word in ('because', 'since', 'on account of', 'unless'):
            self.assertIn(word, page)
        site = self.w.render('Site')
        self.assertIn('Documents', site)
        self.assertIn('tw://tiddler/ADR%20%E2%80%94%20x', site)

    def test_kanban_board_and_wip_limit(self):
        for i, status in enumerate(['planned', 'active', 'active', 'blocked', 'done', 'dropped']):
            self.w.save_tiddler(f't{i}', '', ['task'], fields={'status': status, 'parent': 'Site'})
        pre, f = self.fill('kanban', wip_limit='1')
        self.w.save_tiddler('Board', '', pre['tags'], fields=f)
        page = self.w.render('Board')
        self.assertIn('Doing (2 / 1)', page)
        self.assertIn('over WIP limit', page)
        self.assertIn('Backlog (1)', page)
        self.assertIn('1 dropped card(s) hidden', page)
        with self.assertRaisesRegex(SchemaError, 'integer'):
            self.w.update_tiddler('Board', 'Board', '', pre['tags'], reason='x', fields=dict(f, wip_limit='many'))

    def test_waterfall_phases(self):
        import views
        pre, f = self.fill('waterfall', phase='design', requirements_end='2026-10-01', design_end='2026-11-01')
        self.w.save_tiddler('Plan', '', pre['tags'], fields=f)
        html = views.waterfall_strip(self.w.get_tiddler('Plan'), date(2026, 11, 9))
        self.assertIn('Requirements ✓', html)
        self.assertIn('class="phase late"', html)
        with self.assertRaises(SchemaError):
            self.w.update_tiddler('Plan', 'Plan', '', pre['tags'], reason='x', fields=dict(f, phase='testing'))

    def test_loosening_a_form_contract_needs_ack(self):
        schema = self.w.field_schemas()['daily']
        schema['required'] = ['date']
        with self.assertRaises(ContractAcknowledgementRequired):
            self.w.save_field_schema('daily', schema, reason='arguments are too heavy for daily logs')
        self.w.save_field_schema('daily', schema, reason='arguments are too heavy for daily logs',
                                 acknowledge_contract_change=True)
        self.w.save_tiddler('Daily — free', '', ['daily'], fields={'date': '2026-11-09'})


if __name__ == '__main__':
    unittest.main()
