"""Storage behaviour kept from T05.1, and the browse query."""
from __future__ import annotations

import json
import sqlite3
import os
import unittest

from helpers import APP, Notebook
from wiki_core import WikiCore


class Regression(Notebook):
    def test_existing_workflow_unchanged(self):
        self.w.save_tiddler('A', 'x', ['t'])
        with self.assertRaises(ValueError):
            self.w.update_tiddler('A', 'A', 'y', ['t'], reason=' ')
        with self.assertRaises(ValueError):
            self.w.delete_tiddler('A', reason='')
        self.assertTrue(self.w.update_tiddler('A', 'B', 'y', ['t'], reason='rename'))
        self.assertEqual(self.w.search('y', mode='Text'), ['B'])
        out = os.path.join(self.tmp.name, 'backup.db')
        self.w.snapshot_pair(out)
        with WikiCore(out, readonly=True) as b:
            self.assertTrue(b.verify_history()['verified'])
        exp = os.path.join(self.tmp.name, 'e.json')
        self.assertEqual(self.w.export_json(exp), 1)

    def test_demo_content_imports_with_kit(self):
        self.kit()
        demo = APP.parent / 'demo' / 'STARTER_TIDDLERS.json'
        self.assertEqual(self.w.import_json(demo), 15)
        self.w.verify_history()


class Tamper(Notebook):
    """The shared digest/projection checks still catch outside edits."""

    def protect(self):
        src = os.path.join(self.tmp.name, 'e.json')
        with open(src, 'w') as f:
            json.dump([{'title': 'Evidence', 'text': 'v1', 'tags': 'x'}], f)
        self.w.import_json(src, protect_imported=True)
        self.w.close()

    def sql(self, statement, *args):
        con = sqlite3.connect(self.path)
        con.execute(statement, args)
        con.commit()
        con.close()

    def test_protected_source_change_refuses_open(self):
        self.protect()
        self.sql("UPDATE tiddlers SET raw_json=replace(raw_json,'v1','v2') WHERE title='Evidence'")
        self.w = None
        with self.assertRaisesRegex(Exception, 'source hash mismatch'):
            WikiCore(self.path)

    def test_protected_tag_index_change_refuses_open(self):
        self.protect()
        self.sql("DELETE FROM tiddler_tags WHERE title='Evidence'")
        self.w = None
        with self.assertRaisesRegex(Exception, 'tag index inconsistent'):
            WikiCore(self.path)

    def test_history_detects_edited_search_column(self):
        self.w.save_tiddler('A', 'one', ['t'])
        self.w.close()
        self.w = None
        self.sql("UPDATE tiddlers SET text='two' WHERE title='A'")
        self.w = None
        with self.assertRaisesRegex(Exception, 'Content/history disagreement'):
            WikiCore(self.path)


class Layers(unittest.TestCase):
    def test_base_storage_has_no_writers(self):
        from db import TiddlerDB
        from history_db import HistoryTiddlerDB
        for name in ('save_tiddler', 'update_tiddler', 'delete_tiddler', 'rename_tiddler', 'import_json'):
            self.assertNotIn(name, vars(TiddlerDB), name)
            self.assertIn(name, vars(HistoryTiddlerDB), name)


class Browse(Notebook):
    def setUp(self):
        super().setUp()
        self.kit()
        self.w.install_forms_kit()
        self.w.save_tiddler('Site', 'alpha beta', ['project'], fields={'status': 'active'})
        self.w.save_tiddler('Note', 'beta', ['journal'])
        self.w.save_tiddler('ADR — x', 'beta', ['adr'],
                            fields=dict(adr_status='proposed', claim='c', grounds='g', warrant='w'))

    def titles(self, *a, **k):
        return [r['title'] for r in self.w.browse(*a, **k)]

    def test_views_partition_posts(self):
        posts, system, every = (set(self.titles(v, limit=1000)) for v in ('posts', 'system', 'all'))
        self.assertEqual(posts | system, every)
        self.assertFalse(posts & system)
        self.assertEqual(self.titles('projects'), ['Site'])
        self.assertEqual(self.titles('forms'), ['ADR — x'])

    def test_search_modes_inside_views(self):
        self.assertEqual(self.titles('forms', 'beta', mode='Text'), ['ADR — x'])
        self.assertEqual(sorted(self.titles('posts', 'beta', mode='Text')), ['ADR — x', 'Note', 'Site'])
        self.assertEqual(self.titles('posts', 'journal', mode='Tag'), ['Note'])
        self.assertEqual(self.titles('projects', 'journal', mode='Tag'), [])
        self.assertEqual(self.titles('system', 'schema/adr'), ['$:/schema/adr'])
        with self.assertRaises(ValueError):
            self.w.browse('nope')

    def test_paging_is_exact(self):
        for i in range(12):
            self.w.save_tiddler(f'n{i:02d}', '', ['journal'])
        page1 = self.titles('posts', 'journal', mode='Tag', limit=5)
        page2 = self.titles('posts', 'journal', mode='Tag', limit=5, offset=5)
        self.assertEqual(len(page1 + page2), 10)
        self.assertFalse(set(page1) & set(page2))

    def test_own_template_counts_as_form(self):
        self.w.save_tiddler('$:/template/meeting', '! Meeting', ['$:/tags/Template'],
                            fields={'template_name': 'Meeting', 'template_tags': 'meeting'})
        self.w.save_tiddler('Standup', '', ['meeting'])
        self.assertIn('Standup', self.titles('forms'))


if __name__ == '__main__':
    unittest.main()
