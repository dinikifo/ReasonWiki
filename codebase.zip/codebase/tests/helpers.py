"""Shared fixtures for the PERSONAL.WIKI test suite.

Run from the project root:   python3 -m unittest discover -s tests -v
PVS tests run only when PVS_SRC points at the PVS-01 'src' folder.
GUI tests run only when PySide6 is installed (offscreen platform).
"""
from __future__ import annotations

import os
from pathlib import Path
import sys
import tempfile
import unittest

APP = Path(__file__).resolve().parents[1] / 'app'
TOOLS = APP.parent / 'tools'
for _p in (str(APP), str(TOOLS)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from wiki_core import WikiCore  # noqa: E402

import importlib.util

HAVE_QT = importlib.util.find_spec('PySide6') is not None

PVS_SRC = os.environ.get('PVS_SRC')


class Notebook(unittest.TestCase):
    """A fresh, empty notebook pair per test, opened as ``self.w``."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.tmp.name, 'w.db')
        WikiCore.create_database(self.path)
        self.w = WikiCore(self.path)

    def tearDown(self):
        if self.w is not None:  # tests that damage the files set self.w = None
            self.w.close()
        self.tmp.cleanup()

    def kit(self):
        self.w.install_project_kit()

    def post_id(self, title):
        return [p for p in self.w.history_posts() if p['last_title'] == title][-1]['post_id']

    def reasons(self, title):
        return [e['reason'] for e in self.w.post_history(self.post_id(title))]


def generate_test_data(out: Path, pvs: bool = False) -> None:
    """Run tools/make_test_data.py into ``out`` with a fixed date."""
    import make_test_data
    argv = ['--out', str(out), '--today', '2026-11-09', '--pvs-src', PVS_SRC if pvs else '']
    assert make_test_data.main(argv) == 0


def qt_app():
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    os.environ['WIKI_PREVIEW_MODE'] = 'qt'
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def destroy_widgets(app, *widgets) -> None:
    """Delete Qt widgets while the QApplication is alive (PySide crashes otherwise)."""
    from PySide6.QtCore import QCoreApplication, QEvent
    for widget in widgets:
        widget.close()
        widget.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)
    app.processEvents()
