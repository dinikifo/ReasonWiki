"""Notebook bundles: export, inspect, restore; tampering; PVS link after a move."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile

from helpers import APP, Notebook, PVS_SRC, generate_test_data
from wiki_core import WikiCore
import bundle


class Bundles(Notebook):
    def setUp(self):
        super().setUp()
        self.kit()
        self.w.save_tiddler('P', 'text', ['project'], fields={'status': 'active'})
        self.w.update_tiddler('P', 'P', 'edited', ['project'], reason='edit', fields={'status': 'done'})
        self.w.update_change_log()
        self.out = Path(self.tmp.name) / 'nb.pwbundle'

    def test_round_trip(self):
        manifest = self.w.export_bundle(self.out)
        self.assertEqual((manifest['posts'], manifest['change_log']['verified']), (self.w.count(), True))
        dest = Path(self.tmp.name) / 'restored' / 'copy.db'
        dest.parent.mkdir()
        result = WikiCore.restore_bundle(self.out, dest)
        self.assertEqual(result['posts'], self.w.count())
        with WikiCore(dest) as copy:
            self.assertEqual(copy.get_tiddler('P')['fields']['status'], 'done')
            self.assertEqual(len(copy.post_history([p for p in copy.history_posts()
                                                    if p['last_title'] == 'P'][0]['post_id'])), 2)
            self.assertTrue(copy.verify_change_log()['verified'])
        self.assertEqual(sorted(os.listdir(dest.parent)), ['copy.db', 'copy.history.sqlite'])  # no leftovers

    def test_never_overwrites(self):
        self.w.export_bundle(self.out)
        with self.assertRaisesRegex(bundle.BundleError, 'already exists'):
            self.w.export_bundle(self.out)
        with self.assertRaisesRegex(bundle.BundleError, 'already exists'):
            WikiCore.restore_bundle(self.out, self.path)

    def tamper(self, member, data):
        bad = Path(self.tmp.name) / 'bad.pwbundle'
        with zipfile.ZipFile(self.out) as src, zipfile.ZipFile(bad, 'w') as dst:
            for name in src.namelist():
                dst.writestr(name, data if name == member else src.read(name))
        return bad

    def test_altered_or_damaged_bundles_refused(self):
        self.w.export_bundle(self.out)
        with zipfile.ZipFile(self.out) as z:
            db_bytes = bytearray(z.read(bundle.CONTENT))
            manifest = json.loads(z.read(bundle.MANIFEST))
        db_bytes[-1] ^= 1
        dest = Path(self.tmp.name) / 'x.db'
        with self.assertRaisesRegex(bundle.BundleError, 'checksum'):
            WikiCore.restore_bundle(self.tamper(bundle.CONTENT, bytes(db_bytes)), dest)
        manifest['format'] = 'other'
        with self.assertRaisesRegex(bundle.BundleError, 'Not a PERSONAL.WIKI'):
            WikiCore.restore_bundle(self.tamper(bundle.MANIFEST, json.dumps(manifest)), dest)
        junk = Path(self.tmp.name) / 'junk.pwbundle'
        junk.write_bytes(b'not a zip')
        with self.assertRaisesRegex(bundle.BundleError, 'not a notebook bundle'):
            WikiCore.restore_bundle(junk, dest)
        self.assertFalse(dest.exists())

    def test_consistent_but_altered_history_refused(self):
        """Even with matching checksums, a pair whose history disagrees is refused."""
        import sqlite3
        work = Path(self.tmp.name) / 'evil'
        work.mkdir()
        self.w.snapshot_pair(work / 'n.db')
        con = sqlite3.connect(work / 'n.db')
        con.execute("UPDATE tiddlers SET text='forged' WHERE title='P'")
        con.commit()
        con.close()
        evil = Path(self.tmp.name) / 'evil.pwbundle'
        files = {bundle.CONTENT: work / 'n.db', bundle.HISTORY: work / 'n.history.sqlite'}
        manifest = {'format': bundle.FORMAT, 'version': bundle.VERSION, 'created_at': 'x',
                    'files': {k: {'sha256': bundle._sha256(v), 'bytes': v.stat().st_size} for k, v in files.items()}}
        with zipfile.ZipFile(evil, 'w') as z:
            z.writestr(bundle.MANIFEST, json.dumps(manifest))
            for name, path in files.items():
                z.write(path, name)
        with self.assertRaisesRegex(Exception, 'disagreement|History verification failed'):
            WikiCore.restore_bundle(evil, Path(self.tmp.name) / 'y.db')
        self.assertFalse((Path(self.tmp.name) / 'y.db').exists())

    def test_cli(self):
        tool = APP.parent / 'tools' / 'notebook_bundle.py'
        self.w.close()
        run = lambda *a: subprocess.run([sys.executable, str(tool), *a], capture_output=True, text=True)  # noqa: E731
        self.assertEqual(run('export', self.path, str(self.out)).returncode, 0)
        inspected = run('inspect', str(self.out))
        self.assertEqual(json.loads(inspected.stdout)['format'], bundle.FORMAT)
        dest = Path(self.tmp.name) / 'cli.db'
        self.assertEqual(run('restore', str(self.out), str(dest)).returncode, 0)
        refused = run('restore', str(self.out), str(dest))
        self.assertEqual(refused.returncode, 2)
        self.assertIn('already exists', refused.stderr)
        self.w = WikiCore(self.path)


@unittest.skipUnless(PVS_SRC, 'set PVS_SRC to the PVS-01 src folder')
class BundleMovesPvsNotebook(unittest.TestCase):
    def test_restore_elsewhere_then_refresh_from_moved_workspace(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            generate_test_data(tmp / 'TD', pvs=True)
            out = tmp / 'loop.pwbundle'
            with WikiCore(tmp / 'TD' / 'pvs' / 'pvs_loop.db') as w:
                manifest = w.export_bundle(out)
                before = w.pvs_state()
            self.assertEqual(len(manifest['pvs']['workspace_id']), 64)
            # "another machine": the workspace now lives somewhere else
            shutil.move(str(tmp / 'TD' / 'pvs' / 'workspace'), str(tmp / 'elsewhere'))
            (tmp / 'machine2').mkdir()
            result = WikiCore.restore_bundle(out, tmp / 'machine2' / 'loop.db')
            self.assertIn('next refresh will ask', result['pvs_note'])
            import pvs_sync
            with WikiCore(tmp / 'machine2' / 'loop.db') as w:
                with self.assertRaises(pvs_sync.WorkspaceMissing):
                    w.refresh_from_pvs(pvs_src=PVS_SRC)
                report = w.refresh_from_pvs(tmp / 'elsewhere', pvs_src=PVS_SRC)
                self.assertEqual(report['new'], [])
                self.assertEqual([c['title'] for c in report['conflicts']],
                                 [c['title'] for c in before['conflicts']])  # carried over, not lost
                after = w.pvs_state()
                self.assertEqual(len(after['to_enter']), len(before['to_enter']))
                self.assertTrue(w.verify_change_log()['verified'])


if __name__ == '__main__':
    unittest.main()
