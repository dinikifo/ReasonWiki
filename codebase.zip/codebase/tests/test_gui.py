"""Desktop UI smoke tests (offscreen; needs PySide6)."""
from __future__ import annotations

import unittest

from helpers import HAVE_QT, PVS_SRC, Notebook, destroy_widgets, generate_test_data, qt_app
from wiki_core import WikiCore


@unittest.skipUnless(HAVE_QT, 'PySide6 not installed')
class GuiCase(Notebook):
    """Opens the notebook in a main window; Qt objects are destroyed safely."""

    def open_window(self):
        self.app = qt_app()
        import main
        self.main = main
        self.w.close()  # the window opens its own WikiCore
        self.win = main.TiddlyViewer()
        self.win._load_database(self.path)
        self.widgets = [self.win]
        return self.win

    def keep(self, widget):
        self.widgets.append(widget)
        return widget

    def tearDown(self):
        if getattr(self, 'widgets', None):
            destroy_widgets(self.app, *reversed(self.widgets))
            self.widgets = []
        self.w = WikiCore(self.path)
        super().tearDown()

    def rows(self):
        lst = self.win.results_list
        return [lst.item(i).text() for i in range(lst.count())]


class EditorAndDashboard(GuiCase):
    def test_editor_fields_and_dashboard(self):
        self.kit()
        self.w.save_tiddler('P', '', ['project'], fields={'status': 'active'})
        self.w.save_tiddler('Imported', '', [], fields={'n': 3})
        win = self.open_window()
        win._show_dashboard()
        self.assertEqual(win._showing, 'dashboard')
        ed = self.keep(self.main.TiddlerEditor(win, None, core=win.db, preset={'title': 'x', 'tags': ['task']}))
        self.assertEqual(ed.get_tiddler_data()['fields'], {})  # placeholder row ignored
        ed2 = self.keep(self.main.TiddlerEditor(win, win.db.get_tiddler('Imported'), core=win.db))
        self.assertEqual(ed2.get_tiddler_data()['fields'], {'n': 3})  # non-string value preserved
        chooser = self.keep(self.main.ProjectItemDialog(win, win.db, 'P'))
        self.assertEqual(chooser.kind.currentText(), 'goal')


class FormsUi(GuiCase):
    def test_template_dialog_and_argument_section(self):
        self.kit()
        self.w.install_forms_kit()
        self.w.save_tiddler('Site', '', ['project'], fields={'status': 'active'})
        self.w.save_tiddler('Note', '', ['journal'], fields={'mood': 'ok'})
        win = self.open_window()
        chooser = self.keep(self.main.TemplateDialog(win, win.db, 'Site'))
        self.assertEqual(chooser.list.count(), 9)
        self.assertEqual(chooser.project.currentText(), 'Site')
        chooser.list.setCurrentRow([t['tag'] for t in chooser.templates].index('adr'))
        template, project = chooser.choice()
        ed = self.keep(self.main.TiddlerEditor(win, None, core=win.db,
                                               preset=win.db.preset_from_template(template, project=project)))
        self.assertFalse(ed.argument_box.isHidden())
        ed.argument_edits['claim'].setText('Use SQLite')
        ed.argument_edits['grounds'].setPlainText('Single user\nLocal files')
        ed.argument_edits['warrant'].setPlainText('No server needed')
        data = ed.get_tiddler_data()
        self.assertEqual((data['fields']['claim'], data['fields']['grounds']), ('Use SQLite', 'Single user\nLocal files'))
        self.assertEqual(data['fields']['qualifier'], 'provisional')
        win.db.save_tiddler('ADR — SQLite', data['text'], data['tags'], fields=dict(data['fields']))
        plain = self.keep(self.main.TiddlerEditor(win, win.db.get_tiddler('Note'), core=win.db))
        self.assertTrue(plain.argument_box.isHidden())  # untyped posts: no argument section
        self.assertEqual(plain.get_tiddler_data()['fields'], {'mood': 'ok'})
        self.assertEqual(win.db.get_tiddler('ADR — SQLite')['fields']['adr_status'], 'proposed')


class BrowsePanel(GuiCase):
    def setUp(self):
        super().setUp()
        self.kit()
        self.w.install_forms_kit()
        self.w.save_tiddler('Site', 'alpha', ['project'], fields={'status': 'active'})
        self.w.save_tiddler('Note', 'alpha', ['journal'])
        self.w.save_tiddler('ADR — x', 'alpha', ['adr'],
                            fields=dict(adr_status='proposed', claim='c', grounds='g', warrant='w'))

    def view(self, key):
        self.win.view_picker.setCurrentIndex(self.win.view_picker.findData(key))
        return self.rows()

    def test_views(self):
        self.open_window()
        posts = self.rows()
        self.assertIn('Note', posts)
        self.assertFalse(any(r.startswith('$:/') for r in posts))  # system posts hidden by default
        self.assertEqual(self.view('projects'), ['project · Site  [active]'])
        self.assertEqual(self.view('forms'), ['Decision record (ADR) · ADR — x'])
        self.assertTrue(all(r.startswith('$:/') for r in self.view('system')))
        self.assertIn('🏷 journal', self.view('tags'))
        self.assertEqual(len(self.view('all')), self.win.db.count())

    def test_search_within_view_and_tag_click(self):
        win = self.open_window()
        self.view('forms')
        win.search_mode.setCurrentText('Text')
        win.search_input.setText('alpha')
        win._reset_search()
        self.assertEqual(self.rows(), ['Decision record (ADR) · ADR — x'])
        self.view('tags')
        win.search_input.setText('jour')
        win._reset_search()
        self.assertEqual(self.rows(), ['🏷 journal'])
        win._on_result_clicked(win.results_list.item(0))
        self.assertEqual((win._current_view(), self.rows()), ('all', ['Note']))

    def test_list_keeps_view_after_save(self):
        win = self.open_window()
        self.view('projects')
        win.db.save_tiddler('Second', '', ['project'], fields={'status': 'planned'})
        win._refresh_results()
        self.assertEqual(win._current_view(), 'projects')
        self.assertEqual(len(self.rows()), 2)


class ChangeLogUi(GuiCase):
    def test_opening_a_notebook_catches_up_the_log(self):
        self.w.save_tiddler('A', 'x', [])
        win = self.open_window()
        self.assertEqual(win.db.verify_change_log()['entries'], 1)
        self.assertIn('[[A]]', win.db.get_tiddler(win.db.verify_change_log()['tip'])['text'])


class BundleUi(GuiCase):
    def test_export_and_restore_actions(self):
        import os
        from PySide6.QtWidgets import QFileDialog, QMessageBox
        self.w.save_tiddler('A', 'x', [])
        win = self.open_window()
        bundle_path = os.path.join(self.tmp.name, 'b.pwbundle')
        restored = os.path.join(self.tmp.name, 'restored.db')
        shown = []
        patches = {
            (QFileDialog, 'getSaveFileName'): iter([(bundle_path, ''), (restored, '')]),
            (QFileDialog, 'getOpenFileName'): iter([(bundle_path, '')]),
        }
        saved = {}
        for (cls, name), answers in patches.items():
            saved[(cls, name)] = getattr(cls, name)
            setattr(cls, name, staticmethod(lambda *a, _it=answers, **k: next(_it)))
        saved[(QMessageBox, 'information')] = QMessageBox.information
        saved[(QMessageBox, 'critical')] = QMessageBox.critical
        QMessageBox.information = staticmethod(lambda *a, **k: shown.append(a[1]))
        QMessageBox.critical = staticmethod(lambda *a, **k: shown.append('FAIL ' + a[2]))
        try:
            win._export_bundle()
            win._restore_bundle()
        finally:
            for (cls, name), value in saved.items():
                setattr(cls, name, value)
        self.assertEqual(shown, ['Bundle written', 'Notebook restored'])
        self.assertEqual(win.db.db_path, restored)
        self.assertEqual(win.db.get_tiddler('A')['text'], 'x')


@unittest.skipUnless(HAVE_QT and PVS_SRC, 'needs PySide6 and PVS_SRC')
class PvsUi(GuiCase):
    def setUp(self):
        super().setUp()
        import shutil
        import tempfile
        from pathlib import Path
        self.data = tempfile.mkdtemp()
        generate_test_data(Path(self.data) / 'TD', pvs=True)
        self.w.close()
        for suffix in ('.db', '.history.sqlite'):
            shutil.copy(Path(self.data) / 'TD' / 'pvs' / ('pvs_loop' + suffix), self.path.replace('.db', suffix))
        self.w = WikiCore(self.path)

    def tearDown(self):
        super().tearDown()
        import shutil
        shutil.rmtree(self.data, ignore_errors=True)

    def test_editor_hides_and_keeps_pvs_fields(self):
        win = self.open_window()
        title = 'PVS/versioner/typed-fields/gui'
        post = win.db.get_tiddler(title)
        ed = self.keep(self.main.TiddlerEditor(win, post, core=win.db))
        table = ed.fields_table
        names = {table.item(r, 0).text() for r in range(table.rowCount())}
        self.assertFalse(any(n.startswith('pvs_') or n == 'parent' for n in names))
        data = ed.get_tiddler_data()
        self.assertEqual({k: v for k, v in data['fields'].items() if k.startswith('pvs_')},
                         {k: v for k, v in post['fields'].items() if k.startswith('pvs_')})
        win.db.update_tiddler(title, title, 'formatted', data['tags'], reason='format', fields=data['fields'])

    def test_sync_page_and_conflict_dialog_offered(self):
        win = self.open_window()
        offered = []
        win._resolve_conflicts = lambda conflicts: offered.append([c['title'] for c in conflicts])
        win._show_pvs_sync()
        self.assertEqual(win._showing, 'pvs')
        self.assertEqual(offered, [['PVS/versioner/typed-fields/ratchet']])


@unittest.skipUnless(HAVE_QT, 'PySide6 not installed')
class Shutdown(unittest.TestCase):
    def test_shutdown_destroys_window_before_app(self):
        app = qt_app()
        import main
        win = main.TiddlyViewer()
        destroyed = []
        win.destroyed.connect(lambda *_: destroyed.append(True))
        main.shutdown(app, win)
        self.assertEqual(destroyed, [True])


if __name__ == '__main__':
    unittest.main()
