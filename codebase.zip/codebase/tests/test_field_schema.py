"""Typed-field schemas and the ratchet (field_schema.py)."""
from __future__ import annotations

import random
import unittest

import helpers  # puts app/ on sys.path
import field_schema as fs

assert helpers.APP.is_dir()


class FieldSchemaUnit(unittest.TestCase):
    def test_bounds_on_dropped_type_count_as_tightening(self):
        self.assertTrue(fs.narrows_or_equals({'type': 'null'},
                                             {'type': ['null', 'string'], 'minLength': 1}))
        self.assertTrue(fs.narrows_or_equals({'type': 'boolean'},
                                             {'type': ['boolean', 'integer'], 'maximum': 10}))

    def test_loosening_detected(self):
        old = {'type': 'object', 'properties': {'s': {'type': 'string', 'enum': ['a', 'b']}},
               'required': ['s']}
        self.assertFalse(fs.narrows_or_equals({'type': 'object', 'properties': {'s': {'type': 'string'}},
                                               'required': ['s']}, old))
        self.assertFalse(fs.narrows_or_equals({'type': 'object', 'properties': old['properties']}, old))
        self.assertTrue(fs.narrows_or_equals({'type': 'object', 'properties': {'s': {'type': 'string', 'enum': ['a']}},
                                              'required': ['s', 't']}, old))

    def test_format_ratchet(self):
        self.assertTrue(fs.narrows_or_equals({'type': 'string', 'format': 'date'}, {'type': 'string'}))
        self.assertFalse(fs.narrows_or_equals({'type': 'string'}, {'type': 'string', 'format': 'date'}))
        self.assertFalse(fs.narrows_or_equals({'type': 'string', 'format': 'number'},
                                              {'type': 'string', 'format': 'integer'}))

    def test_formats(self):
        for value, fmt, ok in (('2026-02-28', 'date', True), ('2026-02-30', 'date', False),
                               ('26-1-1', 'date', False), ('-12', 'integer', True), ('1.5', 'integer', False),
                               ('1.5e3', 'number', True), ('abc', 'number', False)):
            self.assertEqual(fs.is_valid(value, {'type': 'string', 'format': fmt}), ok, (value, fmt))

    def test_unknown_keyword_refused(self):
        with self.assertRaises(fs.SchemaError):
            fs.check_schema({'type': 'string', 'pattern': 'x'})

    def test_narrowing_is_sound_on_random_pairs(self):
        rng = random.Random(4)
        types = ['string', 'integer', 'number', 'boolean', 'null', 'object']

        def schema(depth=0):
            s = {}
            if rng.random() < .8:
                s['type'] = rng.choice(types) if rng.random() < .7 else rng.sample(types, rng.randint(1, 3))
            ts = [s.get('type', 'any')] if isinstance(s.get('type', 'any'), str) else s['type']
            if depth < 1 and ('object' in ts or 'any' in ts) and rng.random() < .7:
                s['properties'] = {k: schema(depth + 1) for k in 'ab' if rng.random() < .6}
                if rng.random() < .5:
                    s['required'] = [k for k in 'ab' if rng.random() < .5]
                if rng.random() < .4:
                    s['additionalProperties'] = rng.random() < .5
            if rng.random() < .2:
                s['enum'] = rng.sample(['x', 'yy', 1, 2.5, True, None], rng.randint(1, 3))
            if rng.random() < .3: s['minimum'] = rng.randint(-2, 2)
            if rng.random() < .3: s['maximum'] = rng.randint(2, 4)
            if rng.random() < .3: s['minLength'] = rng.randint(0, 2)
            if rng.random() < .3: s['maxLength'] = rng.randint(2, 3)
            if rng.random() < .2: s['format'] = rng.choice(['date', 'integer', 'number'])
            return s

        def value(depth=0):
            c = rng.randint(0, 7)
            return [lambda: rng.choice(['', 'x', 'yy', '12', '2026-01-01', 'abcd']), lambda: rng.randint(-3, 5),
                    lambda: rng.choice([0.5, 2.5]), lambda: rng.random() < .5, lambda: None,
                    lambda: {k: value(depth + 1) for k in 'abz' if rng.random() < .5} if depth < 2 else 1,
                    lambda: '3', lambda: '2026-13-01'][c]()
        checked = 0
        for _ in range(40000):
            a, b = schema(), schema()
            try:
                fs.check_schema(a); fs.check_schema(b)
            except fs.SchemaError:
                continue
            if not fs.narrows_or_equals(a, b):
                continue
            checked += 1
            for _ in range(30):
                v = value()
                if fs.is_valid(v, a):
                    self.assertTrue(fs.is_valid(v, b), (a, b, v))
        self.assertGreater(checked, 1000)


if __name__ == '__main__':
    unittest.main()
