"""Project tracking: overview, dashboard, post panels."""
from __future__ import annotations

import unittest
from datetime import date

from helpers import Notebook


class ProjectOverview(Notebook):
    def test_tree_progress_and_attention(self):
        self.kit()
        S = self.w.save_tiddler
        S('P', '', ['project'], fields={'status': 'active'})
        S('G', '', ['goal'], fields={'status': 'active', 'parent': 'P'})
        S('t1', '', ['task'], fields={'status': 'done', 'parent': 'G'})
        S('t2', '', ['task'], fields={'status': 'blocked', 'parent': 'G', 'due': '2026-11-01'})
        S('t3', '', ['task'], fields={'status': 'dropped', 'parent': 'G'})
        S('t4', '', ['task'], fields={'status': 'planned', 'parent': 'G', 'due': '2026-11-12'})
        S('orphan', '', ['task'], fields={'status': 'planned', 'parent': 'Nowhere'})
        S('c1', '', ['goal'], fields={'status': 'planned', 'parent': 'c2'})
        S('c2', '', ['goal'], fields={'status': 'planned', 'parent': 'c1'})
        S('loose', '', ['task'], fields={'status': 'planned'})
        ov = self.w.project_overview(date(2026, 11, 9))
        p = ov['projects'][0]
        self.assertEqual((p['title'], p['total']), ('P', 5))
        self.assertAlmostEqual(p['progress'], 1 / 4)
        self.assertEqual(ov['overdue'], ['t2'])
        self.assertEqual(ov['due_soon'], ['t4'])
        self.assertEqual(ov['blocked'], ['t2'])
        self.assertEqual(ov['orphans'], ['orphan'])
        self.assertEqual(ov['cycles'], ['c1', 'c2'])
        self.assertIn('loose', ov['unfiled'])
        html = self.w.render_dashboard(date(2026, 11, 9))
        self.assertIn('tw://tiddler/t2', html)
        self.assertIn('Parent cycles', html)
        page = self.w.render('G')
        self.assertIn('fieldpanel', page)
        self.assertIn('tw://tiddler/t1', page)

    def test_dashboard_escapes_titles(self):
        self.kit()
        self.w.save_tiddler('<img src=x>', '', ['project'], fields={'status': 'active'})
        html = self.w.render_dashboard()
        self.assertNotIn('<img src=x>', html)
        self.assertIn('&lt;img src=x&gt;', html)

    def test_empty_notebook_dashboard(self):
        self.assertIn('No project items yet', self.w.render_dashboard())
        self.assertIn('No contracts yet', self.w.render_contracts())


if __name__ == '__main__':
    unittest.main()
