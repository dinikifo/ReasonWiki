#!/bin/sh
cd "$(dirname "$0")" || exit 1
if [ -x ".venv/bin/python" ]; then
  ".venv/bin/python" start_personal_wiki.py
else
  python3 start_personal_wiki.py
fi
status=$?
if [ "$status" -ne 0 ]; then
  printf '\nLaunch failed (exit %s). See README.md for Python and PySide6 requirements.\n' "$status"
  printf 'Press Return to close...'
  read -r _
fi
exit "$status"
