@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" start_personal_wiki.py
) else (
  py -3 start_personal_wiki.py
)
if errorlevel 1 (
  echo.
  echo Launch failed. See README.md for Python and PySide6 requirements.
  pause
)
