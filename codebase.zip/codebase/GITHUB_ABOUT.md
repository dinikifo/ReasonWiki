# GitHub repository metadata (copy into the GitHub interface)

This is metadata for the repository settings, not configuration used by the
application.

**Suggested repository name**

`personal-wiki-experimental`

**Suggested short description** (GitHub "About")

Experimental offline Python/SQLite personal wiki for project tracking, reasoned history, typed fields, Toulmin forms and PVS snapshots.

**Suggested topics**

`python`, `sqlite`, `pyside6`, `personal-wiki`, `knowledge-management`,
`project-management`, `decision-records`, `toulmin`, `experimental`, `cc0`

**Longer project description**

PERSONAL.WIKI T06 is an experimental, single-user desktop notebook for project
management and structured reasoning. It combines searchable TiddlyWiki-style
posts, local SQLite version history with edit reasons, checked metadata fields,
project hierarchies and dashboards, and reusable forms for 5W1H, 5 Whys, A3,
ADR, PDCA, daily logs, Kanban, Waterfall, and Toulmin arguments. It can read
and reconcile PVS-01 snapshots while keeping that external system authoritative
for its own data. Built on the author's earlier Personal Wiki work, with
additional inspiration from Addendum of the Desiderata. Released under CC0 to
the extent the author holds the relevant rights. Not production hardened.

**Suggested first release title**

`T06 — Experimental Projects & Reasoning Notebook`

**Suggested release tag**

`v0.6.0-experimental`

The release tag is a *suggestion*, not a claim about prior versions.
Mark this as a **pre-release** if publishing before cross-platform validation.

**Related repository URLs — complete before publishing**

- `ADD_PERSONAL_WIKI_GITHUB_URL`
- `ADD_DESIDERATA_GITHUB_URL`

These are explicit placeholders: the supplied package did not identify the
actual owner/repositories. Do not publish them as though they were live links.
