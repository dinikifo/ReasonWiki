# Publishing this experimental project

This is a **prepared CC0 release candidate**, not a published GitHub repository.
No source-code logic was intentionally modified in this preparation; the changes
are license files, the README release notice, and these publishing notes.

## Before making the repository public

1. Confirm that you own or control rights in all code and documentation you are
   dedicating under CC0. If work is from other authors, retain their licensing
   and notices rather than assuming CC0 covers it.
2. Replace `ADD_PERSONAL_WIKI_GITHUB_URL` and `ADD_DESIDERATA_GITHUB_URL` in
   `README.md`, `ORIGINS.md`, and `GITHUB_ABOUT.md` with the real upstream links.
   If known, add the original commits/tags that were used. Keep the
   relationship clear without asserting unverified file-level reuse.
3. Review all source and screenshots for personal details, URLs, usernames,
   tokens, and information you would not want permanently indexed. A quick
   static scan is not a guarantee of a clean public release.
4. Do not include your own notebook databases, backups, passwords, local PVS
   workspaces, or other private data. `TEST_DATA/` is excluded via `.gitignore`;
   the generator can create example data for a release artifact separately.
5. Install optional GUI and PVS prerequisites on the target platforms and run
   acceptance tests before claiming those integrations work there.
6. Review the documented history-integrity, authentication, and portability
   limitations. Do not characterize this as production security software.

## GitHub repository description

Use `GITHUB_ABOUT.md` for a copy-ready project description, suggested topics,
and draft release metadata. This file is not automatically read into GitHub
repository settings.

## GitHub publishing

Initialize a new repository using the *contents* of this archive at the
repository root (not a single ZIP file), so that GitHub sees `LICENSE` and
`README.md`. Use `CC0-1.0` as the license identifier when metadata permits,
and mark the first public release as experimental / pre-release.

You can run the headless tests using:

```sh
python -m unittest discover -s tests -v
```

The GUI tests require PySide6; PVS-specific tests additionally require the
`PVS_SRC` environment variable pointing to a compatible external checkout.
As of this preparation, in the provided runtime, **87 tests were discovered,
52 passed, 35 skipped** (primarily missing PySide6 and PVS_SRC). This is not a
complete cross-platform or integration test.

## CC0

`LICENSE` is the CC0 1.0 Universal legal code. CC0 waives the publisher's
copyright and related rights to the extent permitted by law and has a fallback
license. It does not waive patents or trademarks, grant rights in others'
material, or eliminate privacy obligations. See the original legal text at:
https://creativecommons.org/publicdomain/zero/1.0/legalcode
