# PERSONAL.WIKI T06 — User Manual

PERSONAL.WIKI is an offline notebook for notes and projects. Posts are
TiddlyWiki-compatible, every change is kept in a version history with a reason,
and since T06 you can track projects, give post fields checked types, restore
old versions and browse read-only snapshots of PVS-01 workspaces.

**Contents**

1. [Install and start](#1-install-and-start)
2. [The window](#2-the-window)
3. [Posts](#3-posts)
4. [Fields](#4-fields)
5. [Projects](#5-projects)
6. [Field contracts (typed fields)](#6-field-contracts-typed-fields)
7. [Forms and arguments](#7-forms-and-arguments)
8. [History and restore](#8-history-and-restore)
9. [Import, export and protected posts](#9-import-export-and-protected-posts)
10. [Backups and notebook files](#10-backups-and-notebook-files)
11. [Working with PVS](#11-working-with-pvs)
12. [Test data and walkthrough](#12-test-data-and-walkthrough)
13. [Messages and what to do](#13-messages-and-what-to-do)
14. [Keyboard shortcuts](#14-keyboard-shortcuts)
15. [Limits](#15-limits)

---

## 1. Install and start

You need **Python 3.11 or newer** and **PySide6**. SQLite with FTS5 and JSON
support is part of a normal Python install.

1. Extract the folder somewhere writable. Don't extract over an older
   PERSONAL.WIKI folder.
2. Create a virtual environment in the folder and install PySide6:
   - macOS / Linux: `python3 -m venv .venv` then `.venv/bin/python -m pip install PySide6`
   - Windows: `py -3 -m venv .venv` then `.venv\Scripts\python -m pip install PySide6`
3. Start it:
   - macOS: double-click **Start PERSONAL.WIKI.command**
   - Windows: double-click **Start PERSONAL.WIKI.bat**
   - Linux: run **Start PERSONAL.WIKI.sh**
   - Any system: `python3 start_personal_wiki.py`

The first start creates your notebook in `MY_WIKI_DATA/` with 15 introductory
posts and opens **Welcome to PERSONAL.WIKI**. Later starts open the same
notebook; nothing is regenerated.

**If it does not start**

| Command | What it does |
|---|---|
| `python3 start_personal_wiki.py --check` | Checks Python, SQLite and the bundled demo. Creates nothing. |
| `python3 start_personal_wiki.py --prepare` | Creates or verifies `MY_WIKI_DATA` without opening a window. |
| `WIKI_PREVIEW_MODE=qt python3 start_personal_wiki.py` | Uses the simpler Qt text preview. Use this on systems without Qt WebEngine, such as some Raspberry Pi setups. |

You can also switch the preview at any time with **View → Use Compatibility
Preview (Qt Text)**. Both previews show the same content. The compatibility one
is plainer.

---

## 2. The window

![Main window showing a project post](images/01_window_post.png)

- **Toolbar:** ◀ ▶ go back and forward through posts you have read.
  **+ New** creates a post, **✎ Edit** edits the one you are reading,
  **+ Item** creates a project item, **▦ Projects** opens the dashboard.
- **Search bar:** type to filter the list. The menu on the right chooses
  **Title**, **Text** (full text) or **Tag**. The search applies within the
  current view (below).
- **List (left):** what the **Show:** picker selects (see 2.1), 200 per page.
  Use *Previous* and *Next* at the bottom to page through.
- **Preview (right):** the post you are reading. Links between posts work by clicking.
- **Status bar:** how many posts the notebook holds, plus short messages.

Menus: **File** (open, create, import, export, backup, verify, PVS snapshot),
**View** (all posts, all tags, dashboard, contracts, project and forms kits, preview mode),
**Navigate** (back, forward) and **Tiddler** (new post, new from template, new
project item, edit, delete, history).

### 2.1 The browse panel

The **Show:** picker above the list chooses what the list contains:

| View | Lists |
|---|---|
| **Posts** (default) | Every post except `$:/` system posts |
| **Projects** | Project items, labelled `kind · title [status]` |
| **Forms** | Posts made from a form, labelled `form · title`. This includes forms you made yourself (chapter 7.6). |
| **Tags** | Every tag. Typing in the search bar filters tag names; clicking a tag lists all posts that carry it. |
| **System ($:/)** | Contracts (`$:/schema/…`), templates (`$:/template/…`) and other system posts |
| **All** | Everything |

![Browse panel showing the Forms view](images/16_browse_forms.png)

Search works inside the chosen view. For example, **Forms** with *Text* mode
and `URLs` finds only the forms that mention URLs. **View → Show All Posts**
(Ctrl+Shift+A) clears the search and lists the current view.

---

## 3. Posts

A post has a **title**, **tags**, **text** written in TiddlyWiki markup, and
optional **fields** (see the next chapter).

**Create:** **+ New** (Ctrl+N). Enter a title, tags and text, then **Save**. Titles must be unique.

**Tags:** separate tags with spaces. A tag that contains spaces goes in double
square brackets: `work [[Website Relaunch]] urgent`.

**Links and markup:** `[[Other post]]` links to another post. For headings,
lists, tables, code and the rest, read the built-in post **07 — Markup Gallery**.

**Edit:** open the post, then **✎ Edit** (Ctrl+E). When you save, the wiki asks
**"Why are you making this change? (Required for history)"**. The reason is
stored with the new version. If you cancel the reason, your draft stays open.

**Rename:** change the title in the editor. The history follows the post under
its new name.

**Delete:** **Tiddler → Delete Tiddler** (Ctrl+Shift+D). You confirm, then give a
reason. The post's last content stays in the history, so you can bring it back
(see chapter 8).

**If a save fails,** the editor reopens with your draft intact. Nothing is ever
half-saved: each save either completes fully or changes nothing.

---

## 4. Fields

Fields are named values attached to a post, such as `status = active`. They
are stored as TiddlyWiki fields, so they survive JSON export and import.

The editor has a **Fields** table under the text:

- **+ Field** adds a row. Type the name in the first column and the value in the second.
- **− Remove** deletes the selected row. Saving without the row removes the field.
- The names `title`, `text`, `tags`, `created` and `modified` are reserved;
  use the boxes above for those.
- Under the table, the editor shows the **contract** for the post's tags: which
  fields are allowed, what values they take, and which are required (marked
  with `*`). When you add a tag that has a contract, empty rows appear for its
  required fields.
- An empty row that you added and never filled in is ignored.

When you read a post that has fields, a panel above the text lists them. A
`parent` field is shown as a link, and the panel says whether each contract is
satisfied (✓).

![Editing a task's fields](images/03_editor.png)

---

## 5. Projects

### 5.1 Setting up

Choose **View → Install Project Kit** once per notebook. It adds:

- contracts for the four kinds of project item: `$:/schema/project`,
  `$:/schema/goal`, `$:/schema/milestone` and `$:/schema/task`
- a guide post, **10 — Managing Projects**

Installing again changes nothing. If you start a project item in a notebook
that has no contracts yet, the wiki offers to install the kit first.

### 5.2 Project items

A project item is any post tagged `project`, `goal`, `milestone` or `task`.
They all use the same fields:

| Field | Values | Meaning |
|---|---|---|
| `status` | `planned`, `active`, `blocked`, `done`, `dropped` | Required |
| `parent` | title of another item | What it belongs to: a goal's project, a task's goal or milestone… |
| `due` | a date such as `2026-12-31` | Shown as overdue or due soon on the dashboard |
| `priority` | `high`, `medium`, `low` | Used for sorting |

The kinds don't impose a strict hierarchy. A task can sit directly under a
project, and a milestone can have tasks under it.

**To create one:** **Tiddler → New Project Item…** (Ctrl+Shift+P) or **+ Item**.

![New project item dialog](images/04_new_item.png)

If you are reading a project item when you start, the dialog suggests it as the
parent and picks the next kind down: project → goal → milestone → task. Choose
the kind, title, parent, status, due date and priority, then **OK**. The editor
opens with the tag and fields filled in, so you can add text before saving.

**To change status** (for example to mark a task done), edit the post and
change the `status` row in the Fields table.

### 5.3 The dashboard

**View → Project Dashboard** (Ctrl+D) or **▦ Projects**.

![Project dashboard](images/02_dashboard.png)

**Needs attention** lists only the sections that have entries:

| Section | Shows |
|---|---|
| Overdue | Open items (planned, active or blocked) whose `due` date has passed |
| Due in the next 7 days | Open items due from today through seven days from now |
| Blocked | Items with status `blocked` |
| Contract violations | Posts whose fields break their contract, with the reason (see 6.4) |
| Missing parent | Items whose `parent` names a post that doesn't exist |
| Parent cycles | Items whose parents loop back to themselves, such as A → B → A |

Below that, each **project** gets a card. The card shows its status, due date,
priority, a progress bar, item counts by status, and a tree of everything under
it. **Progress** is done ÷ (all items − dropped items). A project with no items
shows no bar. Items that aren't under any project are listed at the end under
**Not under a project**.

Click any title to open it. The dashboard is recalculated each time you open it.

On a project item's own page, the fields panel also lists its **Children**.

---

## 6. Field contracts (typed fields)

### 6.1 What a contract is

A contract decides which fields posts with a given tag may have and what values
those fields may hold. It is an ordinary post titled `$:/schema/<tag>`, and its
text is JSON. For example, the kit's task contract is:

```json
{
  "type": "object",
  "properties": {
    "status":   {"type": "string", "enum": ["planned", "active", "blocked", "done", "dropped"]},
    "parent":   {"type": "string", "minLength": 1},
    "due":      {"type": "string", "format": "date"},
    "priority": {"type": "string", "enum": ["high", "medium", "low"]}
  },
  "required": ["status"]
}
```

Any tag can have a contract, not only the project kinds. Posts without a
governed tag aren't checked at all. **View → Field Contracts** lists every
contract as a table.

![Field contracts page](images/05_contracts.png)

### 6.2 What is checked

- When you **save, edit, rename, import or restore** a post, its fields must
  satisfy the contract of **every** tag it carries that has one. If they don't,
  nothing is saved. You see **"Fields do not match the contract"** with the
  reason, and the editor reopens with your draft.
- A contract post must be valid JSON describing an object, using only the
  supported keywords (6.5). A malformed contract can't be saved.

### 6.3 Changing a contract: the ratchet

Edit the contract post like any other post, giving a reason. The wiki compares
the new contract with the old one:

| Change | What happens |
|---|---|
| **Tightening**, such as making `parent` required, removing a value from an `enum`, adding `format: "date"` or narrowing a length | Saved immediately |
| **Loosening**, such as removing a required field, widening an `enum` or dropping a `format` | Asks you to acknowledge |
| A change the wiki **can't prove** is a tightening | Asks you to acknowledge |
| **Deleting or renaming** a contract post | Asks you to acknowledge |
| Tightening that **existing posts would break** | Asks you to acknowledge, and names the posts |

![Acknowledgement dialog](images/06_acknowledge.png)

If you answer **Yes**, the change is saved and its history reason ends with
**`[contract change acknowledged by owner]`**, so you can always see which
contract changes were deliberate loosenings. If you answer **No**, nothing
changes and your draft stays open.

The check is conservative: it never calls a loosening a tightening, but now
and then it asks about a change that really was a tightening. When that
happens, answer Yes.

### 6.4 Violations

A violation can only exist after you acknowledge a tightening that existing
posts don't meet, or after a file was changed outside the app. Violating posts
are listed on the dashboard, and their fields panel names the problem. The next
time you edit such a post, you must fix its fields before it will save.

### 6.5 Supported keywords

| Keyword | Use |
|---|---|
| `type` | `object`, `string`, `integer`, `number`, `boolean`, `null`, `array`, `any`, or a list of these |
| `properties` | One schema per field name |
| `required` | List of field names that must be present |
| `additionalProperties` | `false` means no fields other than those listed |
| `enum` | List of allowed values |
| `minLength`, `maxLength` | String length |
| `minimum`, `maximum` | Numeric bounds (for real JSON numbers, which come from imported data) |
| `format` | For strings: `date` (YYYY-MM-DD, a real calendar date), `integer`, `number` |
| `items` | Schema for list elements |

Values typed in the editor are always **strings**. To type a number or date
field, use `"type": "string"` with a `format`, for example
`"estimate": {"type": "string", "format": "number"}`. Any other JSON Schema
keyword is refused, so a typo can't silently disable a check.

---

## 7. Forms and arguments

Forms are templates for the posts that document *how* a project is going and
*why* you decided what you did. Each form is a tag with a template and a
contract, so a form post can't be saved half filled in, and **every form
carries a Toulmin argument.**

### 7.1 Setting up and starting a form

Choose **View → Install Forms Kit** once per notebook. It adds a template
(`$:/template/<form>`) and a contract (`$:/schema/<form>`) for each form, plus
the guide post **11 — Using Forms**. Installing again changes nothing.

**To start a form:** **Tiddler → New from Template…** (Ctrl+T).

![Template chooser](images/10_template_dialog.png)

Pick the form, and optionally the project it documents. If you are reading a
project item when you start, that item is preselected. The editor then opens
with the title, tag, text skeleton and default fields filled in. For example,
the Daily log's title and `date` are set to today, and a Kanban board's `scope`
is set to the project.

### 7.2 The forms

| Form (tag) | Use it when | Its own fields (`*` = required) |
|---|---|---|
| **5W1H** (`5w1h`) | Scoping new work | `what*`, `why*`, `how*`, `who`, `when`, `where` |
| **5 Whys** (`five-whys`) | Something went wrong and you want a cause you can act on | `problem*`, `root_cause*`, `countermeasure*` |
| **A3 report** (`a3`) | Telling a problem's or project's whole story on one page. Update the same post as the work moves. | `a3_status*` (draft, in-progress, closed), `review_date` |
| **Decision record** (`adr`) | Recording a decision that you, or future you, will need to explain | `adr_status*` (proposed, accepted, rejected, deprecated, superseded), `decided`, `superseded_by` |
| **PDCA cycle** (`pdca`) | Treating an iteration as an experiment | `cycle*` (a number), `pdca_phase*` (plan, do, check, act), `metric` |
| **Daily log** (`daily`) | Writing down what got done, what's next, what's blocked and what you decided | `date*` |
| **Kanban board** (`kanban`) | Seeing a project's work as a board with a WIP limit | `scope*` (the project), `wip_limit*` (a number) |
| **Waterfall plan** (`waterfall`) | Running work in fixed phases with deadlines | `scope*`, `phase*`, `requirements_end`, `design_end`, `implementation_end`, `verification_end` |
| **Argument** (`argument`) | Recording a single argument for or against something | `stance*` (support, oppose), `responds_to`, `about` |

Every form also has an optional `project` field. When it's set, the project's
page lists the form under **Documents**.

![A project page listing its documents](images/15_project_documents.png)

### 7.3 The argument

Every form requires a Toulmin argument. The editor shows it in its own
**Argument** section, with room for full sentences:

| Part | Question it answers | Required |
|---|---|---|
| **Claim** | What do you conclude? | yes |
| **Grounds** | What facts or evidence support it? | yes |
| **Warrant** | Why do those grounds support the claim? | yes |
| **Backing** | What supports the warrant? | |
| **Qualifier** | How sure are you? (`provisional` by default; also likely, certain…) | |
| **Rebuttal** | When would the claim not hold? | |

![Filling in a 5 Whys form](images/11_form_editor.png)

On the post, the argument appears as a box at the top: *claim — because
grounds — since warrant — on account of backing — unless rebuttal*.

![A decision record](images/12_adr_post.png)

The six parts are plain text fields, the same shape PVS-01 uses for its
arguments. To reply to an argument, create an **Argument** form and set
`responds_to` to the title of the post you're answering.

If a required argument is too heavy for a form you use often (say, the daily
log), you can loosen that form's contract (chapter 6.3). The wiki asks you to
acknowledge the change, so the decision to relax it is recorded too.

### 7.4 Kanban boards

A Kanban post draws a **live board** from the items under its `scope` project.
The lanes are **Backlog** (planned), **Doing** (active), **Blocked** and
**Done**, and each card is ordered by priority and then due date.

![Kanban board](images/13_kanban.png)

- **To move a card,** change the item's `status`. The board itself holds no
  cards; it's a view of the project.
- The cards are the project's tasks, plus any goals or milestones that have no
  children (anything that has children is a container, not a card).
- If **Doing** holds more cards than `wip_limit`, the lane turns red and says
  **over WIP limit**.
- Dropped items are hidden and counted below the board.

### 7.5 Waterfall plans

A Waterfall post shows a **phase strip**: Requirements, Design,
Implementation, Verification, Maintenance. Finished phases are marked ✓, the
current phase is highlighted, and the current phase turns red if its end date
has passed.

![Waterfall phase strip](images/14_waterfall.png)

**To move to the next phase,** edit the `phase` field. The reason you give is
the **gate decision**, and the post's history keeps every gate with its date
and reason. Put the exit criteria for each phase in the text.

### 7.6 Changing forms or adding your own

Templates and contracts are ordinary posts, so editing them is versioned like
anything else.

- **To change a form's skeleton,** edit `$:/template/<form>`. New posts use the
  new version; existing posts don't change.
- **To make a form stricter or looser,** edit `$:/schema/<form>`. The ratchet
  rules from chapter 6 apply.
- **To create a new form,** copy a template and a contract under a new tag. The
  template's fields set up the chooser:

| Field | Meaning |
|---|---|
| `template_name` | Name shown in the chooser |
| `template_description` | One-line description |
| `template_title` | Title of new posts; `{date}` becomes today, `{project}` the chosen project |
| `template_tags` | Tags of new posts (normally the form's tag) |
| `template_fields` | JSON object of default field values; `{date}` and `{project}` work here too |

---

## 8. History and restore

### 8.1 Viewing history

**Tiddler → View Post History…** opens the history window, starting on the post
you are reading. Choose any post from the drop-down, including deleted ones,
which are marked `[Deleted]`. Each version shows when it was made, the kind of
change (`first_version`, `edit`, `rename`, `delete`, `import_overwrite`), the
reason, the SHA-256 digests, and the complete before and after content.

![Post history window](images/07_history.png)

### 8.2 Restoring

Select a version and press **Restore This Version…**, then give a reason.

- **The post still exists:** the chosen version becomes the current one as a
  **new** version. The versions in between stay in the history, and its reason
  names the event it came from. If the old version had a different title, the
  post is renamed back.
- **The post was deleted:** a deleted post's history is closed, so the version
  comes back as a **new post** with its own history. Its first reason names the
  deleted post and event it came from. If a post with that title already
  exists, rename that post first.
- Restored content must satisfy **today's** contracts. If an old version breaks
  a contract you have since tightened, fix the post by hand instead.
- **Protected** posts can't be restored over.
- If the post already matches the chosen version, nothing happens.

History is never rewritten or removed by the app.

### 8.3 Verifying

**File → Verify Post History** recomputes every digest and checks that the
history and the current posts agree. The same check runs automatically before
a notebook opens for editing.

### 8.4 The change log

Besides each post's own history, the wiki keeps a **change log**: a chain of
posts tagged `changelog` that you can read like a diary of the notebook.

- **One entry per day of edits**, for example *Change log 0003 — 2026-11-09 — edits*.
  It's a table of every change that day (time in UTC, the post as a link, the
  kind of change, the reason). The newest entry keeps growing during the day.
- **One entry per PVS refresh**, for example *Change log 0004 — 2026-11-09 13:20:05 —
  PVS refresh*: what came from PVS, what is still to enter in PVS, conflicts and
  removed items, all as links (chapter 11).

The number is the entry's place in the chain, so the list shows them in order.
Each entry links the **previous** one (`log_prev`) and stores the SHA-256 of the
previous entry as it was when linked (`log_prev_sha256`). Once a newer entry
exists, the older one is **protected**, so the wiki checks its digest every time
the notebook opens. **File → Verify Post History** also walks the chain and
reports a broken link, a gap in the numbering, or an earlier entry that changed.

![A change-log entry for a PVS refresh](images/20_changelog.png)

The log catches up automatically when you open or close a notebook, and before
every PVS refresh. **File → Update Change Log** catches up immediately. Edits to
the change-log posts themselves aren't logged.

*Limit:* the newest entry isn't protected yet, so deleting it isn't detected by
the chain (its deletion is still in the post history). See chapter 15.

---

## 9. Import, export and protected posts

**Export:** **File → Export JSON…** (Ctrl+Shift+E) writes all current posts,
fields included, as TiddlyWiki JSON. History isn't exported; use a backup for
that (chapter 10).

**Import:** **File → Import JSON…** (Ctrl+I). It asks three questions:

1. **Import conflict handling.** *No* (the default) rejects the whole import if
   any title already exists with different content. *Yes* replaces those posts
   and asks for a reason. *Cancel* stops.
2. **Protect evidence.** *Yes* makes the imported posts read-only (see below).
   *No* leaves them editable.
3. If the batch changes a contract in a way that needs acknowledgement, you get
   **"Contract change in import"**. Nothing has been imported at that point;
   *Yes* runs the import again with the acknowledgement.

An import is **all or nothing**: if one post fails (a conflict, a contract
violation, a protected post), nothing from the file is kept. A file may include
its own contract posts in any order. They're checked against the final state of
the batch.

**Protected posts** are read-only records, such as an original email or a
source document. They can't be edited, renamed, deleted, overwritten by an
import, or restored over, and the wiki checks their digest every time it opens
the notebook. To add commentary, write a new post that links to the protected one.

---

## 10. Backups and notebook files

A notebook is **two files that belong together** in one folder:

```
personal_wiki.db                 posts
personal_wiki.history.sqlite     their history
```

- **Backup:** **File → Snapshot Database…** writes a verified pair, for example
  `wiki_backup.db` and `wiki_backup.history.sqlite`. It never overwrites an
  existing backup. To restore, copy **both** files back together.
- Never copy only the `.db` file of an open notebook, and never mix a `.db` with
  another notebook's history file. The wiki refuses a mismatched pair rather
  than guessing.
- Keep notebooks on a local disk, not in a cloud-sync or network folder, and
  keep copies of your backups on external media.
- **Other notebooks:** **File → New Database…** (Ctrl+Shift+N) creates a new
  pair. **File → Open Database…** (Ctrl+O) switches notebooks. Each folder holds
  independent notebooks; search never crosses notebooks. The starter always
  reopens `MY_WIKI_DATA` on the next launch.

### 10.1 Notebook bundles (back up, move, restore)

A **bundle** is one `.pwbundle` file holding a notebook pair, with a manifest
of checksums. Use it for backups, and to move a notebook to another machine.

- **File → Export Notebook Bundle…** first catches up the change log, then
  writes a bundle from a verified copy of the pair. The name suggests the
  notebook and today's date, e.g. `personal_wiki-2026-11-09.pwbundle`. It never
  overwrites a file.
- **File → Restore Notebook Bundle…** asks for the bundle and a **new** notebook
  name, then:
  1. checks the manifest and the SHA-256 of both files,
  2. unpacks into a private folder next to the destination,
  3. opens the pair read-only and verifies the history, the protected posts and
     the change-log chain,
  4. only then creates the two files (never over existing ones), and opens the
     restored notebook.

  A damaged or altered bundle is refused before anything is written, including
  one whose checksums were recomputed to match a forged history.
- **From a terminal or a scheduled job:**

  ```bash
  python3 tools/notebook_bundle.py export  MY_WIKI_DATA/personal_wiki.db  backups/wiki-2026-11-09.pwbundle
  python3 tools/notebook_bundle.py inspect backups/wiki-2026-11-09.pwbundle
  python3 tools/notebook_bundle.py restore backups/wiki-2026-11-09.pwbundle  elsewhere/personal_wiki.db
  ```

  Each prints a JSON summary and exits with 0. On any refusal it exits with 2
  and gives the reason.

**A suggested routine:** export a bundle at the end of each working session,
and copy bundles to another disk or machine. Restore one now and then into a
scratch folder to prove your backups work. A restore never touches your live
notebook.

**Moving a PVS-linked notebook:** the bundle records which PVS workspace the
notebook follows, by identity (chapter 11.1). After restoring on another
machine, the next refresh asks where the workspace is if it isn't at the
same path.

---

## 11. Working with PVS

You maintain both systems. **PVS** records the project's decisions and code
evidence. **The wiki** is where you read them, format them, and think about
what to do next. Progress can start on either side: a status can change in
the wiki first and wait for you to enter it in PVS, or PVS can move ahead of
the wiki. **The wiki never writes to PVS.** It reads PVS, reconciles, and
lists what you still need to enter there yourself.

### 11.1 Refresh from PVS

**File → Refresh from PVS…** (Ctrl+Shift+R). The first time, choose the PVS
**workspace folder**: the one you passed to `PVSWorkspace(...)`, which contains
`objects/`. The notebook remembers it in the post `$:/config/pvs`; later
refreshes use it without asking. If PVS's code can't be found, the wiki asks
for PVS's **`src` folder** (or set `PVS_SRC`).

**How PVS is read:** the wiki never loads PVS code itself. A refresh runs
`tools/pvs_export.py` as a **separate program**. That program reads the
workspace at one consistent point and writes a JSON snapshot of PVS's data,
which the wiki then reads. You can run it yourself, for example on the machine
where PVS lives:

```bash
python3 tools/pvs_export.py --pvs-src PATH/TO/pvs/src  PATH/TO/workspace  -o pvs-snapshot.json
```

Then use **File → Refresh from PVS Snapshot File…** on any machine to reconcile
from that file. It works exactly like a normal refresh.

**Same workspace, any folder:** the notebook knows its workspace by an
**identity**, taken from the first event of every PVS object, not by its
folder. If the workspace has moved (another folder, another machine, restored
from a backup), the refresh says *"The PVS workspace is no longer at …"* and
asks where it is now. A **different** workspace is refused (*"… this is a
different workspace"*). One notebook follows one workspace; use another
notebook for another workspace.

A refresh reads every PVS object at one consistent point, then updates **this
notebook** in a single transaction:

| PVS item | Post |
|---|---|
| Project | `PVS/<versioner>/<project>`, tagged `project` and `pvs` |
| Acceptance-branch goal | `…/<goal>`, tagged `goal` and `pvs` |
| Milestone | `…/<goal>/<milestone>`, tagged `milestone` and `pvs` |
| Rejection-branch goal | tagged `pvs-evidence` (evidence for *not* doing the project, not counted as work) |
| Controlled object, index | `PVS/target/<object>`, **PVS snapshot** |

Then you see a summary, and the **PVS Sync** page opens.

### 11.2 Who owns what

| Part of a PVS post | Owner | On refresh |
|---|---|---|
| Text | **You** | Seeded from PVS once, when the post is created. **Never overwritten.** |
| Tags you add, fields you add | **You** | Kept |
| `status` | **Both** | Reconciled (11.3) |
| `parent`, every `pvs_…` field, the PVS content | **PVS** | Updated |

So format and annotate freely. The fields PVS owns are hidden in the editor,
and changing them by hand is refused with *"… belong(s) to PVS. Change it in
PVS, then refresh."* For the same reason you can't rename a PVS post, remove
its `pvs` tag, delete it (unless PVS has dropped it), or create a `pvs` post
yourself.

At the top of every PVS post, a **From PVS** panel shows the revision, history
verdict and branch. If PVS's content has changed since your copy was made, the
panel shows the **current PVS version** below it, so you can update your text.

![A PVS post: your text, with the current PVS content above it](images/17_pvs_post.png)

### 11.3 Status in both directions

The wiki remembers PVS's status at the last refresh (the *base*) and compares:

| You (vs base) | PVS (vs base) | Result |
|---|---|---|
| unchanged | changed | **Takes PVS's value.** The history reason names the refresh. |
| changed | unchanged | **Keeps yours.** It is listed under **To enter in PVS** with the PVS operation to use, e.g. `set_goal_status ACTIVE`. |
| changed | changed to the same value | **In sync** |
| changed | changed to a different value | **Conflict.** Nothing is overwritten; the post and dashboard say so. |

**To resolve conflicts:** **File → PVS Sync…** opens the conflicts dialog.
Select one, choose **Take PVS** or **Keep wiki**, and give a reason. *Keep
wiki* moves the item to *To enter in PVS*.

![Resolving a conflict](images/18_pvs_conflicts.png)

Suggested operations follow PVS's own commands. PVS has no direct way to set a
milestone's status other than stop and resume; for other milestone changes the
suggestion says so.

### 11.4 Reasoning in both directions

Arguments you draft in the wiki can be tracked until they reach PVS. On any
post with a Toulmin argument (usually an **Argument** form), add two fields:

| Field | Value |
|---|---|
| `pvs_target` | The PVS post the argument belongs to, e.g. `PVS/versioner/typed-fields` |
| `pvs_side` | For a project: `acceptance` or `rejection`. For a goal: `for` or `against`. |

The post then says **"To enter in PVS on … : add_rfc_argument acceptance"**
(or `add_goal_argument for`, and so on). After you enter it in PVS with the
same **claim** and **warrant**, the next refresh finds it there and the post
says **"Entered in PVS"**. Arguments added directly in PVS appear in the PVS
post's content after the next refresh.

### 11.5 The PVS Sync page and dashboard

**File → PVS Sync…**, and a **PVS sync** card on the project dashboard, show:

- **Conflicts**
- **To enter in PVS**: statuses and arguments, each with its PVS operation
- **Arguments with a bad PVS target**
- **No longer in PVS**: items PVS dropped. They stay in the wiki, with your
  text, until you delete them (now allowed) or a later refresh finds them again.

![PVS sync on the dashboard](images/19_pvs_sync.png)

Every refresh also writes a **change-log entry** listing exactly what it did
(chapter 8.4).

### 11.6 A typical round

1. **Refresh from PVS.** Read the summary.
2. Read and format the PVS posts. Write insights as forms (ADR, 5 Whys,
   Argument…), linked with `project`, `responds_to` or `pvs_target`.
3. Change statuses where you've decided something.
4. Open **PVS Sync** and enter the *To enter in PVS* items in PVS.
5. **Refresh** again. The entered items disappear from the list, and anything
   PVS changed meanwhile comes in.

### 11.7 Archive copy

**File → Export PVS Archive Notebook…** still creates a separate, fully
protected, read-only notebook of one PVS snapshot. Use it to keep a record of
a moment in time; use **Refresh from PVS** for everyday work.

## 12. Test data and walkthrough

### 12.1 Generate the test data

From the PERSONAL.WIKI folder:

```bash
python3 tools/make_test_data.py
# with PVS data as well:
PVS_SRC=/path/to/function_data_oop/src python3 tools/make_test_data.py
```

This creates `TEST_DATA/` and refuses to overwrite an existing one (use
`--out OTHER_FOLDER`). Due dates are relative to today, so overdue items stay
overdue whenever you generate the data. `--today 2026-11-09` reproduces this
manual's screenshots exactly.

| Path | What it is |
|---|---|
| `notebook/test_notebook.db` | 59 posts with real history. Every dashboard section has entries, and there is at least one post of every form. |
| `import/01…05_*.json` | Import scenarios, with their own README |
| `pvs/workspace/` | A PVS-01 workspace: one accepted and one rejected project (PVS only) |
| `pvs/pvs_loop.db` | A notebook that has been through the two-way loop twice (PVS only, see below) |
| `pvs/pvs_archive.db` | A read-only archive copy of the workspace (PVS only) |

The test notebook contains:

- **Website Relaunch**: 8 items covering every status. *Accessibility review*
  is blocked and 4 days overdue, *Export old posts* is 1 day overdue, *Build the
  landing page* is due in 3 days, and *Redirect map* is dropped.
- **Thesis Chapter 3**: a deeper tree (goal → milestone → tasks). *Pilot run* is
  due in 7 days.
- **Home Server**: a project with no items.
- **Old blog theme**: deleted, then restored as a new post, then marked dropped.
- **Renew domain** (not under a project), **Fix printer** (missing parent),
  **Chicken** and **Egg** (a parent cycle).
- An `estimate` field added to the task contract (a free tightening), and a
  milestone contract that requires `due` (an acknowledged tightening). Together
  they leave **Mockups approved** as a violation.
- **Client brief (original)**: a protected post. **Scratch idea**: deleted and
  left deleted.
- Plain notes with links and a table: **Meeting notes — kickoff** and **Reading list**.
- A change log with one entry for the day's edits.
- The forms kit, with at least one post of every form, all carrying arguments.
  *Website Relaunch* has a 5W1H, a 5 Whys about the blocked review, an A3, an
  ADR (*Keep the old URLs*), an Argument replying to it, and a Kanban board
  with a WIP limit of 1. *Thesis Chapter 3* has a PDCA cycle and a Waterfall
  plan whose implementation phase ended 2 days ago. There are also two daily logs.

The PVS loop notebook went through these steps. Refresh 1; then in the wiki, your
own summary on the *typed-fields* project, goal *gui* set to `active`, goal
*ratchet* set to `blocked`, and two arguments aimed at PVS. Then in PVS, one of
those arguments entered, *ratchet* set to ACTIVE, and a new goal *docs*. Then
Refresh 2. So it shows every case at once.

### 12.2 Walkthrough

Open `TEST_DATA/notebook/test_notebook.db` with **File → Open Database…**, then
work through the steps. Each one says what you should see.

| # | Do this | You should see |
|---|---|---|
| 1 | **▦ Projects** | Overdue (2), Due in the next 7 days (2), Blocked (1), Contract violations (1: *Mockups approved*, missing `due`), Missing parent (*Fix printer* → *Office setup*), Parent cycles (*Chicken*, *Egg*). Cards: *Website Relaunch* 29% with 8 items, *Thesis Chapter 3* 50% with 6 items, *Home Server* with 0 items, *Old blog theme* dropped. *Renew domain* under "Not under a project". |
| 2 | Click **Website Relaunch** | A fields panel with status, due and priority, a ✓ for the project contract, a Children list with two goals, and a Documents list with 6 forms |
| 3 | Open **Experiments** (a goal), press **+ Item** | The dialog suggests parent *Experiments* and kind *milestone*. Cancel. |
| 4 | Open **Pilot run**, **+ Item**, title `Write up pilot`, OK, Save | The new task appears under *Pilot run*, and Thesis Chapter 3 drops to 43% (3 of 7) |
| 5 | Edit **Write up pilot**, set `status` to `finished`, Save | "Fields do not match the contract": `'finished' is not one of: …`. The editor reopens. Set it to `done` and save, giving a reason. |
| 6 | Edit **Mockups approved**, change only the text, Save | Refused: missing required `due`. Add a `due` row such as `2026-11-01`, then save. Step 1's violation is gone. |
| 7 | **View → Field Contracts**, click **task**, Edit. Change `"required": ["status"]` to `["status", "parent"]`. Save with a reason. | "Contract change": 1 existing post would break, **Renew domain** (the only task without a parent). Choose **No**: nothing changes. |
| 8 | Repeat 7 and choose **Yes** | Saved. The history reason ends with `[contract change acknowledged by owner]`, and the dashboard lists *Renew domain* as a violation. |
| 9 | Edit **$:/schema/task** again, delete the `"priority"` line from `properties` and fix the commas. Save. | Asks to acknowledge: removing a property is a loosening. Choose **No**. |
| 10 | Open **Build the landing page**, **Tiddler → View Post History…** | Three versions: `first_version`, `edit` ("Started work"), `rename` ("Clearer title; added footer") |
| 11 | Select the first version, **Restore This Version…**, give a reason | "Restored 'Build landing page' as a new version of the post". The title reverts, and the history now has four versions. |
| 12 | History window: choose **[Deleted] Scratch idea**, select the delete version, **Restore This Version…** | It comes back as a NEW post. Its first reason names the deleted post and event. |
| 13 | Open **Client brief (original)**, press **✎ Edit** | "Protected research record". No editor opens. |
| 14 | **File → Import JSON…** with `import/01_valid_tasks.json` (No, No) | "2 new/changed records committed atomically". *Write results section* and *Make figures* appear under *Experiments*. |
| 15 | Import `02_invalid_status.json` (No, No) | "Import rolled back": `'in progress' is not one of …`. Neither post exists. |
| 16 | Import `03_bring_own_contract.json` (No, No) | 3 records. **View → Field Contracts** now lists **bug**. |
| 17 | Import `04_loosen_task_contract.json` (Yes, reason, No) | "Contract change in import". **Yes** commits it and marks the reason acknowledged. |
| 18 | Import `05_overwrite_protected.json` (Yes, reason, No) | "Import rolled back": the brief is protected |
| 19 | **File → Verify Post History** | "… current posts and … historical events checked against their hashes." |
| 20 | **File → Snapshot Database…** to a new name | "Backup pair verified" with two file names |
| 21 | Open **Website Relaunch**, **Tiddler → New from Template…** (Ctrl+T) | The chooser lists 9 forms, with *Website Relaunch* preselected as the project. Choose **Decision record (ADR)**, OK. |
| 22 | In the editor: title `ADR — Use a CDN`, leave the Argument empty, Save | "Fields do not match the contract": `missing required field(s): claim, grounds, warrant`. The editor reopens. |
| 23 | Fill Claim, Grounds and Warrant, Save | The post shows the argument box. *Website Relaunch* now lists 7 Documents. |
| 24 | Open **Kanban — Website Relaunch** | Backlog (2), Doing (0 / 1), Blocked (1), Done (1), and "1 dropped card(s) hidden". *Build landing page* is back in Backlog because step 11 restored its planned version. |
| 25 | Edit **Build landing page** and **Export old posts**, set each `status` to `active` (each needs a reason). Reopen the board. | Doing (2 / 1), the lane turns red, "over WIP limit" |
| 26 | Open **Waterfall — Thesis Chapter 3** | Requirements ✓, Design ✓, **Implementation** red and marked late, then Verification and Maintenance |
| 27 | Edit it: set `phase` to `verification`, reason `Gate: implementation complete` | Implementation ✓, Verification highlighted. The history keeps the gate reason. |
| 28 | Open **$:/schema/daily** (**View → Field Contracts**, or **Show: System**) and edit it: change `"required"` to `["date"]`, Save | "Contract change": dropping the argument is a loosening. Choose **No**. |
| 29 | (PVS) **File → Open Database…** `pvs/pvs_loop.db`, **▦ Projects** | A **PVS sync** card. Conflicts (1): *ratchet*, wiki `blocked` / PVS `active`. To enter in PVS (2): *gui* status `active` → `set_goal_status ACTIVE`, and *Argument — The editor needs inline help* → `add_goal_argument for`. |
| 30 | (PVS) Click **PVS/versioner/typed-fields** | Your text, *Typed fields — my notes*. Above it, the From PVS panel says PVS content changed and shows the current version, including the argument *Start with a small checker* and the new goal *docs*. |
| 31 | (PVS) Open **Argument — Start with a small checker** | "Entered in PVS: this argument is on PVS/versioner/typed-fields (acceptance)." |
| 32 | (PVS) **File → PVS Sync…**: select *ratchet*, **Take PVS**, give a reason | The conflict disappears, and *ratchet* is `active` again |
| 33 | (PVS) Open **PVS/versioner/typed-fields/gui**, **Tiddler → Delete Tiddler** | Refused: "… comes from PVS. Remove it in PVS, then refresh." |
| 34 | (PVS) **Show: Posts**, search `Change log` | At least 4 entries: edits, refresh, edits, refresh. Each links the previous one. **File → Verify Post History** ends with "Change log: … entries, chain intact." |
| 35 | (PVS) **File → Refresh from PVS…** | It asks nothing (the workspace is remembered). Summary: nothing new, status from PVS 0, to enter in PVS 2, conflicts 0. A new change-log entry is added. |
| 36 | (PVS) **File → Export PVS Archive Notebook…**, choose `TEST_DATA` itself | Refused: "… is not a PVS workspace (no objects/ folder)". Nothing is created. |
| 37 | Open `notebook/test_notebook.db`, **File → Export Notebook Bundle…**, accept the suggested name | "Bundle written", with post, event and change-log counts |
| 38 | **File → Restore Notebook Bundle…**: choose that bundle and a new name such as `restored.db` | "Notebook restored … verified". The restored notebook opens; **Verify Post History** passes and **▦ Projects** looks the same as step 1 (plus your walkthrough edits). |

Steps 1, 2, 4–12, 14–18 and 22–28 are also checked automatically through the API
by `tests/test_walkthrough.py` (class `Walkthrough`), steps 29–36 by
`PVSWalkthrough`, and steps 37–38 by `tests/test_bundle.py` and `tests/test_gui.py`.

---

## 13. Messages and what to do

| Message | Meaning and fix |
|---|---|
| **Fields do not match the contract** … `'x' is not one of: …` / `missing required field(s)` / `is not a valid date` | Fix the field in the editor; the draft is kept. Dates are `YYYY-MM-DD`. If the missing fields are `claim, grounds, warrant`, fill in the editor's Argument section. |
| **Contract change** … loosens the old one / removes the field contract / existing post(s) do not satisfy | The change needs your acknowledgement. Yes saves it and marks the reason; No changes nothing. |
| **Contract '$:/schema/x' is unreadable** | That contract post holds invalid JSON. Open and fix it; posts with that tag can't be saved until you do. |
| **Protected research record** / **Historical record is protected** | Read-only post. Write a new post that links to it. |
| **The current post already matches that version** | Nothing to restore. |
| **A post titled '…' already exists; rename it first** | Restoring a deleted post would clash with an existing title. |
| **History verification failed; changes refused** | The `.db` and `.history.sqlite` files disagree, usually because one was copied or edited outside the app. Restore your last verified backup pair. |
| **No history file for … Initialize a first snapshot explicitly** / **Initialize post history?** | An older notebook without a history file. Yes creates a first history from the current posts; earlier edits can't be recovered. |
| **Existing database is schema v…; requires an EXPLICIT side-by-side migration** | Run `python3 app/schema_migrations.py plan SOURCE`, then `… migrate SOURCE NEW_DESTINATION`. |
| **Cannot import PVS. Choose the PVS "src" folder** | Point the wiki at the folder that contains `fd_oop_reconstruction`, or set `PVS_SRC`. |
| **… is not a PVS workspace (no objects/ folder)** | Choose the folder that contains `objects/`, usually named `db`. |
| **… belong(s) to PVS. Change it in PVS, then refresh.** / **… comes from PVS** / **Only Refresh from PVS creates posts tagged "pvs"** | Parts of PVS posts that PVS owns (chapter 11.2). Edit the text or status instead, or make the change in PVS and refresh. |
| **This notebook follows PVS workspace … this is a different workspace** | A notebook follows one workspace, recognised by identity. Use another notebook for another workspace. |
| **The PVS workspace is no longer at …** | It moved. Choose where it is now; the notebook checks it's the same workspace. |
| **Not a PVS snapshot** / **Unsupported PVS snapshot version** | The file wasn't written by `tools/pvs_export.py`, or by a newer version of it. |
| **… checksum does not match the manifest** / **Not a PERSONAL.WIKI notebook bundle** | The bundle is damaged or isn't a bundle. Nothing was written. Use another copy. |
| **A notebook (or its history file) already exists there** | Restore and export never overwrite. Choose a new name. |
| **Change log chain BROKEN** | An entry is missing, out of order, or changed after the next one linked it. Restore your last verified backup pair. |
| **Import rolled back** | Nothing from that file was kept. The message names the first problem. |
| **Finish the import before …** | An import is still running in the background. Wait for its message. |

---

## 14. Keyboard shortcuts

| Keys | Action |
|---|---|
| Ctrl+N | New post |
| Ctrl+Shift+P | New project item |
| Ctrl+T | New from template (forms) |
| Ctrl+Shift+R | Refresh from PVS |
| Ctrl+E | Edit post |
| Ctrl+Shift+D | Delete post |
| Ctrl+D | Project dashboard |
| Ctrl+O | Open notebook |
| Ctrl+Shift+N | New notebook |
| Ctrl+I | Import JSON |
| Ctrl+Shift+E | Export JSON |
| Ctrl+Shift+A | Show all posts |
| Ctrl+Shift+T | Show all tags |
| Alt+Left / Alt+Right | Back / forward |
| Ctrl+Q | Quit |

On macOS, Ctrl is ⌘.

---

## 15. Limits

- **Single user, on your own machine.** There is no login. An acknowledgement
  records *that* the owner agreed, not *who* agreed.
- **History detects accidents, not attacks.** Digests cover post contents, but
  reasons and timestamps aren't chained. Someone with file access could edit a
  reason, or remove the complete history of a deleted post, without the
  verification noticing. Hardening is planned for a later release.
- **Contracts check fields, not text.** The ratchet is a conservative sufficient
  check. It never accepts a loosening as a tightening, but sometimes asks about
  a tightening.
- **The renderer supports a subset of TiddlyWiki.** It doesn't run widgets or
  macros beyond the supported discussion-list filter.
- **The wiki never writes to PVS** and never loads PVS code. A refresh runs a
  separate export program and reads its JSON; anything going back to PVS, you
  enter yourself.
- **Bundles are as safe as where you keep them.** They are checked on restore,
  but a bundle is not encrypted. Anyone with the file can read the notebook.
- **Status is the only field synced in both directions.** Structure (`parent`),
  PVS content and identifiers come from PVS only.
- **The newest change-log entry isn't protected yet**, so deleting it isn't
  caught by the chain (its deletion is still in its post history).
- The desktop GUI was tested on Linux. Windows, macOS and Raspberry Pi
  desktops haven't been acceptance-tested.
