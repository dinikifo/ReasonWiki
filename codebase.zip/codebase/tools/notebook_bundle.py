#!/usr/bin/env python3
"""Back up, inspect and restore PERSONAL.WIKI notebooks as single bundle files.

    python3 tools/notebook_bundle.py export  MY_WIKI_DATA/personal_wiki.db  backups/wiki-2026-11-09.pwbundle
    python3 tools/notebook_bundle.py inspect backups/wiki-2026-11-09.pwbundle
    python3 tools/notebook_bundle.py restore backups/wiki-2026-11-09.pwbundle  elsewhere/personal_wiki.db

export   verifies the notebook and writes one bundle (never overwrites).
inspect  checks a bundle's manifest and checksums and prints its summary.
restore  verifies the bundle and its history, then creates a NEW notebook pair.

Suitable for scheduled backups (cron, Task Scheduler). Exit code 0 on success,
2 on any refusal, with the reason on standard error.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'app'))

import bundle  # noqa: E402
from wiki_core import WikiCore  # noqa: E402


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest='command', required=True)
    e = sub.add_parser('export', help='write a bundle of a notebook')
    e.add_argument('notebook')
    e.add_argument('bundle')
    i = sub.add_parser('inspect', help='check a bundle and print its manifest')
    i.add_argument('bundle')
    r = sub.add_parser('restore', help='restore a bundle as a new notebook')
    r.add_argument('bundle')
    r.add_argument('notebook')
    args = parser.parse_args(argv)
    try:
        if args.command == 'export':
            with WikiCore(args.notebook) as wiki:
                result = wiki.export_bundle(args.bundle)
        elif args.command == 'inspect':
            result = bundle.read_manifest(args.bundle)
        else:
            result = WikiCore.restore_bundle(args.bundle, args.notebook)
    except Exception as exc:  # one clear refusal message for scripts
        print(f'notebook_bundle: {exc}', file=sys.stderr)
        return 2
    print(json.dumps(result, indent=2, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
