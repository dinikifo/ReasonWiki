#!/usr/bin/env python3
"""Export a PVS-01 workspace as a read-only JSON snapshot ("pvs-snapshot" v1).

    python3 tools/pvs_export.py --pvs-src PATH/TO/pvs/src WORKSPACE [-o snapshot.json]

This is the only program that loads PVS code; PERSONAL.WIKI reads the JSON it
writes and never imports PVS. It reads every object at one consistent pin
(under the PVS writer lock), validates each versioning tree with PVS's own
rules, and changes nothing. It refuses a folder that is not already a PVS
workspace.

The output is PVS's own domain data, not wiki posts: what PVS knows, so the
format is a contract owned by the PVS side. It is meant to move into PVS
itself later unchanged; it lives here because the current PVS gate (IF00)
allows no PVS source changes.

Format (stable keys, sorted output):

  {"format": "pvs-snapshot", "version": 1, "exported_at": ISO-8601 UTC,
   "workspace": {"id": sha256 of the objects' genesis digests, "root": path},
   "objects": [{"object_id", "contract", "revision", "pin_seq", "pin_digest",
                "genesis_digest", "verdict", "data"}]}

The workspace id does not depend on the folder path, so a moved or restored
workspace is recognised as the same one.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys

FORMAT, VERSION = 'pvs-snapshot', 1


class ExportError(RuntimeError):
    pass


def _import_pvs(pvs_src: str | None):
    src = pvs_src or os.environ.get('PVS_SRC')
    if src:
        src_path = Path(src).expanduser().resolve()
        if not (src_path / 'fd_oop_reconstruction' / 'pvs').is_dir():
            raise ExportError(f'Cannot import PVS: {src_path} does not contain fd_oop_reconstruction/pvs. '
                              'Pass --pvs-src or set PVS_SRC.')
        sys.path.insert(0, str(src_path))
    try:
        from fd_oop_reconstruction.original import ContractCatalog
        from fd_oop_reconstruction.directory_store import DirectoryObjectStore
        from fd_oop_reconstruction.pvs.model import register_pvs_contracts, validate_tree
    except ImportError as exc:
        raise ExportError('Cannot import PVS. Pass --pvs-src (the folder containing '
                          'fd_oop_reconstruction) or set PVS_SRC.') from exc
    return ContractCatalog, DirectoryObjectStore, register_pvs_contracts, validate_tree


def export_snapshot(workspace: str | Path, pvs_src: str | None = None) -> dict:
    root = Path(workspace).expanduser()
    if root.is_symlink() or not (root / 'objects').is_dir():
        raise ExportError(f'{root} is not a PVS workspace (no objects/ folder). '
                          'Choose the folder passed to PVSWorkspace(...), usually "db".')
    ContractCatalog, DirectoryObjectStore, register, validate_tree = _import_pvs(pvs_src)
    catalog = ContractCatalog()
    register(catalog)
    store = DirectoryObjectStore(root, catalog)
    objects = []
    with store.locked():  # one consistent read: pins and states under the writer lock
        pins = [store.pin(oid) for oid in store.objects()]
        for pin in pins:
            history = store.history(pin.object_id, through=pin.seq)
            state = store.get(pin.object_id, pin=pin)
            verdict = store.verify(pin.object_id)
            if state['contract'] == 'pvs.inspect@1.0':
                validate_tree(state['data'])
            objects.append({'object_id': pin.object_id, 'contract': state['contract'],
                            'revision': state['revision'], 'pin_seq': pin.seq, 'pin_digest': pin.digest,
                            'genesis_digest': history[0]['digest'],
                            'verdict': getattr(verdict.status, 'value', str(verdict.status)),
                            'data': state['data']})
    if not any(o['contract'] == 'pvs.inspect@1.0' for o in objects):
        raise ExportError('No PVS versioning object found in this workspace')
    identity = hashlib.sha256(json.dumps(sorted((o['object_id'], o['genesis_digest']) for o in objects),
                                         separators=(',', ':')).encode()).hexdigest()
    return {'format': FORMAT, 'version': VERSION,
            'exported_at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
            'workspace': {'id': identity, 'root': str(root.resolve())}, 'objects': objects}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('workspace', help='PVS workspace folder (contains objects/)')
    parser.add_argument('--pvs-src', help='PVS src folder (contains fd_oop_reconstruction); or set PVS_SRC')
    parser.add_argument('-o', '--output', help='write here instead of standard output (refuses to overwrite)')
    args = parser.parse_args(argv)
    try:
        snapshot = export_snapshot(args.workspace, args.pvs_src)
    except Exception as exc:  # report every failure the same way to the calling process
        print(f'pvs_export: {exc}', file=sys.stderr)
        return 2
    text = json.dumps(snapshot, ensure_ascii=False, sort_keys=True, indent=1)
    if args.output:
        out = Path(args.output)
        if out.exists():
            print(f'pvs_export: refusing to overwrite {out}', file=sys.stderr)
            return 2
        out.write_text(text, encoding='utf-8')
    else:
        sys.stdout.write(text)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
