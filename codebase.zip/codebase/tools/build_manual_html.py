#!/usr/bin/env python3
"""Render docs/USER_MANUAL.md to a single self-contained docs/USER_MANUAL.html.

Images are embedded, so the HTML file can be read or shared on its own.
Requires the 'markdown' package (pip install markdown).
"""
from __future__ import annotations

import base64
from pathlib import Path
import re

import markdown

DOCS = Path(__file__).resolve().parents[1] / 'docs'

CSS = """
:root { --fg:#1f2933; --muted:#616e7c; --line:#e4e7eb; --accent:#2563eb; --bg:#ffffff; --code:#f5f7fa; }
@media (prefers-color-scheme: dark) { :root { --fg:#e4e7eb; --muted:#9aa5b1; --line:#323f4b; --accent:#7aa7ff; --bg:#111827; --code:#1f2933; } }
body { font: 16px/1.6 -apple-system, "Segoe UI", Roboto, sans-serif; color:var(--fg); background:var(--bg);
       max-width: 920px; margin: 0 auto; padding: 24px 16px 80px; }
h1 { font-size: 2em; margin-top: .4em; } h2 { margin-top: 2.2em; padding-top: .6em; border-top: 1px solid var(--line); }
h3 { margin-top: 1.6em; } a { color: var(--accent); }
code { background: var(--code); padding: 1px 5px; border-radius: 4px; font-size: .92em; }
pre { background: var(--code); padding: 12px 14px; border-radius: 6px; overflow-x: auto; } pre code { padding: 0; }
table { border-collapse: collapse; width: 100%; margin: 1em 0; font-size: .95em; display: block; overflow-x: auto; }
th, td { border: 1px solid var(--line); padding: 6px 10px; text-align: left; vertical-align: top; }
th { background: var(--code); }
img { max-width: 100%; border: 1px solid var(--line); border-radius: 6px; margin: .5em 0 1em; }
hr { border: none; border-top: 1px solid var(--line); margin: 2em 0; }
"""


def main() -> None:
    text = (DOCS / 'USER_MANUAL.md').read_text(encoding='utf-8')
    body = markdown.markdown(text, extensions=['tables', 'fenced_code', 'toc', 'sane_lists'])

    def embed(match: re.Match) -> str:
        src = match.group(1)
        path = DOCS / src
        data = base64.b64encode(path.read_bytes()).decode('ascii')
        return f'src="data:image/png;base64,{data}"'

    body = re.sub(r'src="(images/[^"]+\.png)"', embed, body)
    html = ('<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            f'<title>PERSONAL.WIKI User Manual</title><style>{CSS}</style></head><body>{body}</body></html>')
    out = DOCS / 'USER_MANUAL.html'
    out.write_text(html, encoding='utf-8')
    print(out, f'{len(html)//1024} KB')


if __name__ == '__main__':
    main()
