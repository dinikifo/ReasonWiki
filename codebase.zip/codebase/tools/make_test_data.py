#!/usr/bin/env python3
"""Build PERSONAL.WIKI test data for the user manual's walkthrough.

    python3 tools/make_test_data.py                  # creates ./TEST_DATA
    python3 tools/make_test_data.py --out /some/dir  # elsewhere (must not exist)
    PVS_SRC=/path/to/pvs/src python3 tools/make_test_data.py   # also builds PVS data

Everything is written through the normal WikiCore API, so posts carry real
version histories (edits, a rename, an acknowledged contract change, a delete
and a restore). Due dates are relative to --today (default: the real date) so
"overdue" and "due this week" stay meaningful whenever you generate the data.

Output (never overwrites an existing folder):
  notebook/test_notebook.db (+ .history.sqlite)  every dashboard section populated
  import/01..05_*.json                            import scenarios (see README there)
  pvs/workspace/                                  a PVS-01 workspace      (PVS_SRC only)
  pvs/pvs_loop.db (+ .history.sqlite)             two-way loop, refreshed twice (PVS_SRC only)
  pvs/pvs_archive.db (+ .history.sqlite)          read-only archive copy  (PVS_SRC only)
"""
from __future__ import annotations

import argparse
from datetime import date, timedelta
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'app'))

from wiki_core import WikiCore  # noqa: E402

PROTECTED_BRIEF = {
    'title': 'Client brief (original)',
    'tags': 'evidence [[Website Relaunch]]',
    'source': 'email from client, 2026-10-01',
    'text': "! Original brief\n\nAs received. ''Do not edit'' — this record is protected.\n\n"
            "* Faster pages\n* Accessible colours\n* Keep the old URLs working\n",
}


def build_notebook(path: Path, today: date) -> dict:
    d = lambda n: (today + timedelta(days=n)).isoformat()  # noqa: E731
    WikiCore.create_database(path)
    with WikiCore(path) as w:
        w.install_project_kit(reason='Test data: project kit')

        # --- Contract changes: one free tightening, one acknowledged ---------
        task = w.field_schemas()['task']
        task['properties']['estimate'] = {'type': 'string', 'format': 'number'}
        w.save_field_schema('task', task, reason='Track effort estimates in hours')

        def item(title, kind, status, parent=None, due=None, priority=None, text='', **extra):
            fields = {'status': status}
            if parent: fields['parent'] = parent
            if due: fields['due'] = due
            if priority: fields['priority'] = priority
            fields.update(extra)
            w.save_tiddler(title, text, [kind], fields=fields)

        # --- Project 1: mixed progress, overdue, blocked, due soon ------------
        item('Website Relaunch', 'project', 'active', due=d(30), priority='high',
             text='Relaunch the company site with the new design.\n\nSee [[Client brief (original)]] '
                  'and [[Meeting notes — kickoff]].\n')
        item('New design', 'goal', 'active', parent='Website Relaunch')
        item('Mockups approved', 'milestone', 'done', parent='New design')
        item('Pick colour palette', 'task', 'done', parent='Mockups approved', estimate='2')
        item('Build landing page', 'task', 'planned', parent='New design', due=d(3),
             priority='medium', estimate='6')
        item('Accessibility review', 'task', 'blocked', parent='New design', due=d(-4),
             priority='high', text='Waiting for the external auditor.\n')
        item('Content migration', 'goal', 'planned', parent='Website Relaunch')
        item('Export old posts', 'task', 'planned', parent='Content migration', due=d(-1))
        item('Redirect map', 'task', 'dropped', parent='Content migration',
             text='Not needed: URLs stay the same.\n')

        # --- Project 2: deeper tree -----------------------------------------
        item('Thesis Chapter 3', 'project', 'active', due=d(60), priority='high')
        item('Literature review', 'goal', 'done', parent='Thesis Chapter 3')
        item('Read core papers', 'task', 'done', parent='Literature review', estimate='12')
        item('Experiments', 'goal', 'active', parent='Thesis Chapter 3')
        item('Pilot run', 'milestone', 'active', parent='Experiments', due=d(7))
        item('Prepare dataset', 'task', 'done', parent='Pilot run', estimate='4')
        item('Run baseline', 'task', 'planned', parent='Pilot run', estimate='3')

        # --- Small cases ------------------------------------------------------
        item('Home Server', 'project', 'planned', text='No goals yet — shows a project with no items.\n')
        item('Renew domain', 'task', 'planned', due=d(10), text='Not under any project.\n')
        item('Fix printer', 'task', 'planned', parent='Office setup',
             text="Its parent ''Office setup'' does not exist.\n")
        item('Chicken', 'goal', 'planned')
        item('Egg', 'goal', 'planned', parent='Chicken')
        w.update_tiddler('Chicken', 'Chicken', '', ['goal'], reason='Test data: make a parent cycle',
                         fields={'status': 'planned', 'parent': 'Egg'})

        # --- History: edits and a rename on one task --------------------------
        w.update_tiddler('Build landing page', 'Build landing page',
                         'Hero section and sign-up form.\n', ['task'], reason='Started work',
                         fields={'status': 'active', 'parent': 'New design', 'due': d(3),
                                 'priority': 'medium', 'estimate': '6'})
        w.update_tiddler('Build landing page', 'Build the landing page',
                         'Hero section, sign-up form and footer.\n', ['task'],
                         reason='Clearer title; added footer', fields={
                             'status': 'active', 'parent': 'New design', 'due': d(3),
                             'priority': 'medium', 'estimate': '8'})

        # --- History: delete then restore (comes back as a new post) ---------
        item('Old blog theme', 'project', 'active', text='Keep the 2019 theme alive.\n')
        old = [p for p in w.history_posts() if p['last_title'] == 'Old blog theme'][0]['post_id']
        w.delete_tiddler('Old blog theme', reason='Dropped with the relaunch')
        delete_event = w.post_history(old)[-1]['event_id']
        w.restore_version(old, delete_event, reason='Keep it as a record of what we dropped')
        w.update_tiddler('Old blog theme', 'Old blog theme', 'Superseded by [[Website Relaunch]].\n',
                         ['project'], reason='Mark as dropped', fields={'status': 'dropped'})
        w.save_tiddler('Scratch idea', 'Delete me.', [])
        w.delete_tiddler('Scratch idea', reason='Test data: a deleted post that stays deleted')

        # --- Acknowledged tightening that leaves a violation ------------------
        milestone = w.field_schemas()['milestone']
        milestone['required'] = ['status', 'due']
        w.save_field_schema('milestone', milestone, reason='Every milestone needs a date',
                            acknowledge_contract_change=True)

        # --- Plain notes and protected evidence --------------------------------
        w.save_tiddler('Meeting notes — kickoff',
                       "! Kickoff\n\n* Agreed scope: [[New design]] and [[Content migration]]\n"
                       "* Risk: [[Accessibility review]] depends on an external auditor\n\n"
                       "|!Who |!Action |\n|Me |Draft landing page |\n|Client |Send logo files |\n",
                       ['meeting', 'Website Relaunch'])
        w.save_tiddler('Reading list', "* //Designing Data-Intensive Applications//\n"
                       "* //A Philosophy of Software Design//\n", ['reading'])
        src = path.parent / '_brief.json'
        src.write_text(json.dumps([PROTECTED_BRIEF], ensure_ascii=False), encoding='utf-8')
        try:
            w.import_json(src, protect_imported=True)
        finally:
            src.unlink()
        build_forms(w, d)
        w.update_change_log()
        overview = w.project_overview(today)
        verified = w.verify_history()
    return {'posts': verified['active_posts'], 'events': verified['events'],
            'projects': len(overview['projects']), 'overdue': overview['overdue'],
            'violations': [v['title'] for v in overview['violations']]}


def build_forms(w, d) -> None:
    """One or more posts of every form, linked to the test projects."""
    w.install_forms_kit(reason='Test data: forms kit')
    T = lambda claim, grounds, warrant, **more: dict(claim=claim, grounds=grounds, warrant=warrant, **more)  # noqa: E731
    w.save_tiddler('5W1H — Website Relaunch', '! 5W1H\n\nScope agreed at the kickoff.\n', ['5w1h'], fields=dict(
        project='Website Relaunch', who='Me, with client sign-off', what='Relaunch the site on the new design',
        when='Before the December campaign', where='Production site and staging', why='Old site is slow '
        'and fails accessibility checks', how='New design first, then migrate content', qualifier='likely',
        **T('The relaunch is worth doing before December', 'Page loads take 6 s; 14 accessibility errors',
            'Campaign traffic will land on these pages', backing='Client analytics for last campaign')))
    w.save_tiddler('5 Whys — Accessibility review blocked',
                   '! 5 Whys\n\n# Why blocked? The auditor has not started.\n'
                   '# Why? We booked them after the design was final.\n'
                   '# Why? The plan put the audit in the last phase.\n'
                   '# Why? We treated accessibility as a check, not a design input.\n', ['five-whys'], fields=dict(
        project='Website Relaunch', problem='Accessibility review is blocked and overdue',
        root_cause='Accessibility was planned as a final check, not a design input',
        countermeasure='Book audits at design start; add colour-contrast checks to each mockup',
        qualifier='provisional', **T('Booking audits earlier prevents this block',
                                     'The block traces to scheduling, not to the auditor',
                                     'Removing the late dependency removes the wait',
                                     rebuttal='Unless the auditor is unavailable at design time too')))
    w.save_tiddler('A3 — Website Relaunch', '! A3\n\n!! 1. Background\n\nCampaign in December.\n\n'
                   '!! 2. Current condition\n\n6 s loads, 14 accessibility errors.\n\n'
                   '!! 3. Goal\n\nUnder 2 s, zero errors.\n\n!! 4. Root cause analysis\n\n'
                   'See [[5 Whys — Accessibility review blocked]].\n', ['a3'], fields=dict(
        project='Website Relaunch', a3_status='in-progress', review_date=d(7), qualifier='likely',
        **T('The relaunch will meet its targets if the audit moves earlier',
            'Design is 29% done; the only blocker is the audit', 'Remaining work is unblocked otherwise')))
    w.save_tiddler('ADR — Keep the old URLs', '! Decision\n\n!! Context\n\nInbound links from partners.\n\n'
                   '!! Decision\n\nKeep every existing URL.\n\n!! Alternatives considered\n\n'
                   '* A redirect map ([[Redirect map]])\n\n!! Consequences\n\nNo redirects to maintain.\n',
                   ['adr'], fields=dict(project='Website Relaunch', adr_status='accepted', decided=d(-6),
        qualifier='certain', **T('Keep the old URLs', 'Partners link to 40 deep URLs',
                                 'Unchanged URLs cannot break inbound links',
                                 backing='Search ranking guidance on stable URLs')))
    w.save_tiddler('Argument — The redirect map is unnecessary', 'See [[ADR — Keep the old URLs]].\n',
                   ['argument'], fields=dict(stance='support', responds_to='ADR — Keep the old URLs',
        about='Redirect map', project='Website Relaunch', qualifier='likely',
        **T('The redirect map can be dropped', 'No URL changes in the new design',
            'A redirect map only matters when URLs change')))
    w.save_tiddler('PDCA — Thesis Chapter 3 — cycle 1', '! PDCA\n\n!! Plan\n\nSmaller dataset first.\n\n'
                   '!! Do\n\nRan the pilot on 10%.\n\n!! Check\n\nBaseline variance too high.\n',
                   ['pdca'], fields=dict(project='Thesis Chapter 3', cycle='1', pdca_phase='check',
        metric='Variance of baseline accuracy across 5 seeds', qualifier='provisional',
        **T('A 10% pilot is too small to compare models', 'Seed variance exceeds the expected effect',
            'An effect smaller than the noise cannot be measured')))
    w.save_tiddler('Kanban — Website Relaunch', '! Kanban board\n\n!! Policies\n\n'
                   '* One card in Doing at a time\n', ['kanban'], fields=dict(
        scope='Website Relaunch', wip_limit='1', qualifier='likely',
        **T('Limiting Doing to one card finishes work sooner', 'Two parallel tasks both slipped last month',
            'Less switching means each task finishes sooner')))
    w.save_tiddler('Waterfall — Thesis Chapter 3', '! Waterfall plan\n\nGate decisions are in the history.\n',
                   ['waterfall'], fields=dict(scope='Thesis Chapter 3', phase='implementation',
        requirements_end=d(-30), design_end=d(-10), implementation_end=d(-2), verification_end=d(40),
        qualifier='provisional', **T('The chapter can still finish on time', 'Only implementation is late',
                                     'Verification has 40 days of slack')))
    for offset, done in ((-1, 'Drafted the A3'), (0, 'Ran pilot check')):
        w.save_tiddler(f'Daily — {d(offset)}', f'! Daily log\n\n!! Done\n\n* {done}\n', ['daily'],
                       fields=dict(date=d(offset), qualifier='certain',
                                   **T(f'{done} moved the work forward', 'It unblocked the next step',
                                       'Unblocking is progress')))


IMPORTS = {
    '01_valid_tasks.json': [
        {'title': 'Write results section', 'tags': 'task', 'status': 'planned',
         'parent': 'Experiments', 'estimate': '5', 'text': 'Imported task.'},
        {'title': 'Make figures', 'tags': 'task', 'status': 'planned',
         'parent': 'Experiments', 'priority': 'low', 'text': 'Imported task.'},
    ],
    '02_invalid_status.json': [
        {'title': 'Good imported task', 'tags': 'task', 'status': 'planned',
         'parent': 'Experiments', 'text': ''},
        {'title': 'Bad imported task', 'tags': 'task', 'status': 'in progress',
         'parent': 'Experiments', 'text': ''},
    ],
    '03_bring_own_contract.json': [
        {'title': 'Login button misaligned', 'tags': 'bug', 'severity': 'minor',
         'status': 'planned', 'text': 'On mobile only.'},
        {'title': '$:/schema/bug', 'type': 'application/json', 'tags': '$:/tags/FieldContract',
         'text': json.dumps({'type': 'object', 'required': ['severity'], 'properties': {
             'severity': {'type': 'string', 'enum': ['minor', 'major', 'critical']}}}, indent=2)},
        {'title': 'Checkout crashes', 'tags': 'bug', 'severity': 'critical', 'status': 'active',
         'text': 'Reproducible with an empty cart.'},
    ],
    '04_loosen_task_contract.json': None,  # built from the live contract below
    '05_overwrite_protected.json': [dict(PROTECTED_BRIEF, text='Edited brief.')],
}

IMPORT_README = """# Import scenarios

Open notebook/test_notebook.db, then File → Import JSON… with each file.
Expected results (also in the user manual, chapter "Walkthrough"):

| File | Answer the dialogs | Expected |
|---|---|---|
| 01_valid_tasks.json | No (reject conflicts), No (don't protect) | 2 posts committed; they appear under Thesis Chapter 3 → Experiments |
| 02_invalid_status.json | No, No | Rolled back: "'in progress' is not one of ..."; neither post exists |
| 03_bring_own_contract.json | No, No | 3 posts committed; the batch carries its own contract for tag `bug` |
| 04_loosen_task_contract.json | Yes (replace), reason, No | Asks to acknowledge loosening; Yes → committed and marked acknowledged |
| 05_overwrite_protected.json | Yes (replace), reason, No | Rolled back: the original brief is protected |
"""


def build_imports(folder: Path, notebook: Path) -> None:
    folder.mkdir()
    with WikiCore(notebook, readonly=True) as w:
        task = w.get_tiddler('$:/schema/task')
        loose = json.loads(task['text'])
        loose['properties']['status'] = {'type': 'string', 'minLength': 1}
        raw = {k: v for k, v in task.items() if k not in ('fields',)}
        raw.update(task['fields'])
        raw['tags'] = '$:/tags/FieldContract'
        raw['text'] = json.dumps(loose, indent=2)
    for name, records in IMPORTS.items():
        if records is None:
            records = [raw]
        (folder / name).write_text(json.dumps(records, indent=2, ensure_ascii=False), encoding='utf-8')
    (folder / 'README.md').write_text(IMPORT_README, encoding='utf-8')


def build_pvs(folder: Path, pvs_src: str) -> dict:
    sys.path.insert(0, pvs_src)
    from fd_oop_reconstruction.pvs import PVSWorkspace, argument
    folder.mkdir()
    code = folder / 'code'
    code.mkdir()
    (code / 'store.py').write_text('def save(x):\n    return x\n', encoding='utf-8')
    ws = PVSWorkspace(folder / 'workspace')
    ws.create_target('wiki-app', {'language': 'python', 'entry': 'store.py'})
    ws.create_versioner('versioner', 'dimitris')
    V, H = 'versioner', 'dimitris'
    ws.add_project(V, H, 'typed-fields', 'wiki-app', 'Add field contracts to the wiki')
    for_it = argument('Contracts catch bad data early', 'Status typos broke the dashboard',
                      'A checked field cannot hold an unknown status', backing='T06 tests')
    against = argument('Contracts add friction', 'Every new field needs a schema change',
                       'Friction slows quick notes', rebuttal='Untagged posts stay untyped')
    ws.add_rfc_argument(V, H, 'typed-fields', 'acceptance', for_it, 'Main argument')
    ws.add_rfc_argument(V, H, 'typed-fields', 'rejection', against, 'Recorded concern')
    ws.add_goal(V, H, 'typed-fields', 'acceptance', 'ratchet', 'Port the FD narrowing check', 'goal')
    ws.add_goal(V, H, 'typed-fields', 'acceptance', 'gui', 'Field editor in the GUI', 'goal')
    ws.add_goal(V, H, 'typed-fields', 'rejection', 'friction', 'Measure editing friction', 'evidence')
    ws.set_dependencies(V, H, 'typed-fields', 'gui', ['ratchet'], 'GUI needs the checker')
    ws.add_milestone(V, H, 'typed-fields', 'ratchet', 'ported', 'Checker ported')
    ws.decide(V, H, 'typed-fields', 'ACCEPTED', 'Benefits outweigh friction for tagged posts')
    ws.record_file(V, H, 'typed-fields', 'ported', code, 'store.py', for_it, 'Known-good source')
    ws.set_goal_status(V, H, 'typed-fields', 'ratchet', 'COMPLETE', 'Checker merged')
    ws.add_project(V, H, 'cloud-sync', 'wiki-app', 'Sync notebooks to a cloud drive')
    ws.add_rfc_argument(V, H, 'cloud-sync', 'rejection',
                        argument('SQLite pairs must stay together', 'Sync tools copy files one by one',
                                 'A half-synced pair is refused on open'), 'Why not')
    ws.decide(V, H, 'cloud-sync', 'REJECTED', 'Conflicts with the paired-database rule')
    archive = WikiCore.create_pvs_notebook(folder / 'pvs_archive.db', folder / 'workspace', pvs_src=pvs_src)
    return {'archive': archive, 'loop': build_pvs_loop(folder, ws, pvs_src)}


def build_pvs_loop(folder: Path, ws, pvs_src: str) -> dict:
    """A notebook that has been through the two-way loop twice.

    Refresh 1 → wiki edits (format, status first in the wiki, a disputed
    status, two arguments aimed at PVS) → PVS edits (one of the arguments
    entered, a new goal, the disputed status) → Refresh 2.
    """
    from fd_oop_reconstruction.pvs import argument
    V, H, P = 'versioner', 'dimitris', 'typed-fields'
    nb = folder / 'pvs_loop.db'
    WikiCore.create_database(nb)
    with WikiCore(nb) as w:
        w.install_forms_kit(reason='Test data: forms kit')
        w.refresh_from_pvs(folder / 'workspace', pvs_src=pvs_src)
        proj, gui, ratchet = f'PVS/{V}/{P}', f'PVS/{V}/{P}/gui', f'PVS/{V}/{P}/ratchet'
        post = w.get_tiddler(proj)
        w.update_tiddler(proj, proj, '! Typed fields — my notes\n\nThe checker is merged; the GUI is next. '
                         'See [[Argument — Start with a small checker]].\n', post['tags'],
                         reason='Formatted my own summary', fields=post['fields'])
        post = w.get_tiddler(gui)
        w.update_tiddler(gui, gui, post['text'], post['tags'], reason='Started the field editor',
                         fields=dict(post['fields'], status='active'))
        post = w.get_tiddler(ratchet)
        w.update_tiddler(ratchet, ratchet, post['text'], post['tags'], reason='Found a bug; blocked',
                         fields=dict(post['fields'], status='blocked'))
        w.save_tiddler('Argument — Start with a small checker', 'Drafted in the wiki, then entered in PVS.\n',
                       ['argument'], fields=dict(stance='support', pvs_target=proj, pvs_side='acceptance',
                                                 claim='Start with a small checker', grounds='Fewer moving parts',
                                                 warrant='Small code is easier to verify', qualifier='likely'))
        w.save_tiddler('Argument — The editor needs inline help', 'Still to enter in PVS.\n',
                       ['argument'], fields=dict(stance='support', pvs_target=gui, pvs_side='for',
                                                 claim='The field editor needs inline help',
                                                 grounds='Users mistype enum values',
                                                 warrant='Hints prevent invalid input', qualifier='provisional'))
    ws.add_rfc_argument(V, H, P, 'acceptance', argument('Start with a small checker', 'Fewer moving parts',
                                                        'Small code is easier to verify'), 'Entered from the wiki')
    ws.set_goal_status(V, H, P, 'ratchet', 'ACTIVE', 'Reopened for a follow-up')
    ws.add_goal(V, H, P, 'acceptance', 'docs', 'Document field contracts', 'New goal')
    with WikiCore(nb) as w:
        report = w.refresh_from_pvs()
        state = w.pvs_state()
        log = w.verify_change_log()
    return {'notebook': str(nb), 'new': report['new'], 'conflicts': [c['title'] for c in state['conflicts']],
            'to_enter': [t['title'] for t in state['to_enter']],
            'arguments_entered': len(state['reasoning_entered']),
            'arguments_pending': len(state['reasoning_pending']), 'change_log': log['entries']}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--out', default=str(ROOT / 'TEST_DATA'), help='output folder (must not exist)')
    parser.add_argument('--today', help='pretend today is YYYY-MM-DD (for reproducible screenshots)')
    parser.add_argument('--pvs-src', default=os.environ.get('PVS_SRC'), help='PVS-01 src folder')
    args = parser.parse_args(argv)
    out = Path(args.out)
    if out.exists():
        print(f'Refusing to overwrite {out}; choose another --out or move it away.', file=sys.stderr)
        return 2
    today = date.fromisoformat(args.today) if args.today else date.today()
    out.mkdir(parents=True)
    (out / 'notebook').mkdir()
    nb = out / 'notebook' / 'test_notebook.db'
    summary = build_notebook(nb, today)
    print('Notebook:', nb, summary)
    build_imports(out / 'import', nb)
    print('Import scenarios:', out / 'import')
    if args.pvs_src:
        print('PVS:', build_pvs(out / 'pvs', args.pvs_src))
    else:
        print('PVS data skipped (set PVS_SRC or --pvs-src to the PVS-01 src folder).')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
