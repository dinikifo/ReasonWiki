"""Typed post fields: a small JSON-schema subset with a one-way ratchet.

A post class is a tag. Its field contract lives in an ordinary post titled
``$:/schema/<tag>`` whose text is a JSON schema describing the post's custom
fields object. Because the contract is a post, every change to it is versioned
by the normal post history and needs a reason.

The ratchet (ported from Function-Data OOP ``schema_narrows_or_equals``):
tightening a contract is free; loosening it, or any change that cannot be
proved to be a tightening, needs explicit acknowledgement.

Supported keywords: type, properties, required, additionalProperties, items,
minLength, maxLength, minimum, maximum, enum, format.
``format`` applies to strings and is one of: date (YYYY-MM-DD), integer, number.
TiddlyWiki field values are strings, so ``format`` is how numbers and dates
are typed without breaking TiddlyWiki JSON compatibility.

Standard library only; no Qt.
"""
from __future__ import annotations

from datetime import date
import json
import re
from typing import Any, Mapping

SCHEMA_PREFIX = '$:/schema/'


class SchemaError(ValueError):
    """A contract is malformed, or a post's fields violate a contract."""


class ContractAcknowledgementRequired(PermissionError):
    """A contract change needs the owner's explicit acknowledgement because it
    loosens (or cannot be proved to tighten) a contract, removes a contract,
    or would leave existing posts in violation.

    Retry the same operation with ``acknowledge_contract_change=True``.
    """

    def __init__(self, message: str, *, tag: str = '', violations: list[str] | None = None):
        super().__init__(message)
        self.tag = tag
        self.violations = list(violations or [])


ALLOWED_TYPES = frozenset({'any', 'object', 'array', 'string', 'integer', 'number', 'boolean', 'null'})
SCHEMA_KEYS = frozenset({'type', 'properties', 'required', 'additionalProperties', 'items',
                         'minLength', 'maxLength', 'minimum', 'maximum', 'enum', 'format'})
FORMATS = frozenset({'date', 'integer', 'number'})
_INT_RE = re.compile(r'[+-]?\d+')
_NUM_RE = re.compile(r'[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?')


def schema_tag(title: str) -> str | None:
    """Return the tag governed by a schema post title, else None."""
    if isinstance(title, str) and title.startswith(SCHEMA_PREFIX) and len(title) > len(SCHEMA_PREFIX):
        return title[len(SCHEMA_PREFIX):]
    return None


def schema_title(tag: str) -> str:
    if not isinstance(tag, str) or not tag.strip():
        raise SchemaError('A schema needs a nonempty tag')
    return SCHEMA_PREFIX + tag


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def _types(schema: Mapping[str, Any]) -> list[str]:
    value = schema.get('type', 'any')
    return [value] if isinstance(value, str) else list(value)


def _type_set(schema: Mapping[str, Any]) -> set[str]:
    raw = set(_types(schema))
    if 'any' in raw:
        return set(ALLOWED_TYPES - {'any'})
    return raw


def check_schema(schema: Any, *, _depth: int = 0) -> None:
    """Validate the supported schema SUBSET (unknown keywords are refused)."""
    if _depth > 24:
        raise SchemaError('schema nesting is too deep')
    if type(schema) is not dict:
        raise SchemaError('schema must be a JSON object')
    unknown = set(schema) - SCHEMA_KEYS
    if unknown:
        raise SchemaError(f'unsupported schema keywords: {sorted(unknown)}')
    types = schema.get('type', 'any')
    types = [types] if type(types) is str else types
    if type(types) is not list or not types or any(type(t) is not str or t not in ALLOWED_TYPES for t in types):
        raise SchemaError('invalid schema type')
    if len(set(types)) != len(types):
        raise SchemaError('duplicate schema type')
    properties = schema.get('properties', {})
    if type(properties) is not dict:
        raise SchemaError('properties must be an object')
    for name, child in properties.items():
        if type(name) is not str or not name:
            raise SchemaError('property names must be nonempty strings')
        check_schema(child, _depth=_depth + 1)
    required = schema.get('required', [])
    if (type(required) is not list or any(type(x) is not str or not x for x in required)
            or len(set(required)) != len(required)):
        raise SchemaError('required must be a list of distinct nonempty names')
    if 'additionalProperties' in schema and type(schema['additionalProperties']) is not bool:
        raise SchemaError('additionalProperties must be true or false')
    if 'items' in schema:
        check_schema(schema['items'], _depth=_depth + 1)
    for key in ('minLength', 'maxLength'):
        if key in schema and (type(schema[key]) is not int or schema[key] < 0):
            raise SchemaError(f'{key} must be a nonnegative integer')
    if 'minLength' in schema and 'maxLength' in schema and schema['minLength'] > schema['maxLength']:
        raise SchemaError('minLength exceeds maxLength')
    for key in ('minimum', 'maximum'):
        if key in schema and type(schema[key]) not in (int, float):
            raise SchemaError(f'{key} must be numeric')
    if 'minimum' in schema and 'maximum' in schema and schema['minimum'] > schema['maximum']:
        raise SchemaError('minimum exceeds maximum')
    if 'format' in schema and schema['format'] not in FORMATS:
        raise SchemaError(f'format must be one of {sorted(FORMATS)}')
    if 'enum' in schema:
        values = schema['enum']
        if type(values) is not list or not values:
            raise SchemaError('enum must be a nonempty array')
        if len({_canonical(v) for v in values}) != len(values):
            raise SchemaError('duplicate enum values')
    try:
        json.dumps(schema, allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise SchemaError(f'schema is not plain JSON: {exc}') from exc


def _matches(value: Any, name: str) -> bool:
    if name == 'any':
        return True
    if name == 'object':
        return type(value) is dict
    if name == 'array':
        return type(value) is list
    if name == 'string':
        return type(value) is str
    if name == 'integer':
        return type(value) is int
    if name == 'number':
        return type(value) in (int, float)
    if name == 'boolean':
        return type(value) is bool
    return value is None


def _format_ok(value: str, fmt: str) -> bool:
    if fmt == 'integer':
        return _INT_RE.fullmatch(value) is not None
    if fmt == 'number':
        return _NUM_RE.fullmatch(value) is not None
    if fmt == 'date':
        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
            return False
        try:
            date.fromisoformat(value)
        except ValueError:
            return False
        return True
    return False


def validate(value: Any, schema: Mapping[str, Any], *, path: str = 'fields', _depth: int = 0) -> None:
    """Raise SchemaError if ``value`` violates ``schema``."""
    if _depth == 0:
        check_schema(schema)
    if _depth > 24:
        raise SchemaError('value nesting is too deep')
    types = _types(schema)
    if not any(_matches(value, t) for t in types):
        raise SchemaError(f'{path}: expected {" or ".join(types)}, got {type(value).__name__}')
    if 'enum' in schema and _canonical(value) not in {_canonical(x) for x in schema['enum']}:
        allowed = ', '.join(str(x) for x in schema['enum'])
        raise SchemaError(f'{path}: {value!r} is not one of: {allowed}')
    if type(value) is dict:
        missing = set(schema.get('required', [])) - set(value)
        if missing:
            raise SchemaError(f'{path}: missing required field(s): {", ".join(sorted(missing))}')
        props = schema.get('properties', {})
        for name, child in value.items():
            if name in props:
                validate(child, props[name], path=f'{path}.{name}', _depth=_depth + 1)
            elif schema.get('additionalProperties', True) is False:
                raise SchemaError(f'{path}: field {name!r} is not allowed by the contract')
    if type(value) is list and 'items' in schema:
        for i, child in enumerate(value):
            validate(child, schema['items'], path=f'{path}[{i}]', _depth=_depth + 1)
    if type(value) is str:
        if len(value) < schema.get('minLength', 0):
            raise SchemaError(f'{path}: shorter than {schema["minLength"]} characters')
        if 'maxLength' in schema and len(value) > schema['maxLength']:
            raise SchemaError(f'{path}: longer than {schema["maxLength"]} characters')
        if 'format' in schema and not _format_ok(value, schema['format']):
            raise SchemaError(f'{path}: {value!r} is not a valid {schema["format"]}')
    if type(value) in (int, float):
        if 'minimum' in schema and value < schema['minimum']:
            raise SchemaError(f'{path}: below minimum {schema["minimum"]}')
        if 'maximum' in schema and value > schema['maximum']:
            raise SchemaError(f'{path}: above maximum {schema["maximum"]}')


def is_valid(value: Any, schema: Mapping[str, Any]) -> bool:
    try:
        validate(value, schema)
        return True
    except SchemaError:
        return False


def narrows_or_equals(new: Mapping[str, Any], old: Mapping[str, Any]) -> bool:
    """Sufficient (sound, not complete) check that every value valid under
    ``new`` is valid under ``old``. False means loosening OR unproved.

    Difference from the FD original: a bound is only compared when the new
    schema still admits the type that bound applies to, so dropping a type
    from a union is recognized as a tightening.
    """
    check_schema(new)
    check_schema(old)
    if _canonical(new) == _canonical(old):
        return True
    if 'enum' in new:
        return all(is_valid(v, old) for v in new['enum'])
    if 'enum' in old:
        return False
    nt, ot = _type_set(new), _type_set(old)
    if not all(t in ot or (t == 'integer' and 'number' in ot) for t in nt):
        return False
    numeric = bool(nt & {'integer', 'number'})
    stringy = 'string' in nt
    for lower, upper, applies in (('minimum', 'maximum', numeric),
                                  ('minLength', 'maxLength', stringy)):
        if not applies:
            continue
        if lower in old and (lower not in new or new[lower] < old[lower]):
            return False
        if upper in old and (upper not in new or new[upper] > old[upper]):
            return False
    if stringy and 'format' in old and new.get('format') != old['format']:
        return False
    if 'object' in nt:
        if not set(old.get('required', [])).issubset(set(new.get('required', []))):
            return False
        op, np_ = old.get('properties', {}), new.get('properties', {})
        if old.get('additionalProperties', True) is False:
            if new.get('additionalProperties', True) is not False:
                return False
            if set(np_) - set(op):
                return False
        for key, old_child in op.items():
            if key not in np_:
                if new.get('additionalProperties', True) is not False:
                    return False
            elif not narrows_or_equals(np_[key], old_child):
                return False
    if 'array' in nt and 'items' in old:
        if 'items' not in new or not narrows_or_equals(new['items'], old['items']):
            return False
    return True


def parse_schema_text(text: str) -> dict:
    """Parse and check the JSON text of a ``$:/schema/<tag>`` post."""
    try:
        schema = json.loads(text)
    except (TypeError, ValueError) as exc:
        raise SchemaError(f'schema post text is not valid JSON: {exc}') from exc
    check_schema(schema)
    if 'object' not in _type_set(schema):
        raise SchemaError('a field contract must describe an object (type "object")')
    return schema


def describe(schema: Mapping[str, Any]) -> list[tuple[str, str, bool]]:
    """Human summary rows (field, constraint, required) for editor hints."""
    rows = []
    required = set(schema.get('required', []))
    for name, child in schema.get('properties', {}).items():
        bits = []
        if 'enum' in child:
            bits.append(' | '.join(str(v) for v in child['enum']))
        elif 'format' in child:
            bits.append(child['format'])
        else:
            bits.append('/'.join(_types(child)))
        if 'minLength' in child:
            bits.append(f'min {child["minLength"]} chars')
        if 'maxLength' in child:
            bits.append(f'max {child["maxLength"]} chars')
        rows.append((name, ', '.join(bits), name in required))
    for name in sorted(required - set(schema.get('properties', {}))):
        rows.append((name, 'any', True))
    return rows
