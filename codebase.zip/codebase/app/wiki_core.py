"""Qt-free public API for one independent PERSONAL.WIKI notebook.

The UI and command-line launchers should use this module, not SQLite tables,
connections or the history implementation. No PySide6 import is permitted here.

One notebook = one content SQLite v2 file and its companion history SQLite v1.
All persistence rules remain in db.py/history_db.py; render_tiddler is a pure
markup-to-HTML function in renderer.py. This facade is intentionally small.
"""
from __future__ import annotations

from contextlib import closing
import tempfile
from html import escape
from pathlib import Path
import re
import sqlite3
import sys
from urllib.parse import quote

from db import create_new_database as _create_content_database, _publish_temp
from history_db import (
    HistoryTiddlerDB, initialize_history as _initialize_history,
    history_path as _history_path,
)
import field_schema as _fs
from field_schema import ContractAcknowledgementRequired, SchemaError  # re-exported for UIs
import projects as _projects
import forms as _forms
import views as _views


__all__ = ['WikiCore', 'ContractAcknowledgementRequired', 'SchemaError']


class WikiCore:
    """One open notebook, independent of desktop UI frameworks.

    A caller owns and closes each instance. Open a separate instance in a
    background worker/thread; never share its SQLite connection across threads.
    """

    def __init__(self, path: str | Path, *, readonly: bool = False):
        self._db = HistoryTiddlerDB(str(path), readonly=readonly)
        self.db_path = str(path)
        self.readonly = readonly
        try:
            report = self._db.integrity_report()
            if (report['integrity'] != 'ok' or report['foreign_key_violations']
                    or not report['fts_matches']):
                raise ValueError('Database integrity or search index check failed: ' + str(report))
            protection = self._db.protection_report()
            if protection['violation_count']:
                raise ValueError('Protected evidence audit failed: ' + str(protection['violations']))
        except BaseException:
            self._db.close()
            raise

    @staticmethod
    def check_storage_environment() -> None:
        """Check Python/SQLite prerequisites without loading the desktop UI."""
        if sys.version_info < (3, 11):
            raise RuntimeError('Python 3.11+ is required')
        with closing(sqlite3.connect(':memory:')) as connection:
            connection.execute('CREATE VIRTUAL TABLE fts_probe USING fts5(text)')
            if connection.execute('SELECT json_valid(?)', ('{"ok":true}',)).fetchone()[0] != 1:
                raise RuntimeError('SQLite JSON support is missing')

    @staticmethod
    def history_file(path: str | Path) -> Path:
        return _history_path(str(path))

    @staticmethod
    def has_history(path: str | Path) -> bool:
        sidecar = _history_path(str(path))
        return sidecar.is_file() and not sidecar.is_symlink()

    @staticmethod
    def initialize_history(path: str | Path) -> Path:
        """Explicitly baseline an existing pre-history notebook."""
        return _initialize_history(str(path))

    @staticmethod
    def create_database(path: str | Path) -> None:
        """Create the content/history pair without publishing a partial setup.

        Stage and verify both files on the destination filesystem. Publication
        is no-clobber; a caught error cleans up only files created by this
        invocation. As two filenames cannot be published atomically, a sudden
        power loss between links may still leave an *obviously incomplete* pair
        which is refused on next open rather than silently reconstructed.
        """
        dest = Path(path)
        companion = _history_path(str(dest))
        if dest.exists() or dest.is_symlink() or companion.exists() or companion.is_symlink():
            raise FileExistsError('Content or history database already exists; refusing to replace')
        if not dest.parent.is_dir():
            raise FileNotFoundError(f'Database destination folder does not exist: {dest.parent}')
        with tempfile.TemporaryDirectory(prefix='.pw_create_pair_', dir=dest.parent) as tmp:
            staged = Path(tmp) / 'new.db'
            _create_content_database(str(staged))
            _initialize_history(str(staged))
            with WikiCore(staged, readonly=True) as check:
                if check.count() or not check.verify_history()['verified']:
                    raise ValueError('New database pair failed verification')
            created = []
            try:
                for source, target in ((staged, dest), (_history_path(str(staged)), companion)):
                    source_stat = source.stat()
                    # Include even a partially published link: a later
                    # directory-fsync failure must still clean it up safely.
                    created.append((target, source_stat.st_dev, source_stat.st_ino))
                    _publish_temp(str(source), target, overwrite=False)
            except BaseException:
                # A different process must never have its files deleted.
                for target, device, inode in reversed(created):
                    try:
                        stat = target.stat(follow_symlinks=False)
                        if (stat.st_dev, stat.st_ino) == (device, inode):
                            target.unlink()
                    except FileNotFoundError:
                        pass
                raise

    def close(self) -> None:
        self._db.close()

    def __enter__(self) -> 'WikiCore':
        return self

    def __exit__(self, *_args) -> None:
        self.close()

    def count(self) -> int:
        return self._db.count()

    def get_tiddler(self, title: str) -> dict | None:
        return self._db.get_tiddler(title)

    def is_protected(self, title: str) -> bool:
        return self._db.is_protected(title)

    def all_titles(self, limit: int = 200, offset: int = 0) -> list[str]:
        return self._db.all_titles(limit, offset)

    BROWSE_VIEWS = ('posts', 'projects', 'forms', 'system', 'all')

    def browse(self, view: str = 'posts', query: str = '', *, mode: str = 'Title',
               limit: int = 200, offset: int = 0) -> list[dict]:
        """Titles for the browse panel, each with a display label.

        posts: everything except $:/ system posts; projects: project items;
        forms: posts made from a form (kit or your own templates); system: $:/
        posts (contracts, templates…); all: everything. ``query``/``mode`` search
        within the view.
        """
        if view not in self.BROWSE_VIEWS:
            raise ValueError(f'Unknown view {view!r}')
        if mode not in ('Title', 'Text', 'Tag'):
            raise ValueError(f'Unsupported search mode: {mode!r}')
        form_tags = self.form_tags() if view == 'forms' else None
        filters = {'posts': dict(system=False), 'projects': dict(any_tags=_projects.KINDS),
                   'forms': dict(system=False, any_tags=form_tags), 'system': dict(system=True),
                   'all': {}}[view]
        titles = self._db.browse_titles(query=query, mode=mode, limit=limit, offset=offset, **filters)
        return [{'title': t, 'label': self._browse_label(view, t, form_tags)} for t in titles]

    def form_tags(self) -> set[str]:
        """Tags of every form: the kit's plus those named by your own templates."""
        tags = set(_forms.FORM_TAGS)
        for template in self.list_templates():
            post = self.get_tiddler(template['title'])
            tags.update((post.get('fields', {}).get('template_tags') or '').split())
        return tags

    def _browse_label(self, view: str, title: str, form_tags) -> str:
        if view == 'projects':
            post = self.get_tiddler(title)
            status = (post.get('fields') or {}).get('status')
            return f"{_projects.kind_of(post)} · {title}" + (f"  [{status}]" if isinstance(status, str) else '')
        if view == 'forms':
            post = self.get_tiddler(title)
            tag = next((t for t in post.get('tags', []) if t in form_tags), '')
            return f'{_forms.form_name(tag) or tag} · {title}'
        return title

    def all_tags(self) -> list[str]:
        return self._db.all_tags()

    def search(self, query: str = '', *, mode: str = 'Title', limit: int = 200,
               offset: int = 0) -> list[str]:
        """Search one notebook only; never query another wiki folder."""
        if not query.strip():
            return self._db.all_titles(limit, offset)
        if mode == 'Title':
            return self._db.search_title(query, limit, offset)
        if mode == 'Text':
            return self._db.search_text(query, limit, offset)
        if mode == 'Tag':
            return self._db.search_tag(query, limit, offset)
        raise ValueError(f'Unsupported search mode: {mode!r}')

    def save_tiddler(self, title: str, text: str, tags: list[str], *,
                     fields: dict | None = None, created: str | None = None,
                     reason: str | None = None, acknowledge_contract_change: bool = False) -> None:
        self._db.save_tiddler(title, text, tags, fields=fields, created=created, reason=reason,
                              acknowledge_contract_change=acknowledge_contract_change)

    def update_tiddler(self, old_title: str, new_title: str, text: str,
                       tags: list[str], *, reason: str, fields: dict | None = None,
                       acknowledge_contract_change: bool = False) -> bool:
        """Edit or rename. When ``fields`` is given it REPLACES all custom fields."""
        return self._db.update_tiddler(old_title, new_title, text, tags, reason=reason, fields=fields,
                                       acknowledge_contract_change=acknowledge_contract_change)

    def rename_tiddler(self, old_title: str, new_title: str, *, reason: str,
                       acknowledge_contract_change: bool = False) -> bool:
        return self._db.rename_tiddler(old_title, new_title, reason=reason,
                                       acknowledge_contract_change=acknowledge_contract_change)

    def delete_tiddler(self, title: str, *, reason: str,
                       acknowledge_contract_change: bool = False) -> bool:
        return self._db.delete_tiddler(title, reason=reason,
                                       acknowledge_contract_change=acknowledge_contract_change)

    def import_json(self, json_path: str | Path, *, on_conflict: str = 'reject',
                    protect_imported: bool = False, reason: str | None = None,
                    acknowledge_contract_change: bool = False) -> int:
        return self._db.import_json(str(json_path), on_conflict=on_conflict,
                                    protect_imported=protect_imported, reason=reason,
                                    acknowledge_contract_change=acknowledge_contract_change)

    def import_records(self, records: list[dict], *, on_conflict: str = 'reject',
                       protect_imported: bool = False, reason: str | None = None,
                       acknowledge_contract_change: bool = False) -> int:
        return self._db.import_records(records, on_conflict=on_conflict,
                                       protect_imported=protect_imported, reason=reason,
                                       acknowledge_contract_change=acknowledge_contract_change)

    # --- Typed fields (contracts) -------------------------------------
    def field_schemas(self) -> dict[str, dict]:
        """Contracts by tag, read from ``$:/schema/<tag>`` posts."""
        return self._db.field_schemas()

    def contract_violations(self) -> list[dict]:
        return self._db.contract_violations()

    def contract_hints(self, tags: list[str]) -> list[dict]:
        """Editor hints: one entry per governed tag with its field rows."""
        schemas = self.field_schemas()
        return [{'tag': t, 'rows': _fs.describe(schemas[t]),
                 'closed': schemas[t].get('additionalProperties') is False}
                for t in tags if t in schemas]

    def save_field_schema(self, tag: str, schema: dict, *, reason: str,
                          acknowledge_contract_change: bool = False) -> None:
        """Create or change the contract for ``tag`` (ratchet-checked)."""
        import json as _json
        _fs.check_schema(schema)
        title = _fs.schema_title(tag)
        text = _json.dumps(schema, indent=2, ensure_ascii=False)
        existing = self.get_tiddler(title)
        if existing is None:
            self.save_tiddler(title, text, ['$:/tags/FieldContract'], fields={'type': 'application/json'},
                              reason=reason, acknowledge_contract_change=acknowledge_contract_change)
        else:
            self.update_tiddler(title, title, text, existing.get('tags', []), reason=reason,
                                acknowledge_contract_change=acknowledge_contract_change)

    # --- Kits ---------------------------------------------------------
    def _install_kit(self, records: list[dict], reason: str) -> list[str]:
        """Add the kit posts that are missing, in one transaction. Never overwrites."""
        missing = [r for r in records if self.get_tiddler(r['title']) is None]
        if missing:
            self._db.import_records(missing, first_version_reason=reason)
        return [r['title'] for r in missing]

    def install_project_kit(self, *, reason: str = 'Install project kit') -> list[str]:
        """Contracts for project/goal/milestone/task and the guide post."""
        return self._install_kit(_projects.kit_records(), reason)

    def install_forms_kit(self, *, reason: str = 'Install forms kit') -> list[str]:
        """A template and a contract for every form, and the guide post."""
        return self._install_kit(_forms.kit_records(), reason)

    # --- Project tracking ---------------------------------------------

    def project_overview(self, today=None) -> dict:
        return _projects.overview(self, today)

    def render_dashboard(self, today=None) -> str:
        overview = self.project_overview(today)
        overview['pvs'] = self.pvs_state()
        return _views.dashboard(overview)

    def render_pvs_sync(self) -> str:
        return _views.pvs_sync_page(self.pvs_state())

    def render_contracts(self) -> str:
        return _views.contracts(self)

    # --- Forms ------------------------------------------------------------
    def list_templates(self) -> list[dict]:
        return _forms.list_templates(self)

    def preset_from_template(self, template: str, *, project: str | None = None, today=None) -> dict:
        return _forms.preset_from_template(self, template, project=project, today=today)

    # --- Low-level helpers used by the sync and change log -------------------
    def raw_record(self, title: str) -> dict | None:
        """The stored TiddlyWiki object exactly as saved (fields at top level)."""
        return self._db._get_raw(title)

    def write_batch(self, changes: list[dict], *, managed: bool = False) -> int:
        return self._db.write_batch(changes, managed=managed)

    def events_since(self, event_id: int = 0) -> list[dict]:
        return self._db.events_since(event_id)

    def titles_with_field(self, name: str) -> list[str]:
        return self._db.titles_with_field(name)

    # --- Two-way PVS workflow ------------------------------------------------
    def refresh_from_pvs(self, pvs_root: str | Path | None = None, *, pvs_src: str | None = None,
                         snapshot_file: str | Path | None = None) -> dict:
        """Read PVS into this notebook and reconcile (see pvs_sync). Never writes to PVS
        and never loads PVS code in this process."""
        import pvs_sync
        self.install_project_kit()
        return pvs_sync.refresh(self, pvs_root, pvs_src=pvs_src, snapshot_file=snapshot_file)

    def pvs_state(self) -> dict:
        import pvs_sync
        return pvs_sync.state(self)

    def resolve_pvs_conflict(self, title: str, choice: str, *, reason: str) -> dict:
        import pvs_sync
        return pvs_sync.resolve(self, title, choice, reason=reason)

    # --- Bundles (backup, move, restore) -----------------------------------------
    def export_bundle(self, path: str | Path) -> dict:
        """Write one verified .pwbundle file holding this notebook pair. Never overwrites."""
        import bundle
        return bundle.export_bundle(self, path)

    @staticmethod
    def restore_bundle(bundle_path: str | Path, dest_path: str | Path) -> dict:
        """Verify a bundle and unpack it as a NEW notebook pair. Never overwrites."""
        import bundle
        return bundle.restore_bundle(bundle_path, dest_path)

    # --- Change log ---------------------------------------------------------
    def update_change_log(self) -> list[str]:
        """Write daily change-log entries for edits not yet logged."""
        import changelog
        return changelog.catch_up(self)

    def verify_change_log(self) -> dict:
        import changelog
        return changelog.verify(self)

    def titles_with_field_value(self, names, value: str, limit: int = 500) -> list[str]:
        return self._db.titles_with_field_value(names, value, limit)

    # --- Restore --------------------------------------------------------
    def restore_version(self, post_id: str, event_id: int, *, reason: str,
                        acknowledge_contract_change: bool = False) -> dict:
        """Bring back a recorded version as a NEW version (history is never rewritten)."""
        return self._db.restore_version(post_id, event_id, reason=reason,
                                        acknowledge_contract_change=acknowledge_contract_change)

    # --- PVS --------------------------------------------------------------
    @staticmethod
    def create_pvs_notebook(path: str | Path, pvs_root: str | Path, *,
                            pvs_src: str | None = None) -> dict:
        """Create a NEW notebook holding a protected, read-only PVS snapshot."""
        from pvs_bridge import snapshot_records
        records, summary = snapshot_records(pvs_root, pvs_src=pvs_src)
        WikiCore.create_database(path)
        try:
            with WikiCore(path) as wiki, wiki._db.managed_writes():
                wiki._db.import_records(
                    _projects.kit_records() + records, protect_imported=True,
                    first_version_reason=f"PVS snapshot of {summary['root']} taken {summary['taken']}")
                summary['verified'] = wiki.verify_history()['verified']
                summary['violations'] = len(wiki.contract_violations())
        except BaseException:
            for leftover in (Path(path), _history_path(str(path))):
                try:
                    leftover.unlink()
                except FileNotFoundError:
                    pass
            raise
        summary['notebook'] = str(path)
        return summary

    def export_json(self, json_path: str | Path, *, overwrite: bool = False) -> int:
        return self._db.export_json(str(json_path), overwrite=overwrite)

    def snapshot_pair(self, path: str | Path) -> dict:
        return self._db.snapshot_pair(str(path))

    def verify_history(self) -> dict:
        return self._db.verify_history()

    def history_posts(self) -> list[dict]:
        return self._db.history_posts()

    def post_history(self, post_id: str) -> list[dict]:
        return self._db.post_history(post_id)

    def integrity_report(self) -> dict:
        return self._db.integrity_report()

    def protection_report(self) -> dict:
        return self._db.protection_report()

    def render(self, title: str) -> str | None:
        """Render one post and the legacy supported discussion-list navigation.

        Returns None for missing posts. No Qt, network or filesystem I/O.
        The renderer's TiddlyWiki compatibility subset is unchanged.
        """
        post = self.get_tiddler(title)
        if post is None:
            return None
        document = _views.render_post(self, post)
        filters = re.findall(r'<\$list\s+filter="([^"]+)"', post.get('text', ''))
        if filters:
            links = []
            for expression in filters:
                for destination in self._db.filtered_title_links(expression):
                    links.append('<li><a href="tw://tiddler/' + quote(destination, safe='') +
                                 '">' + escape(destination) + '</a></li>')
            if links:
                document = document.replace(
                    '</body>',
                    '<section><h2>Discussion navigation (supported filter subset)</h2><ul>' +
                    ''.join(links) + '</ul></section></body>')
        return document
