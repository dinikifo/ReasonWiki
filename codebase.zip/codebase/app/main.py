"""PERSONAL.WIKI desktop application entry point.

The GUI lives in ui_window (main window), ui_dialogs (editor and choosers) and
ui_preview (WebEngine page). Names are re-exported here so older imports such
as ``main.TiddlyViewer`` keep working. The Qt-free core is wiki_core.WikiCore.
"""
import sys
from pathlib import Path

from PySide6.QtWidgets import QApplication

from ui_preview import WEBENGINE_AVAILABLE, TiddlerPage
from ui_dialogs import TiddlerEditor, ProjectItemDialog, TemplateDialog, RESERVED_FIELDS
from ui_window import TiddlyViewer, ImportWorker, BROWSE_VIEWS

__all__ = ['main', 'shutdown', 'TiddlyViewer', 'TiddlerEditor', 'ProjectItemDialog', 'TemplateDialog',
           'ImportWorker', 'TiddlerPage', 'WEBENGINE_AVAILABLE', 'RESERVED_FIELDS', 'BROWSE_VIEWS']


def shutdown(app, window) -> None:
    """Destroy the window while the QApplication still exists.

    Without this, interpreter exit may free the QApplication before the window,
    which crashes PySide (segfault/abort on quit; seen since T05.1). The
    notebook is already closed by the window's closeEvent at this point.
    """
    from PySide6.QtCore import QCoreApplication, QEvent
    window.close()
    window.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)
    app.processEvents()


def main():
    if sys.version_info < (3, 11):
        raise RuntimeError('Python 3.11+ required for supported PERSONAL.WIKI workflows')
    app = QApplication(sys.argv)
    app.setApplicationName("PERSONAL.WIKI")

    # Set up default database path
    window = TiddlyViewer()

    # Auto-load database if it exists in current directory
    default_db = Path("tiddlers.db")
    if default_db.exists():
        window._load_database(str(default_db))

    window.show()
    code = app.exec()
    shutdown(app, window)
    sys.exit(code)


if __name__ == "__main__":
    main()
