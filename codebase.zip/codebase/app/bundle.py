"""Notebook bundles: one verified file to back up, move or restore a notebook.

A bundle (``.pwbundle``, a ZIP) holds the notebook PAIR plus a manifest:

    manifest.json              format, versions, SHA-256 and size of both files,
                               post/event counts, change-log state, PVS link
    notebook.db                the posts
    notebook.history.sqlite    their history
    README.txt                 what this is and how to restore it

Export starts from the verified paired backup (WikiCore.snapshot_pair), so a
bundle is only written from a notebook whose content and history agree.

Restore checks the manifest and every digest, unpacks into a private folder
next to the destination, opens the pair read-only and verifies history,
protected posts and the change-log chain, and only then publishes both files
without overwriting anything. Members are read by fixed name, never by a path
taken from the archive.

A PVS link survives: the notebook knows its workspace by identity, so after a
restore on another machine the next refresh asks where the workspace is.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import tempfile
import zipfile

FORMAT, VERSION = 'personal-wiki-bundle', 1
CONTENT, HISTORY, MANIFEST, README = 'notebook.db', 'notebook.history.sqlite', 'manifest.json', 'README.txt'
MAX_MEMBER_BYTES = 4 * 1024 ** 3

README_TEXT = """PERSONAL.WIKI notebook bundle

This file holds one notebook: its posts (notebook.db) and their history
(notebook.history.sqlite), with checksums in manifest.json.

Restore it with File -> Restore Notebook Bundle... in PERSONAL.WIKI, or:

    python3 tools/notebook_bundle.py restore THIS_FILE NEW_FOLDER/my_notebook.db

Restoring checks every checksum and the notebook's history before anything is
written, and never overwrites an existing notebook.
"""


class BundleError(RuntimeError):
    pass


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def export_bundle(core, out_path: str | Path) -> dict:
    """Write a verified bundle of the open notebook ``core``. Never overwrites."""
    from db import _publish_temp
    out = Path(out_path)
    if out.exists() or out.is_symlink():
        raise BundleError(f'{out} already exists; choose another name')
    if not out.parent.is_dir():
        raise BundleError(f'Folder does not exist: {out.parent}')
    history = core.verify_history()
    log = core.verify_change_log()
    try:
        pvs = core.pvs_state()
    except Exception:  # the bundle must not depend on PVS being reachable
        pvs = {'configured': False}
    with tempfile.TemporaryDirectory(prefix='.pw_bundle_', dir=out.parent) as work:
        work = Path(work)
        pair = core.snapshot_pair(work / CONTENT)  # verified copy of both files
        content, hist = Path(pair['content']), Path(pair['history'])
        manifest = {
            'format': FORMAT, 'version': VERSION,
            'created_at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
            'source': Path(core.db_path).name,
            'files': {CONTENT: {'sha256': _sha256(content), 'bytes': content.stat().st_size},
                      HISTORY: {'sha256': _sha256(hist), 'bytes': hist.stat().st_size}},
            'posts': history['active_posts'], 'events': history['events'],
            'change_log': {'entries': log['entries'], 'tip': log['tip'], 'verified': log['verified']},
            'pvs': ({'workspace_id': core.raw_record('$:/config/pvs').get('pvs_workspace_id'),
                     'last_root': pvs.get('root'), 'last_refresh': pvs.get('last_refresh')}
                    if pvs.get('configured') else None),
        }
        staged = work / 'bundle.zip'
        with zipfile.ZipFile(staged, 'w', compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr(MANIFEST, json.dumps(manifest, indent=2, ensure_ascii=False, sort_keys=True))
            z.write(content, CONTENT)
            z.write(hist, HISTORY)
            z.writestr(README, README_TEXT)
        with open(staged, 'rb') as f:
            os.fsync(f.fileno())
        _publish_temp(str(staged), out, overwrite=False)
    manifest['bundle'] = str(out)
    return manifest


def read_manifest(bundle_path: str | Path) -> dict:
    """Check a bundle's structure and digests without unpacking it to disk."""
    path = Path(bundle_path)
    try:
        z = zipfile.ZipFile(path)
    except (OSError, zipfile.BadZipFile) as exc:
        raise BundleError(f'{path} is not a notebook bundle: {exc}') from exc
    with z:
        names = set(z.namelist())
        if not {MANIFEST, CONTENT, HISTORY} <= names:
            raise BundleError('Bundle is missing manifest.json, notebook.db or notebook.history.sqlite')
        try:
            manifest = json.loads(z.read(MANIFEST))
        except ValueError as exc:
            raise BundleError(f'Bundle manifest is not valid JSON: {exc}') from exc
        if manifest.get('format') != FORMAT:
            raise BundleError('Not a PERSONAL.WIKI notebook bundle')
        if manifest.get('version') != VERSION:
            raise BundleError(f"Unsupported bundle version {manifest.get('version')!r}")
        for name in (CONTENT, HISTORY):
            expected = (manifest.get('files') or {}).get(name) or {}
            info = z.getinfo(name)
            if info.file_size > MAX_MEMBER_BYTES or info.file_size != expected.get('bytes'):
                raise BundleError(f'{name}: size does not match the manifest')
            h = hashlib.sha256()
            with z.open(name) as f:
                for block in iter(lambda: f.read(1 << 20), b''):
                    h.update(block)
            if h.hexdigest() != expected.get('sha256'):
                raise BundleError(f'{name}: checksum does not match the manifest (damaged or altered bundle)')
    return manifest


def restore_bundle(bundle_path: str | Path, dest_path: str | Path) -> dict:
    """Verify and unpack a bundle as a NEW notebook pair at ``dest_path``."""
    from db import _publish_temp
    from history_db import history_path
    from wiki_core import WikiCore
    dest = Path(dest_path)
    companion = history_path(str(dest))
    if dest.suffix != '.db':
        raise BundleError('The restored notebook name must end in .db')
    if dest.exists() or dest.is_symlink() or companion.exists() or companion.is_symlink():
        raise BundleError('A notebook (or its history file) already exists there; choose another name')
    if not dest.parent.is_dir():
        raise BundleError(f'Folder does not exist: {dest.parent}')
    manifest = read_manifest(bundle_path)
    with tempfile.TemporaryDirectory(prefix='.pw_restore_', dir=dest.parent) as work:
        staged = Path(work) / 'restored.db'
        staged_hist = history_path(str(staged))
        with zipfile.ZipFile(bundle_path) as z:
            for name, target in ((CONTENT, staged), (HISTORY, staged_hist)):
                with z.open(name) as src, open(target, 'wb') as out:
                    for block in iter(lambda: src.read(1 << 20), b''):
                        out.write(block)
                    out.flush()
                    os.fsync(out.fileno())
                if _sha256(target) != manifest['files'][name]['sha256']:
                    raise BundleError(f'{name}: checksum changed while unpacking')
        if os.name == 'posix':
            os.chmod(staged, 0o600)
            os.chmod(staged_hist, 0o600)
        with WikiCore(staged, readonly=True) as check:  # integrity + protected posts on open
            history = check.verify_history()
            log = check.verify_change_log()
            if not log['verified']:
                raise BundleError('Change-log chain in the bundle is broken: ' + '; '.join(log['problems'][:3]))
        made = []
        try:
            for source, target in ((staged, dest), (staged_hist, companion)):
                stat = source.stat()
                made.append((target, stat.st_dev, stat.st_ino))
                _publish_temp(str(source), target, overwrite=False)
        except BaseException:
            for target, device, inode in reversed(made):
                try:
                    st = target.stat(follow_symlinks=False)
                    if (st.st_dev, st.st_ino) == (device, inode):
                        target.unlink()
                except FileNotFoundError:
                    pass
            raise
    pvs = manifest.get('pvs')
    note = None
    if pvs and pvs.get('last_root') and not (Path(pvs['last_root']) / 'objects').is_dir():
        note = 'The PVS workspace is not at its last known folder here; the next refresh will ask where it is.'
    return {'notebook': str(dest), 'history': str(companion), 'posts': history['active_posts'],
            'events': history['events'], 'change_log': log['entries'], 'created_at': manifest['created_at'],
            'pvs_note': note}
