"""Forms kit: structured post templates, each carrying a Toulmin argument.

A form is a tag. It has two ordinary, versioned posts:

  $:/template/<tag>   text = the markup skeleton; fields describe defaults
  $:/schema/<tag>     the field contract (see field_schema)

Every form requires the Toulmin core (claim, grounds, warrant) as fields, with
optional backing, qualifier and rebuttal. They are plain strings, the same
shape as a PVS-01 argument, so a form's argument can later be handed to PVS
without conversion. Templates are posts, so you can edit them; the history
keeps every earlier version.

Qt-free. Rendering of the special forms (kanban, waterfall) lives here too.
"""
from __future__ import annotations

from datetime import date
import json

import field_schema as fs

TEMPLATE_PREFIX = '$:/template/'
TOULMIN = ('claim', 'grounds', 'warrant', 'backing', 'qualifier', 'rebuttal')
TOULMIN_REQUIRED = ('claim', 'grounds', 'warrant')
WATERFALL_PHASES = ('requirements', 'design', 'implementation', 'verification', 'maintenance')
KANBAN_LANES = (('planned', 'Backlog'), ('active', 'Doing'), ('blocked', 'Blocked'), ('done', 'Done'))

_S = {'type': 'string', 'minLength': 1}
_DATE = {'type': 'string', 'format': 'date'}
_INT = {'type': 'string', 'format': 'integer'}


def _enum(*values):
    return {'type': 'string', 'enum': list(values)}


def _toulmin_props() -> dict:
    return {name: dict(_S) for name in TOULMIN}


GUIDE_TITLE = '11 — Using Forms'
GUIDE_TEXT = """! Using forms

''Tiddler → New from Template…'' (Ctrl+T) starts a post from a form. Every form has a field
contract, so a form post cannot be saved half-filled.

|!Form |!Use it when |
|5W1H |Scoping new work: who, what, when, where, why, how |
|5 Whys |Something went wrong and you want an actionable root cause |
|A3 report |Telling one problem's or project's whole story on one page; update it as work moves |
|Decision record (ADR) |You made (or propose) a decision others — or future you — will question |
|PDCA cycle |Treating an iteration as an experiment: plan, do, check, act |
|Daily log |Done / next / blocked / decisions for a day |
|Kanban board |A live board of a project's items, with a WIP limit on Doing |
|Waterfall plan |Sequential phases with end dates; the reason for each phase change is the gate decision |
|Argument (Toulmin) |A single argument for or against something, linked with ''responds_to'' |

!! The argument in every form

Each form carries a Toulmin argument in its fields, entered in the editor's ''Argument'' section:

|!Part |!Question it answers |!Required |
|Claim |What do you conclude? |yes |
|Grounds |What facts or evidence? |yes |
|Warrant |Why do those grounds support the claim? |yes |
|Backing |What supports the warrant? | |
|Qualifier |How sure are you? (provisional, likely, certain…) | |
|Rebuttal |When would the claim not hold? | |

They are plain text, the same shape as a PVS-01 argument.

!! Linking forms to projects

Choose a project when you start a form; it is stored in the ''project'' field (''scope'' for boards and
waterfall plans). The project's page then lists the form under ''Documents''.

!! Your own forms

A form is two posts: ''$:/template/<tag>'' (the skeleton text, with fields ''template_name'',
''template_description'', ''template_title'', ''template_tags'' and ''template_fields'') and
''$:/schema/<tag>'' (its contract). Edit them like any post, or copy them to make a new form.
In ''template_title'' and ''template_fields'', `{date}` becomes today and `{project}` the chosen project.
"""

# tag: (name, description, title pattern, specific properties, specific required, text, defaults)
_FORMS = {
    '5w1h': ('5W1H', 'Scope a piece of work: who, what, when, where, why, how.',
             '5W1H — {project}',
             {'who': _S, 'what': _S, 'when': _S, 'where': _S, 'why': _S, 'how': _S},
             ['what', 'why', 'how'],
             "! 5W1H\n\nShort answers go in the fields; use the text for detail.\n\n"
             "!! What\n\n!! Why\n\n!! How\n\n!! Who / When / Where\n", {}),
    'five-whys': ('5 Whys', 'Find an actionable root cause by asking why repeatedly.',
                  '5 Whys — ',
                  {'problem': _S, 'root_cause': _S, 'countermeasure': _S},
                  ['problem', 'root_cause', 'countermeasure'],
                  "! 5 Whys\n\n!! Problem\n\nWhat happened, observed directly (not interpreted).\n\n"
                  "# Why? \n# Why? \n# Why? \n# Why? \n# Why? \n\n"
                  "!! Root cause\n\nThe last why you can act on.\n\n!! Countermeasure\n\n"
                  "What will stop it recurring, and how you will check.\n", {}),
    'a3': ('A3 report', 'Toyota one-page problem/project story; update it as the work moves.',
           'A3 — {project}',
           {'a3_status': _enum('draft', 'in-progress', 'closed'), 'review_date': _DATE},
           ['a3_status'],
           "! A3\n\n!! 1. Background\n\nWhy this matters now.\n\n!! 2. Current condition\n\n"
           "Facts and figures, as observed.\n\n!! 3. Goal / target\n\nMeasurable.\n\n"
           "!! 4. Root cause analysis\n\nLink a [[5 Whys]] post if you have one.\n\n"
           "!! 5. Countermeasures\n\n!! 6. Implementation plan\n\n|!What |!Who |!When |\n| | | |\n\n"
           "!! 7. Follow-up\n\nHow you will check the result; what you learned.\n",
           {'a3_status': 'draft'}),
    'adr': ('Decision record (ADR)', 'Record a decision, its context, alternatives and consequences.',
            'ADR — ',
            {'adr_status': _enum('proposed', 'accepted', 'rejected', 'deprecated', 'superseded'),
             'decided': _DATE, 'superseded_by': _S},
            ['adr_status'],
            "! Decision\n\n!! Context\n\nThe forces at play; what made a decision necessary.\n\n"
            "!! Decision\n\nWhat we will do.\n\n!! Alternatives considered\n\n* \n* \n\n"
            "!! Consequences\n\nWhat becomes easier, what becomes harder.\n",
            {'adr_status': 'proposed'}),
    'pdca': ('PDCA cycle', 'Plan-Do-Check-Act: treat an iteration as an experiment.',
             'PDCA — {project} — cycle ',
             {'cycle': _INT, 'pdca_phase': _enum('plan', 'do', 'check', 'act'), 'metric': _S},
             ['cycle', 'pdca_phase'],
             "! PDCA\n\n!! Plan\n\nHypothesis, change, expected effect, how it will be measured.\n\n"
             "!! Do\n\nWhat was actually done.\n\n!! Check\n\nWhat the measurement showed.\n\n"
             "!! Act\n\nAdopt, adjust or abandon — and what the next cycle tries.\n",
             {'cycle': '1', 'pdca_phase': 'plan'}),
    'daily': ('Daily log', 'Done, next, blocked and decisions for one day.',
              'Daily — {date}',
              {'date': _DATE},
              ['date'],
              "! Daily log\n\n!! Done\n\n* \n\n!! Next\n\n* \n\n!! Blocked\n\n* \n\n"
              "!! Decisions\n\n* \n", {'date': '{date}'}),
    'kanban': ('Kanban board', "A live board of a project's items by status, with a WIP limit.",
               'Kanban — {project}',
               {'scope': _S, 'wip_limit': _INT},
               ['scope', 'wip_limit'],
               "! Kanban board\n\nThe board below is drawn from the items under the project in the "
               "''scope'' field. Change an item's status to move its card.\n\n!! Policies\n\n"
               "* A card enters Doing only when the WIP limit allows\n* Done means \n",
               {'scope': '{project}', 'wip_limit': '3'}),
    'waterfall': ('Waterfall plan', 'Sequential phases with an end date and exit criteria for each.',
                  'Waterfall — {project}',
                  dict({'scope': _S, 'phase': _enum(*WATERFALL_PHASES)},
                       **{f'{p}_end': _DATE for p in WATERFALL_PHASES[:-1]}),
                  ['scope', 'phase'],
                  "! Waterfall plan\n\nMoving to the next phase is an edit of the ''phase'' field; "
                  "its reason is the gate decision.\n\n" +
                  ''.join(f"!! {p.capitalize()}\n\nExit criteria:\n\n* \n\n" for p in WATERFALL_PHASES),
                  {'scope': '{project}', 'phase': 'requirements'}),
    'argument': ('Argument (Toulmin)', 'A single argument for or against something.',
                 'Argument — ',
                 {'stance': _enum('support', 'oppose'), 'responds_to': _S, 'about': _S},
                 ['stance'],
                 "! Argument\n\nThe argument is in the fields. Use the text for evidence, "
                 "links and discussion.\n", {'stance': 'support'}),
}

FORM_TAGS = tuple(_FORMS)


def form_schema(tag: str) -> dict:
    _, _, _, props, required, _, _ = _FORMS[tag]
    properties = dict(props)
    properties['project'] = dict(_S)
    properties.update(_toulmin_props())
    return {'type': 'object', 'properties': properties,
            'required': list(required) + list(TOULMIN_REQUIRED)}


def template_title(tag: str) -> str:
    return TEMPLATE_PREFIX + tag


def kit_records() -> list[dict]:
    records = []
    for tag, (name, description, pattern, _props, _req, text, defaults) in _FORMS.items():
        fields = dict(defaults)
        fields.setdefault('qualifier', 'provisional')
        records.append({'title': fs.schema_title(tag), 'type': 'application/json',
                        'tags': '$:/tags/FieldContract', 'text': json.dumps(form_schema(tag), indent=2)})
        records.append({'title': template_title(tag), 'tags': '$:/tags/Template',
                        'template_name': name, 'template_description': description,
                        'template_title': pattern, 'template_tags': tag,
                        'template_fields': json.dumps(fields, ensure_ascii=False),
                        'text': text})
    records.append({'title': GUIDE_TITLE, 'tags': 'Guide', 'text': GUIDE_TEXT})
    return records


def list_templates(core) -> list[dict]:
    """Every $:/template/* post (kit or your own), as dicts for a chooser."""
    out = []
    for title in core.search(TEMPLATE_PREFIX, mode='Title', limit=500):
        if not title.startswith(TEMPLATE_PREFIX):
            continue
        post = core.get_tiddler(title)
        f = post.get('fields', {})
        out.append({'title': title, 'tag': title[len(TEMPLATE_PREFIX):],
                    'name': f.get('template_name') or title[len(TEMPLATE_PREFIX):],
                    'description': f.get('template_description', '')})
    return sorted(out, key=lambda t: t['name'].lower())


def preset_from_template(core, template: str, *, project: str | None = None,
                         today: date | None = None) -> dict:
    """Editor preset (title, tags, text, fields) built from a template post."""
    post = core.get_tiddler(template)
    if post is None:
        raise ValueError(f'No template {template!r}')
    f = post.get('fields', {})
    today = today or date.today()
    subst = {'{date}': today.isoformat(), '{project}': project or ''}

    def fill(value: str) -> str:
        for key, val in subst.items():
            value = value.replace(key, val)
        return value

    try:
        defaults = json.loads(f.get('template_fields') or '{}')
    except ValueError as exc:
        raise ValueError(f'{template}: template_fields is not valid JSON') from exc
    fields = {k: fill(v) if isinstance(v, str) else v for k, v in defaults.items()}
    fields = {k: v for k, v in fields.items() if v != ''}
    if project and 'project' not in fields and 'scope' not in fields:
        fields['project'] = project
    tags = [t for t in (f.get('template_tags') or '').split() if t]
    title = fill(f.get('template_title') or '').strip(' —') if f.get('template_title') else ''
    if title and core.get_tiddler(title) is not None:
        n = 2
        while core.get_tiddler(f'{title} ({n})') is not None:
            n += 1
        title = f'{title} ({n})'
    return {'title': title, 'tags': tags, 'text': post.get('text', ''), 'fields': fields}


# ----------------------------------------------------------------------
# Data for the special forms (rendered by views.py)
# ----------------------------------------------------------------------
def form_name(tag: str) -> str | None:
    return _FORMS[tag][0] if tag in _FORMS else None


def form_of(post: dict) -> str | None:
    """The kit form tag a post carries, if any."""
    return next((t for t in post.get('tags') or [] if t in _FORMS), None)


def documents(core, title: str) -> list[tuple[str, str]]:
    """(form name, title) for posts that point at ``title`` via project or scope."""
    rows = []
    for t in core.titles_with_field_value(('project', 'scope'), title):
        post = core.get_tiddler(t)
        rows.append((form_name(form_of(post)) or 'note', t))
    return sorted(rows)


def board(core, post: dict, today: date | None = None) -> dict:
    """Kanban data: lanes of work items under the post's scope project."""
    import projects
    f = post.get('fields', {})
    scope = f.get('scope')
    try:
        limit = int(f.get('wip_limit', ''))
    except (TypeError, ValueError):
        limit = None
    ov = projects.overview(core, today)
    if not scope or scope not in ov['items']:
        return {'scope': scope, 'error': f'Board scope {scope!r} is not a project item.', 'overview': ov}
    seen, stack, cards = {scope}, list(ov['children'].get(scope, [])), []
    while stack:
        t = stack.pop()
        if t in seen:
            continue
        seen.add(t)
        cards.append(t)
        stack.extend(ov['children'].get(t, []))
    # Cards are the work items: tasks, plus goals/milestones without children of their own.
    cards = [t for t in cards if ov['items'][t]['kind'] == 'task' or not ov['children'].get(t)]
    prio = {p: i for i, p in enumerate(projects.PRIORITIES)}
    lanes = []
    for status, label in KANBAN_LANES:
        here = sorted((t for t in cards if ov['items'][t]['status'] == status),
                      key=lambda t: (prio.get(ov['items'][t]['priority'], 9), ov['items'][t]['due'] or '9', t))
        lanes.append({'status': status, 'label': label, 'cards': here,
                      'limit': limit if status == 'active' else None,
                      'over': status == 'active' and limit is not None and len(here) > limit})
    return {'scope': scope, 'error': None, 'overview': ov, 'lanes': lanes,
            'dropped': sum(1 for t in cards if ov['items'][t]['status'] == 'dropped')}


def phases(post: dict, today: date | None = None) -> list[dict]:
    """Waterfall data: one dict per phase with its end date and state."""
    today = today or date.today()
    f = post.get('fields', {})
    current = f.get('phase')
    idx = WATERFALL_PHASES.index(current) if current in WATERFALL_PHASES else -1
    out = []
    for i, phase in enumerate(WATERFALL_PHASES):
        end = f.get(f'{phase}_end') if isinstance(f.get(f'{phase}_end'), str) else None
        state = 'past' if i < idx else ('now' if i == idx else 'future')
        if state == 'now' and end:
            try:
                if date.fromisoformat(end) < today:
                    state = 'late'
            except ValueError:
                pass
        out.append({'phase': phase, 'end': end, 'state': state})
    return out
