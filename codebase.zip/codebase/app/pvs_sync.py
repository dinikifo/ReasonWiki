"""Two-way PVS-01 workflow: refresh PVS data into the notebook and reconcile.

You maintain both systems. PVS records decisions and code; the wiki is where
you read, format and think. Neither writes to the other: a refresh READS PVS
into the open notebook, and anything that should go back is listed for you to
enter in PVS by hand.

Ownership on a PVS-managed post (tag ``pvs``):

* PVS owns ``parent`` and every ``pvs_*`` field, including ``pvs_view`` (the
  current PVS content, shown in a "From PVS" panel). Only a refresh changes them.
* You own the text (seeded once from PVS, never overwritten), the tags you add,
  and the ``status``, which may move first on either side.

Status reconcile, per post, against ``pvs_base`` (PVS's value at the last refresh):

    wiki = base, PVS changed     -> take PVS
    wiki changed, PVS = base     -> keep wiki; listed "to enter in PVS"
    both changed to same value   -> in sync
    both changed, different      -> conflict; nothing overwritten; you choose

Reasoning: a post with ``pvs_target`` (a PVS post title) and ``pvs_side``
(acceptance/rejection for a project, for/against for a goal) is listed "to
enter in PVS" until a refresh finds an argument with the same claim and
warrant there.

Every refresh writes one change-log entry in the same transaction.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path

import changelog
from db import record_sha256, parse_tags

CONFIG_TITLE = '$:/config/pvs'
MANAGED_TAG = 'pvs'
SIDES = {'project': ('acceptance', 'rejection'), 'goal': ('for', 'against')}
TO_PVS = {
    'goal': {'planned': 'set_goal_status PENDING', 'active': 'set_goal_status ACTIVE',
             'done': 'set_goal_status COMPLETE', 'blocked': 'set_goal_status BLOCKED',
             'dropped': 'delete_goal'},
    'milestone': {'active': 'resume (milestone)', 'blocked': 'stop (milestone)'},
    'project': {'dropped': 'decide REJECTED', 'blocked': 'stop', 'done': 'archive_project',
                'active': 'resume, or set work ACTIVE', 'planned': 'decide ACCEPTED (work NOT_STARTED), or reopen'},
}


class SyncError(RuntimeError):
    pass


class WorkspaceMissing(SyncError):
    """The remembered workspace folder is not there (moved, restored, other machine)."""


def _kind(record: dict) -> str | None:
    tags = parse_tags(record.get('tags', []))
    return next((k for k in ('project', 'goal', 'milestone') if k in tags), None)


def _json(value, default):
    try:
        return json.loads(value) if isinstance(value, str) and value else default
    except ValueError:
        return default


def suggestion(kind: str | None, status: str) -> str:
    op = TO_PVS.get(kind or '', {}).get(status)
    if op:
        return op
    if kind == 'milestone':
        return f'no direct PVS operation for milestone status {status!r} (use revise_versioner)'
    return f'set status to match {status!r}'


def config(core) -> dict:
    raw = core.raw_record(CONFIG_TITLE)
    return {k: v for k, v in (raw or {}).items() if k.startswith('pvs_')}


def _managed_titles(core) -> list[str]:
    return core.search(MANAGED_TAG, mode='Tag', limit=100000)


def refresh(core, pvs_root: str | Path | None = None, *, pvs_src: str | None = None,
            snapshot_file: str | Path | None = None, now: datetime | None = None) -> dict:
    """Read PVS at one consistent pin and reconcile it into the open notebook.

    PVS is read either by running tools/pvs_export.py in a separate process on the
    workspace folder, or from a snapshot file it wrote (``snapshot_file``). The
    notebook recognises its workspace by identity, not by folder path.
    """
    from pvs_bridge import load_snapshot, records_from_snapshot, run_export
    cfg = config(core)
    remembered = cfg.get('pvs_src')
    if remembered and not Path(remembered).is_dir():
        remembered = None  # e.g. restored on another machine: fall back to PVS_SRC or ask
    pvs_src = pvs_src or remembered or None
    if snapshot_file:
        snapshot = load_snapshot(snapshot_file)
    else:
        root = pvs_root or cfg.get('pvs_root')
        if not root:
            raise SyncError('Choose the PVS workspace folder (the one containing objects/).')
        if not pvs_root and not (Path(root) / 'objects').is_dir():
            raise WorkspaceMissing(f'The PVS workspace is no longer at {root}. Choose where it is now.')
        snapshot = run_export(root, pvs_src)
    workspace_id = snapshot['workspace']['id']
    known = cfg.get('pvs_workspace_id')
    if known and known != workspace_id:
        raise SyncError(f"This notebook follows PVS workspace {known[:12]}… (last seen at "
                        f"{cfg.get('pvs_root')!r}); this is a different workspace ({workspace_id[:12]}…). "
                        'Use a separate notebook for another workspace.')
    root = snapshot['workspace'].get('root') or cfg.get('pvs_root', '')
    records, summary = records_from_snapshot(snapshot, timeless=True)
    core.update_change_log()  # log the user's edits up to now before the refresh entry
    now = now or datetime.now(timezone.utc)
    stamp = now.strftime('%Y-%m-%d %H:%M UTC')
    report = {'new': [], 'from_pvs': [], 'content': [], 'to_enter': [], 'conflicts': [],
              'in_sync': [], 'missing': [], 'returned': []}
    changes = []
    incoming = {r['title']: r for r in records}
    for title, rec in incoming.items():
        pvs_fields = {k: v for k, v in rec.items() if k.startswith('pvs_')}
        pvs_fields['pvs_view'] = rec['text']
        pvs_status = rec.get('status')
        current = core.raw_record(title)
        if current is None:
            after = {'title': title, 'tags': rec['tags'], 'text': rec['text'], **pvs_fields,
                     'pvs_seed_sha256': record_sha256({'text': rec['text']})}
            if rec.get('parent'):
                after['parent'] = rec['parent']
            if pvs_status:
                after['status'] = pvs_status
                after['pvs_base'] = json.dumps({'status': pvs_status})
            changes.append({'title': None, 'record': after,
                            'reason': f'PVS refresh {stamp}: new from PVS'})
            report['new'].append(title)
            continue
        after = {k: v for k, v in current.items() if not k.startswith('pvs_') and k != 'parent'}
        after.update(pvs_fields)
        for keep in ('pvs_seed_sha256',):
            if keep in current:
                after[keep] = current[keep]
        if rec.get('parent'):
            after['parent'] = rec['parent']
        user_tags = parse_tags(current.get('tags', []))
        merged = list(dict.fromkeys(user_tags + parse_tags(rec['tags'])))
        if merged != user_tags:  # keep the stored representation unless a tag is added
            after['tags'] = merged
        notes = []
        if current.get('pvs_presence') == 'missing':
            report['returned'].append(title)
            notes.append('back in PVS')
        if current.get('pvs_view') != pvs_fields['pvs_view']:
            report['content'].append(title)
            notes.append('PVS content changed')
        if pvs_status:
            base = _json(current.get('pvs_base'), {}).get('status')
            wiki = current.get('status')
            if base is None:  # first refresh that knows a base: PVS seeds it
                base = wiki
            if wiki == base and pvs_status != base:
                after['status'] = pvs_status
                base = pvs_status
                report['from_pvs'].append({'title': title, 'from': wiki, 'to': pvs_status})
                notes.append(f'status {wiki} → {pvs_status} (from PVS)')
            elif wiki != base and pvs_status == base:
                report['to_enter'].append({'title': title, 'wiki': wiki, 'pvs': pvs_status})
            elif wiki != base and pvs_status != base:
                if wiki == pvs_status:
                    base = pvs_status
                    report['in_sync'].append(title)
                    notes.append(f'status {wiki} now also in PVS')
                else:
                    after['pvs_conflict'] = json.dumps({'status': {'wiki': wiki, 'pvs': pvs_status}})
                    report['conflicts'].append({'title': title, 'wiki': wiki, 'pvs': pvs_status})
                    notes.append(f'conflict: wiki {wiki} / PVS {pvs_status}')
            after['pvs_base'] = json.dumps({'status': base})
        if {k: v for k, v in after.items() if k != 'modified'} != \
                {k: v for k, v in current.items() if k != 'modified'}:
            changes.append({'title': title, 'record': after,
                            'reason': f'PVS refresh {stamp}: ' + ('; '.join(notes) or 'PVS data updated')})
    for title in _managed_titles(core):
        if title in incoming:
            continue
        current = core.raw_record(title)
        if current.get('pvs_presence') != 'missing':
            changes.append({'title': title, 'record': dict(current, pvs_presence='missing'),
                            'reason': f'PVS refresh {stamp}: no longer in PVS'})
        report['missing'].append(title)
    cfg_record = {'title': CONFIG_TITLE, 'tags': ['$:/tags/Config'],
                  'text': 'Settings for Refresh from PVS. Edited by the refresh.',
                  'pvs_root': root, 'pvs_workspace_id': workspace_id, 'pvs_last_refresh': stamp,
                  'pvs_pins': json.dumps(summary['objects'])}
    if snapshot_file:
        cfg_record['pvs_last_source'] = 'snapshot file'
    if pvs_src:
        cfg_record['pvs_src'] = str(pvs_src)
    old_cfg = core.raw_record(CONFIG_TITLE)
    changes.append({'title': CONFIG_TITLE if old_cfg else None, 'record': cfg_record,
                    'reason': f'PVS refresh {stamp}: settings'})
    report['reasoning'] = reasoning_state(core, incoming)
    log_title, log_changes = changelog.refresh_entry_changes(
        core, refresh_text(report, summary),
        {'log_pvs_workspace': workspace_id, 'log_pvs_pins': json.dumps(summary['objects'])}, now)
    core.write_batch(changes + log_changes, managed=True)
    report.update({'log': log_title, 'root': root, 'workspace_id': workspace_id,
                   'objects': summary['objects'], 'taken': stamp})
    return report


def reasoning_state(core, incoming: dict | None = None) -> list[dict]:
    """Wiki arguments aimed at PVS: entered (found in PVS) or still to enter."""
    out = []
    for title in core.titles_with_field('pvs_target'):
        post = core.raw_record(title)
        if MANAGED_TAG in parse_tags(post.get('tags', [])):
            continue
        target, side = post.get('pvs_target'), post.get('pvs_side')
        source = (incoming or {}).get(target) or core.raw_record(target) or {}
        kind = _kind(source) if source else None
        problem = None
        if not source:
            problem = 'target is not a PVS post'
        elif kind not in SIDES:
            problem = 'arguments can target a PVS project or goal'
        elif side not in SIDES[kind]:
            problem = f"pvs_side must be one of {', '.join(SIDES[kind])}"
        entered = False
        if problem is None:
            args = _json(source.get('pvs_arguments'), {}).get(side, [])
            key = ((post.get('claim') or '').strip(), (post.get('warrant') or '').strip())
            entered = any(((a.get('claim') or '').strip(), (a.get('warrant') or '').strip()) == key for a in args)
        op = None
        if problem is None and not entered:
            op = (f"add_rfc_argument {side}" if kind == 'project' else f"add_goal_argument {side}")
        out.append({'title': title, 'target': target, 'side': side, 'entered': entered,
                    'problem': problem, 'operation': op})
    return out


def state(core) -> dict:
    """Current sync picture for the dashboard (no PVS access needed)."""
    to_enter, conflicts, missing = [], [], []
    for title in _managed_titles(core):
        post = core.raw_record(title)
        if post.get('pvs_presence') == 'missing':
            missing.append(title)
        conflict = _json(post.get('pvs_conflict'), {}).get('status')
        if conflict:
            conflicts.append({'title': title, **conflict})
            continue
        base = _json(post.get('pvs_base'), {}).get('status')
        if base is not None and post.get('status') != base:
            to_enter.append({'title': title, 'wiki': post.get('status'), 'pvs': base,
                             'operation': suggestion(_kind(post), post.get('status'))})
    reasoning = reasoning_state(core)
    cfg = config(core)
    return {'configured': bool(cfg.get('pvs_root')), 'root': cfg.get('pvs_root'),
            'last_refresh': cfg.get('pvs_last_refresh'), 'to_enter': to_enter,
            'conflicts': conflicts, 'missing': missing,
            'reasoning_pending': [r for r in reasoning if not r['entered'] and not r['problem']],
            'reasoning_entered': [r for r in reasoning if r['entered']],
            'reasoning_problems': [r for r in reasoning if r['problem']]}


def resolve(core, title: str, choice: str, *, reason: str) -> dict:
    """Settle a status conflict: 'pvs' takes PVS's value; 'wiki' keeps yours (then to enter in PVS)."""
    if choice not in ('pvs', 'wiki'):
        raise ValueError("choice must be 'pvs' or 'wiki'")
    post = core.raw_record(title)
    conflict = _json((post or {}).get('pvs_conflict'), {}).get('status')
    if not conflict:
        raise ValueError(f'{title!r} has no PVS conflict')
    after = {k: v for k, v in post.items() if k != 'pvs_conflict'}
    after['pvs_base'] = json.dumps({'status': conflict['pvs']})
    after['status'] = conflict['pvs'] if choice == 'pvs' else conflict['wiki']
    core.write_batch([{'title': title, 'record': after,
                       'reason': f"{reason} — PVS conflict resolved: {'took PVS' if choice == 'pvs' else 'kept wiki'}"
                                 f" ({conflict['wiki']} / {conflict['pvs']})"}], managed=True)
    return {'title': title, 'status': after['status']}


def refresh_text(report: dict, summary: dict) -> str:
    def items(rows, fmt):
        return '\n'.join('* ' + fmt(r) for r in rows) if rows else '//none//'
    pins = ', '.join(f"{o['object']} @ {o['seq']}" for o in summary['objects'])
    return '\n'.join([
        f"Workspace `{summary['workspace_id'][:12]}…` at `{summary['root']}` · pins: {pins}", '',
        f"!! New from PVS ({len(report['new'])})", items(report['new'], lambda t: f'[[{t}]]'), '',
        f"!! Status taken from PVS ({len(report['from_pvs'])})",
        items(report['from_pvs'], lambda r: f"[[{r['title']}]]: {r['from']} → {r['to']}"), '',
        f"!! PVS content changed ({len(report['content'])})", items(report['content'], lambda t: f'[[{t}]]'), '',
        f"!! Now in sync ({len(report['in_sync'])})", items(report['in_sync'], lambda t: f'[[{t}]]'), '',
        f"!! To enter in PVS ({len(report['to_enter'])})",
        items(report['to_enter'], lambda r: f"[[{r['title']}]]: wiki {r['wiki']}, PVS {r['pvs']}"), '',
        f"!! Conflicts ({len(report['conflicts'])})",
        items(report['conflicts'], lambda r: f"[[{r['title']}]]: wiki {r['wiki']}, PVS {r['pvs']}"), '',
        f"!! No longer in PVS ({len(report['missing'])})", items(report['missing'], lambda t: f'[[{t}]]'), '',
        f"!! Arguments still to enter ({sum(1 for r in report['reasoning'] if not r['entered'] and not r['problem'])})",
        items([r for r in report['reasoning'] if not r['entered'] and not r['problem']],
              lambda r: f"[[{r['title']}]] → [[{r['target']}]] ({r['side']})"), '',
    ]) + '\n'
