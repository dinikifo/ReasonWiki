"""Reliable TiddlyWiki-compatible SQLite storage (portable JSON is canonical).

TiddlerDB is the storage and read layer. All writes go through
history_db.HistoryTiddlerDB, which records every change; this class has no
writers of its own (they could bypass the history).
Round-trip preservation: original JSON dictionaries, including tags representation and
unknown fields, survive unedited imports/exports. This does not implement TW runtime.
"""
from __future__ import annotations
from contextlib import closing
import hashlib
import json
import os
import sqlite3
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from schema_migrations import TARGET_VERSION, SchemaCompatibilityError, inspect_connection, _connect_existing

SCHEMA = """
CREATE TABLE IF NOT EXISTS tiddlers (
  title TEXT PRIMARY KEY, text TEXT NOT NULL DEFAULT '', created TEXT,
  modified TEXT, tags_json TEXT NOT NULL DEFAULT '[]',
  fields_json TEXT NOT NULL DEFAULT '{}', raw_json TEXT
);
CREATE TABLE IF NOT EXISTS tiddler_tags (
  title TEXT NOT NULL, tag TEXT NOT NULL,
  PRIMARY KEY(title, tag),
  FOREIGN KEY(title) REFERENCES tiddlers(title) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_tiddler_tags_tag ON tiddler_tags(tag);
CREATE TABLE IF NOT EXISTS protected_titles (
  title TEXT PRIMARY KEY, record_sha256 TEXT NOT NULL,
  FOREIGN KEY(title) REFERENCES tiddlers(title) ON DELETE RESTRICT
);
CREATE VIRTUAL TABLE IF NOT EXISTS tiddlers_fts USING fts5(
  title, text, content='tiddlers', content_rowid='rowid'
);
CREATE TRIGGER IF NOT EXISTS tiddlers_ai AFTER INSERT ON tiddlers BEGIN
  INSERT INTO tiddlers_fts(rowid,title,text) VALUES (new.rowid,new.title,new.text);
END;
CREATE TRIGGER IF NOT EXISTS tiddlers_ad AFTER DELETE ON tiddlers BEGIN
  INSERT INTO tiddlers_fts(tiddlers_fts,rowid,title,text)
  VALUES ('delete',old.rowid,old.title,old.text);
END;
CREATE TRIGGER IF NOT EXISTS tiddlers_au AFTER UPDATE ON tiddlers BEGIN
  INSERT INTO tiddlers_fts(tiddlers_fts,rowid,title,text)
  VALUES ('delete',old.rowid,old.title,old.text);
  INSERT INTO tiddlers_fts(rowid,title,text)
  VALUES (new.rowid,new.title,new.text);
END;
"""

def parse_tags(value) -> list[str]:
    if value is None: return []
    if isinstance(value,list):
        return [v for v in value if isinstance(v,str)]
    if not isinstance(value,str): raise ValueError('tags must be list or string')
    result=[]; i=0
    while i < len(value):
        if value[i].isspace():i+=1;continue
        if value.startswith('[[',i):
            end=value.find(']]',i+2)
            if end!=-1:result.append(value[i+2:end]);i=end+2;continue
        end=i+1
        while end<len(value) and not value[end].isspace():end+=1
        result.append(value[i:end]);i=end
    return result

def encode_tags(tags:list[str]) -> str:
    return ' '.join(f'[[{t}]]' if any(c.isspace() for c in t) else t for t in tags)

def _valid_record(record: dict) -> dict:
    if not isinstance(record,dict) or not isinstance(record.get('title'),str) or not record['title']:
        raise ValueError('Every tiddler must be an object with a nonempty string title')
    for field in ('text','created','modified'):
        if field in record and not isinstance(record[field],str):
            raise ValueError(f'{record["title"]}: {field} must be text')
    parse_tags(record.get('tags',[]))
    return record

def record_sha256(record: dict) -> str:
    """Stable digest of a complete post object (sorted keys, compact UTF-8 JSON)."""
    return hashlib.sha256(json.dumps(record,ensure_ascii=False,sort_keys=True,
                          separators=(',',':')).encode('utf-8')).hexdigest()

CORE_KEYS = frozenset({'title','text','created','modified','tags'})

def custom_fields(record: dict) -> dict:
    return {k:v for k,v in record.items() if k not in CORE_KEYS}

def _utc_stamp():return datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')[:17]

def _publish_temp(tmp: str, path: Path, overwrite: bool) -> None:
    # Hard-link publication is an atomic create-if-absent on local APFS/ext4.
    # Never turn 'no overwrite' into a check-then-replace race.
    if overwrite:
        os.replace(tmp, path)
    else:
        os.link(tmp, path)  # raises FileExistsError, including if a concurrent writer won
        os.unlink(tmp)
    if hasattr(os, 'O_DIRECTORY'):
        dfd = os.open(str(path.parent), os.O_RDONLY | os.O_DIRECTORY)
        try: os.fsync(dfd)
        finally: os.close(dfd)


def _write_atomic(path:Path, content: bytes, overwrite:bool=False) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists() and not overwrite:raise FileExistsError(f'Refusing to replace {path}')
    fd, tmp=tempfile.mkstemp(prefix='.'+path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(content);f.flush();os.fsync(f.fileno())
        _publish_temp(tmp,path,overwrite)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def create_new_database(path: str) -> None:
    """Create a fresh v2 database without overwriting an existing file.

    Build and validate the DB in a private directory on the destination's
    filesystem, close/checkpoint its WAL, then publish with atomic no-clobber
    hard-link. A failed create cannot leave a half-initialized destination.
    """
    destination = Path(path)
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f'Database already exists; refusing to replace: {destination}')
    if not destination.parent.is_dir():
        raise FileNotFoundError(f'Database destination folder does not exist: {destination.parent}')
    with tempfile.TemporaryDirectory(prefix='.pw_new_db_', dir=destination.parent) as folder:
        staging = Path(folder) / 'fresh.db'
        with TiddlerDB(str(staging)) as fresh:
            report = fresh.integrity_report()
            if (report['integrity'] != 'ok' or report['foreign_key_violations']
                    or not report['fts_matches'] or report['records'] != 0):
                raise ValueError(f'Fresh database failed validation: {report}')
        # A user-selected location can have permissive parent permissions.
        # Restrict the database file itself on POSIX before publishing it.
        if os.name == 'posix':
            os.chmod(staging, 0o600)
        # The connection is closed and the WAL checkpointed before publication.
        _publish_temp(str(staging), destination, overwrite=False)


class TiddlerDB:
    def __init__(self,db_path:str='tiddlers.db',readonly:bool=False, journal_mode:str='WAL'):
        self.db_path=str(db_path);self.readonly=readonly
        if journal_mode not in ('WAL','DELETE'):
            raise ValueError('Unsupported journal mode')
        path=Path(db_path)
        new=not path.exists()
        if not new:
            # The compatibility gate is deliberately before *any* writable
            # connection, journal-mode switch or implicit DDL execution.
            with closing(_connect_existing(path)) as probe:
                status=inspect_connection(probe)
            if status['schema_version'] != TARGET_VERSION and not (readonly and status['schema_version'] == 0 and
                    status['readable_v2_layout']):
                raise SchemaCompatibilityError(
                    f'Existing database is schema v{status["schema_version"]}; '
                    f'requires an EXPLICIT side-by-side migration to v{TARGET_VERSION}. '
                    'Use: python3 app/schema_migrations.py plan SOURCE; '
                    'python3 app/schema_migrations.py migrate SOURCE NEW_DESTINATION')
            if not readonly:
                # An existing DB must pass the preservation audit BEFORE a
                # writable connection, WAL switch, or any implicit mutation.
                with TiddlerDB(str(path), readonly=True) as audit:
                    protected = audit.protection_report()
                    if protected['violation_count']:
                        raise SchemaCompatibilityError(
                            f'Protected records inconsistent; writable open refused: {protected["violations"]}')
        elif readonly:
            raise FileNotFoundError(str(path))
        if readonly:
            self.conn=_connect_existing(path)
        else:
            self.conn=sqlite3.connect(db_path,timeout=15) if new else _connect_existing(path,readonly=False)
        try:
            self.conn.row_factory=sqlite3.Row
            self.conn.execute('PRAGMA busy_timeout=15000')
            self.conn.execute('PRAGMA foreign_keys=ON')
            if not readonly:
                if not new:
                    # Re-check on the actual writable handle (not just its
                    # read-only preflight), before changing journal settings.
                    live = inspect_connection(self.conn)
                    if live['schema_version'] != TARGET_VERSION:
                        raise SchemaCompatibilityError('Schema version changed during open; refusing write')
                if new:
                    # New empty workspace creation is NOT an upgrade of old data.
                    self.conn.executescript(SCHEMA)
                    self.conn.execute(f'PRAGMA user_version={TARGET_VERSION}')
                    self.conn.commit()
                if not new:
                    # Recheck on the actual handle to narrow the time-of-check
                    # race with independent writers before journal changes.
                    protected = self.protection_report()
                    if protected['violation_count']:
                        raise SchemaCompatibilityError(
                            f'Protected records changed during open: {protected["violations"]}')
                actual=self.conn.execute(f'PRAGMA journal_mode={journal_mode}').fetchone()[0]
                if actual.lower()!=journal_mode.lower():
                    raise sqlite3.OperationalError('Cannot set required SQLite journal mode')
                self.conn.execute('PRAGMA synchronous='+('EXTRA' if journal_mode=='DELETE' else 'FULL'))
                if not self._check_fts_integrity():
                    raise SchemaCompatibilityError('FTS external-content integrity check failed; original left unmodified')
        except BaseException:
            self.conn.close()
            raise

    def _check_fts_integrity(self) -> Optional[bool]:
        # FTS5's external-content integrity-check is a write-style command.
        # In readonly mode, execute it against a PRIVATE online SQLite snapshot:
        # never attempt a write or a journal-mode change on the source database.
        if self.readonly:
            try:
                with tempfile.TemporaryDirectory(prefix='pw_fts_readonly_') as folder:
                    with closing(sqlite3.connect(str(Path(folder) / 'validation.db'))) as copy:
                        self.conn.backup(copy, pages=256, sleep=0.01)
                        copy.execute("INSERT INTO tiddlers_fts(tiddlers_fts,rank) VALUES('integrity-check',1)")
                return True
            except sqlite3.DatabaseError:
                return False
        # The FTS5 command is syntactically an INSERT. Python's sqlite3 opens
        # an implicit transaction for it, even when it only checks integrity.
        # Leaving that transaction open holds the SQLite writer lock, making
        # the GUI's separate JSON-import worker fail with "database is locked".
        # Roll back ONLY the transaction initiated by this check. Never end a
        # transaction already belonging to the caller.
        was_in_transaction = self.conn.in_transaction
        try:
            self.conn.execute("INSERT INTO tiddlers_fts(tiddlers_fts,rank) VALUES('integrity-check',1)")
            return True
        except sqlite3.DatabaseError:
            return False
        finally:
            if not was_in_transaction and self.conn.in_transaction:
                self.conn.rollback()

    def close(self):self.conn.close()
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
    def _store(self,t:dict):
        t=_valid_record(t);title=t['title'];tags=parse_tags(t.get('tags',[]))
        fields=custom_fields(t)
        self.conn.execute('''INSERT INTO tiddlers
          (title,text,created,modified,tags_json,fields_json,raw_json)
          VALUES (?,?,?,?,?,?,?)
          ON CONFLICT(title) DO UPDATE SET text=excluded.text,created=excluded.created,
          modified=excluded.modified,tags_json=excluded.tags_json,
          fields_json=excluded.fields_json,raw_json=excluded.raw_json''',
          (title,t.get('text',''),t.get('created'),t.get('modified'),
           json.dumps(tags,ensure_ascii=False),json.dumps(fields,ensure_ascii=False),
           json.dumps(t,ensure_ascii=False,separators=(',',':'))))
        self.conn.execute('DELETE FROM tiddler_tags WHERE title=?',(title,))
        self.conn.executemany('INSERT INTO tiddler_tags(title,tag) VALUES (?,?)',
                              ((title,tag) for tag in dict.fromkeys(tags)))

    def _protect(self,t:dict):
        digest=record_sha256(t)
        row=self.conn.execute('SELECT record_sha256 FROM protected_titles WHERE title=?',
                              (t['title'],)).fetchone()
        if row is not None and row[0]!=digest:
            raise PermissionError('Preserved evidence hash mismatch: '+t['title'])
        self.conn.execute('INSERT OR IGNORE INTO protected_titles VALUES(?,?)',(t['title'],digest))

    def is_protected(self,title:str)->bool:
        return self.conn.execute('SELECT 1 FROM protected_titles WHERE title=?',(title,)).fetchone() is not None

    def protection_report(self):
        # A raw_json digest alone misses changes to the normalized columns
        # that the search and filter interfaces actually use. Check all three
        # representations: immutable source object, row projection, tag index.
        count=0;violations=[]
        for title,digest in self.conn.execute('SELECT title,record_sha256 FROM protected_titles'):
            row=self.conn.execute("""SELECT title,text,created,modified,tags_json,fields_json,raw_json
                                     FROM tiddlers WHERE title=?""",(title,)).fetchone()
            if row is None:
                violations.append(title+': absent'); continue
            try:
                t=self._get_raw(title)
                if record_sha256(t)!=digest:violations.append(title+': source hash mismatch')
                violations.extend(title+': '+p for p in self._projection_problems(title,t))
            except (ValueError,KeyError,TypeError,json.JSONDecodeError) as exc:
                violations.append(title+': unparsable record: '+str(exc)[:100])
            count+=1
        return {'protected_records':count,'violations':violations[:20],
                'violation_count':len(violations)}

    def _projection_problems(self,title:str,raw:dict)->list[str]:
        """Compare the searchable columns and tag index with the stored source object."""
        row=self.conn.execute('SELECT title,text,created,modified,tags_json,fields_json '
                              'FROM tiddlers WHERE title=?',(title,)).fetchone()
        if row is None:return ['row absent']
        tags=parse_tags(raw.get('tags',[]))
        problems=[]
        if not (row['title']==raw.get('title')==title and row['text']==raw.get('text','') and
                row['created']==raw.get('created') and row['modified']==raw.get('modified') and
                json.loads(row['tags_json'])==tags and json.loads(row['fields_json'])==custom_fields(raw)):
            problems.append('normalized row inconsistent with original')
        found={r[0] for r in self.conn.execute('SELECT tag FROM tiddler_tags WHERE title=?',(title,))}
        if found!=set(tags):problems.append('tag index inconsistent')
        return problems

    def _get_raw(self,title:str)->Optional[dict]:
        row=self.conn.execute('''SELECT title,text,created,modified,tags_json,fields_json,raw_json
                                  FROM tiddlers WHERE title=?''',(title,)).fetchone()
        return self._row_record(row) if row else None

    @staticmethod
    def _row_record(row)->dict:
        if row['raw_json'] is not None:return json.loads(row['raw_json'])
        d={'title':row['title'],'text':row['text']}
        if row['created'] is not None:d['created']=row['created']
        if row['modified'] is not None:d['modified']=row['modified']
        tags=json.loads(row['tags_json'])
        if tags:d['tags']=encode_tags(tags)
        d.update(json.loads(row['fields_json']))
        return d

    def get_tiddler(self,title:str)->Optional[dict]:
        raw=self._get_raw(title)
        if raw is None:return None
        return dict(raw,title=title,text=raw.get('text',''),
                    tags=parse_tags(raw.get('tags',[])),
                    fields=custom_fields(raw))

    def search_title(self,query:str,limit:int=200,offset:int=0)->list[str]:
        # INSTR avoids LIKE wildcard interpretation and uses predictable case folding.
        return [r[0] for r in self.conn.execute('''SELECT title FROM tiddlers
                    WHERE instr(lower(title),lower(?))>0 ORDER BY title LIMIT ? OFFSET ?''',
                    (query,limit,offset))]
    def search_text(self,query:str,limit:int=200,offset:int=0)->list[str]:
        query=query.strip()
        if not query:return []
        terms=[t for t in query.split() if t]
        match=' AND '.join('"'+t.replace('"','""')+'"' for t in terms)
        try:
            return [r[0] for r in self.conn.execute('''SELECT title FROM tiddlers_fts
                         WHERE tiddlers_fts MATCH ? ORDER BY rank LIMIT ? OFFSET ?''',
                         (match,limit,offset))]
        except sqlite3.OperationalError:return []
    def titles_with_field_value(self,names,value:str,limit:int=500)->list[str]:
        """Titles whose custom field (any of ``names``) equals ``value``."""
        names=[names] if isinstance(names,str) else list(names)
        clause=' OR '.join('json_extract(fields_json,?)=?' for _ in names)
        params=[]
        for n in names: params+=['$.'+json.dumps(n),value]
        return [r[0] for r in self.conn.execute(
            f'SELECT title FROM tiddlers WHERE {clause} ORDER BY title LIMIT ?',(*params,limit))]
    def browse_titles(self,*,system:bool|None=None,any_tags=None,query:str='',mode:str='Title',
                      limit:int=200,offset:int=0)->list[str]:
        """Titles filtered by view and search together, so paging stays exact.

        system: True = only $:/ posts, False = exclude them, None = both.
        any_tags: only posts carrying at least one of these tags.
        mode: 'Title' (substring), 'Text' (full-text, ranked) or 'Tag' (exact tag).
        """
        where=[];params=[]
        if system is not None:
            where.append("substr(t.title,1,3)"+('=' if system else '!=')+"'$:/'")
        if any_tags is not None:
            tags=list(any_tags)
            if not tags:return []
            where.append('EXISTS(SELECT 1 FROM tiddler_tags g WHERE g.title=t.title AND g.tag IN (%s))'
                         % ','.join('?'*len(tags)))
            params+=tags
        query=query.strip()
        if query and mode=='Title':
            where.append('instr(lower(t.title),lower(?))>0');params.append(query)
        elif query and mode=='Tag':
            where.append('EXISTS(SELECT 1 FROM tiddler_tags g2 WHERE g2.title=t.title AND g2.tag=?)')
            params.append(query)
        elif query and mode!='Text':
            raise ValueError(f'Unsupported search mode: {mode!r}')
        clause=(' AND '.join(where)) or '1'
        if query and mode=='Text':
            match=' AND '.join('"'+term.replace('"','""')+'"' for term in query.split())
            sql=(f'SELECT t.title FROM tiddlers_fts f JOIN tiddlers t ON t.rowid=f.rowid '
                 f'WHERE tiddlers_fts MATCH ? AND {clause} ORDER BY f.rank LIMIT ? OFFSET ?')
            try:
                return [r[0] for r in self.conn.execute(sql,(match,*params,limit,offset))]
            except sqlite3.OperationalError:
                return []
        sql=f'SELECT t.title FROM tiddlers t WHERE {clause} ORDER BY t.title LIMIT ? OFFSET ?'
        return [r[0] for r in self.conn.execute(sql,(*params,limit,offset))]
    def titles_with_field(self,name:str,limit:int=5000)->list[str]:
        """Titles that have custom field ``name`` set (any value)."""
        return [r[0] for r in self.conn.execute(
            'SELECT title FROM tiddlers WHERE json_extract(fields_json,?) IS NOT NULL ORDER BY title LIMIT ?',
            ('$.'+json.dumps(name),limit))]
    def search_tag(self,tag:str,limit:int=200,offset:int=0)->list[str]:
        return [r[0] for r in self.conn.execute('''SELECT title FROM tiddler_tags
                      WHERE tag=? ORDER BY title LIMIT ? OFFSET ?''',(tag,limit,offset))]
    def filtered_title_links(self, expression:str, limit:int=500)->list[str]:
        # Deliberately small supported subset of TiddlyWiki filter syntax.
        import re
        match=re.fullmatch(r'\[tag\[([^\]]+)\]field:([a-zA-Z0-9_-]+)\[([^\]]+)\]sort\[([a-zA-Z0-9_-]+)\]\]',expression)
        if not match:return []
        tag,field,value,sort=match.groups()
        path='$.'+json.dumps(field)
        sortpath='$.'+json.dumps(sort)
        rows=self.conn.execute('SELECT t.title FROM tiddlers t JOIN tiddler_tags g ON g.title=t.title '
           'WHERE g.tag=? AND json_extract(t.fields_json,?)=? '
           'ORDER BY json_extract(t.fields_json,?),t.title LIMIT ?',
           (tag,path,value,sortpath,limit))
        return [x[0] for x in rows]

    def all_tags(self)->list[str]:
        return [r[0] for r in self.conn.execute('SELECT DISTINCT tag FROM tiddler_tags ORDER BY tag')]
    def all_titles(self,limit:int=200,offset:int=0)->list[str]:
        return [r[0] for r in self.conn.execute('SELECT title FROM tiddlers ORDER BY title LIMIT ? OFFSET ?',
                                               (limit,offset))]
    def count(self):return self.conn.execute('SELECT COUNT(*) FROM tiddlers').fetchone()[0]
    def integrity_report(self)->dict:
        integrity=self.conn.execute('PRAGMA integrity_check').fetchone()[0]
        fk=self.conn.execute('PRAGMA foreign_key_check').fetchall()
        fts=self.conn.execute('SELECT COUNT(*) FROM tiddlers_fts').fetchone()[0]
        fts_integrity=self._check_fts_integrity()
        total=self.count()
        return {'integrity':integrity,'foreign_key_violations':len(fk),
                'records':total,'fts_records':fts,'fts_matches':fts==total and fts_integrity is True,
                'fts_integrity':fts_integrity}
    def rebuild_search(self):
        if self.readonly:raise PermissionError('Read-only database')
        with self.conn:self.conn.execute("INSERT INTO tiddlers_fts(tiddlers_fts) VALUES('rebuild')")

    def export_json(self,json_path:str,overwrite:bool=False)->int:
        # SQLite read transaction gives a consistent view even under concurrent writes.
        self.conn.execute('BEGIN')
        try:
            rows=self.conn.execute('''SELECT title,text,created,modified,tags_json,fields_json,raw_json
                            FROM tiddlers ORDER BY title''').fetchall()
            docs=[self._row_record(r) for r in rows]
        finally:self.conn.rollback()  # release read transaction (never changes data)
        data=json.dumps(docs,ensure_ascii=False,indent=2).encode('utf-8')
        _write_atomic(Path(json_path),data,overwrite=overwrite)
        return len(docs)

