"""Project tracking on ordinary posts. Qt-free.

A post is a project item when it carries one of the kind tags below. Its
structure lives in TiddlyWiki-compatible string fields:

  status    planned | active | blocked | done | dropped   (required)
  parent    title of the parent item (a goal's project, a task's milestone…)
  due       YYYY-MM-DD
  priority  high | medium | low

The project kit installs one field contract per kind ($:/schema/<kind>). Users
may tighten them freely afterwards (e.g. make ``parent`` required for tasks);
loosening asks for acknowledgement. Nothing here bypasses the history layer.
"""
from __future__ import annotations

from datetime import date, timedelta
import json

import field_schema as fs

KINDS = ('project', 'goal', 'milestone', 'task')
STATUSES = ('planned', 'active', 'blocked', 'done', 'dropped')
OPEN_STATUSES = ('planned', 'active', 'blocked')
PRIORITIES = ('high', 'medium', 'low')
GUIDE_TITLE = '10 — Managing Projects'


def kit_schema(kind: str) -> dict:
    return {
        'type': 'object',
        'properties': {
            'status': {'type': 'string', 'enum': list(STATUSES)},
            'parent': {'type': 'string', 'minLength': 1},
            'due': {'type': 'string', 'format': 'date'},
            'priority': {'type': 'string', 'enum': list(PRIORITIES)},
        },
        'required': ['status'],
    }


GUIDE_TEXT = """! Managing projects

Project items are ordinary posts with one of the tags `project`, `goal`, `milestone` or `task`.
Use ''Tiddler → New Project Item…'' to create one, or ''View → Project Dashboard'' to see them all.

!! Fields

|!Field |!Values |
|status |planned, active, blocked, done, dropped (required) |
|parent |title of the item this belongs to |
|due |a date such as 2026-12-31 |
|priority |high, medium, low |

Edit fields in the editor's ''Fields'' table. The editor shows the contract for the post's tags.

!! Contracts (typed fields)

Each kind's fields are checked against a contract post such as [[$:/schema/task]].
A contract is JSON; it is versioned like any other post and every change needs a reason.

* ''Tightening'' a contract (for example adding `"parent"` to `required`) is accepted directly.
* ''Loosening'' it, deleting it, or tightening it while existing posts would break asks you to acknowledge the change. The history reason is marked `[contract change acknowledged by owner]`.
* A post that fails its contract cannot be saved; posts that already fail after an acknowledged change are listed on the dashboard.

!! Restoring

''Tiddler → View Post History…'' can restore any recorded version. Restoring writes a new version; it never rewrites history.
"""


def kit_records() -> list[dict]:
    records = []
    for kind in KINDS:
        records.append({'title': fs.schema_title(kind), 'type': 'application/json',
                        'tags': '$:/tags/FieldContract',
                        'text': json.dumps(kit_schema(kind), indent=2)})
    records.append({'title': GUIDE_TITLE, 'tags': 'Guide', 'text': GUIDE_TEXT})
    return records


def kind_of(post: dict) -> str | None:
    tags = post.get('tags') or []
    for kind in KINDS:
        if kind in tags:
            return kind
    return None


def due_state(due: str | None, status: str | None, today: date) -> str | None:
    """'overdue' / 'soon' (within 7 days) / 'later' for open items, 'closed', 'invalid' or None."""
    if not due:
        return None
    try:
        d = date.fromisoformat(due)
    except ValueError:
        return 'invalid'
    if status not in OPEN_STATUSES:
        return 'closed'
    if d < today:
        return 'overdue'
    if d <= today + timedelta(days=7):
        return 'soon'
    return 'later'


def children_of(core, title: str) -> list[dict]:
    """Direct project-item children of ``title`` (via their parent field), sorted by kind."""
    rows = []
    for child in core.titles_with_field_value('parent', title):
        post = core.get_tiddler(child)
        kind = kind_of(post) if post else None
        if kind is None:
            continue
        f = post.get('fields', {})
        rows.append({'title': child, 'kind': kind, 'status': f.get('status'), 'due': f.get('due')})
    return sorted(rows, key=lambda r: (KINDS.index(r['kind']), r['title'].lower()))


def overview(core, today: date | None = None) -> dict:
    """Compute the project tree and attention lists from current posts."""
    today = today or date.today()
    items: dict[str, dict] = {}
    for kind in KINDS:
        offset = 0
        while True:
            titles = core.search(kind, mode='Tag', limit=500, offset=offset)
            for title in titles:
                if title in items:
                    continue
                post = core.get_tiddler(title)
                if post is None or kind_of(post) is None:
                    continue
                f = post.get('fields', {})
                items[title] = {
                    'title': title, 'kind': kind_of(post),
                    'status': f.get('status') if isinstance(f.get('status'), str) else None,
                    'parent': f.get('parent') if isinstance(f.get('parent'), str) and f.get('parent') else None,
                    'due': f.get('due') if isinstance(f.get('due'), str) and f.get('due') else None,
                    'priority': f.get('priority') if isinstance(f.get('priority'), str) else None,
                    'protected': core.is_protected(title),
                }
            if len(titles) < 500:
                break
            offset += 500
    children: dict[str, list[str]] = {}
    orphans, cycles = [], []
    for title, item in items.items():
        parent = item['parent']
        if parent is None:
            continue
        if parent not in items:
            orphans.append(title)
            continue
        children.setdefault(parent, []).append(title)
    order = {k: i for i, k in enumerate(KINDS)}
    prio = {p: i for i, p in enumerate(PRIORITIES)}

    def sort_key(t):
        it = items[t]
        return (order[it['kind']], it['status'] in ('done', 'dropped'),
                prio.get(it['priority'], 9), it['due'] or '9999', t.lower())

    for kids in children.values():
        kids.sort(key=sort_key)

    def descendants(root: str) -> list[str]:
        out, stack, seen = [], list(children.get(root, [])), {root}
        while stack:
            t = stack.pop()
            if t in seen:
                if t == root and root not in cycles:
                    cycles.append(root)
                continue
            seen.add(t)
            out.append(t)
            stack.extend(children.get(t, []))
        return out

    # Detect parent cycles explicitly (A→B→A never reaches a root).
    for title in items:
        seen, cur = set(), title
        while cur is not None and cur in items and cur not in seen:
            seen.add(cur)
            cur = items[cur]['parent']
        if cur == title and title not in cycles:
            cycles.append(title)

    roots = sorted((t for t, it in items.items()
                    if it['kind'] == 'project' and (it['parent'] is None or it['parent'] not in items)),
                   key=sort_key)
    projects = []
    for root in roots:
        desc = [t for t in descendants(root) if items[t]['kind'] != 'project']
        counts = {s: 0 for s in STATUSES}
        for t in desc:
            if items[t]['status'] in counts:
                counts[items[t]['status']] += 1
        live = len(desc) - counts['dropped']
        progress = (counts['done'] / live) if live else None
        projects.append({'title': root, 'item': items[root], 'counts': counts,
                         'total': len(desc), 'progress': progress})
    attached = set(roots)
    for r in roots:
        attached.update(descendants(r))
    # Orphans and cycle members are already reported under "Needs attention".
    unfiled = sorted((t for t in items if t not in attached and t not in orphans
                      and t not in cycles), key=sort_key)
    overdue, soon, blocked = [], [], []
    for t, it in items.items():
        if it['status'] == 'blocked':
            blocked.append(t)
        state = due_state(it['due'], it['status'], today)
        if state == 'overdue':
            overdue.append(t)
        elif state == 'soon':
            soon.append(t)
    by_due = lambda t: (items[t]['due'] or '', t)
    try:
        violations = core.contract_violations()
        contract_error = None
    except fs.SchemaError as exc:
        violations, contract_error = [], str(exc)
    return {'today': today.isoformat(), 'items': items, 'children': children,
            'projects': projects, 'unfiled': unfiled, 'orphans': sorted(orphans),
            'cycles': sorted(cycles), 'overdue': sorted(overdue, key=by_due),
            'due_soon': sorted(soon, key=by_due), 'blocked': sorted(blocked),
            'violations': violations, 'contract_error': contract_error}
