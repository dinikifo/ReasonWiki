"""Change log: a chain of posts recording what changed, for reading and checking.

Entries are ordinary posts tagged ``changelog``:

* one **daily** entry per day with edits, listing every history event of
  that day (time, post, change, reason) with links to the posts;
* one **PVS refresh** entry per refresh, written in the same transaction as
  the refresh (what came from PVS, what is still to enter, conflicts…).

Each entry links the previous one (``log_prev``) and records the SHA-256 of
the previous entry as stored (``log_prev_sha256``). When a new entry is added
the previous one is protected, so its digest is also checked every time the
notebook opens. ``verify`` walks the whole chain. Only the newest entry (the
tip) can still change: today's daily entry grows as the day goes on.

Qt-free. Events are grouped by their UTC date, as stored in the history.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import re

from db import record_sha256

TAG = 'changelog'
TITLE_PREFIX = 'Change log '
_TITLE = re.compile(r'^Change log \d{4,} — ')
REFRESH_REASON_PREFIX = 'PVS refresh'


def entries(core) -> list[dict]:
    """All entries, oldest first: {'title', 'seq', 'kind', 'record'}."""
    out = []
    for title in core.search(TAG, mode='Tag', limit=100000):
        raw = core.raw_record(title)
        try:
            seq = int(raw.get('log_seq', ''))
        except ValueError:
            seq = 0
        out.append({'title': title, 'seq': seq, 'kind': raw.get('log_kind'), 'record': raw})
    return sorted(out, key=lambda e: (e['seq'], e['title']))


def _unique_title(core, title: str, taken: set) -> str:
    candidate, n = title, 2
    while candidate in taken or core.get_tiddler(candidate) is not None:
        candidate = f'{title} ({n})'
        n += 1
    taken.add(candidate)
    return candidate


def _cell(text: str) -> str:
    return (text or '').replace('|', '/').replace('\n', ' ')


def _daily_text(date: str, events: list[dict], prev: dict | None) -> str:
    lines = [f'! Edits on {date}', '']
    lines.append(f"Previous entry: [[{prev['title']}]]" if prev else 'First entry of this notebook.')
    lines += ['', f'{len(events)} change(s), times in UTC.', '', '|!Time |!Post |!Change |!Reason |']
    for e in events:
        title = e['title'] or e['old_title'] or '?'
        lines.append(f"|{e['changed_at'][11:16]} |[[{title}]] |{e['change_type']} |{_cell(e['reason'])} |")
    return '\n'.join(lines) + '\n'


def _entry_record(title, kind, seq, date, text, prev, extra=None) -> dict:
    record = {'title': title, 'tags': [TAG], 'text': text, 'log_kind': kind, 'log_seq': str(seq),
              'log_date': date}
    if prev:
        record['log_prev'] = prev['title']
    record.update(extra or {})
    return record


def _append_changes(core, chain: list[dict], record: dict, reason: str) -> list[dict]:
    """Batch changes that add ``record`` after the current tip (and protect the tip)."""
    changes = []
    tip = chain[-1] if chain else None
    change = {'title': None, 'record': record, 'reason': reason}
    if tip is not None:
        changes.append({'title': tip['title'], 'protect_only': True})
        change['link_prev'] = tip['title']
    changes.append(change)
    return changes


def _loggable(event: dict, log_titles: set) -> bool:
    """Daily entries list user edits; log posts and refresh writes are logged elsewhere."""
    titles = (event['title'] or '', event['old_title'] or '')
    return not (any(_TITLE.match(t) or t in log_titles for t in titles)
                or (event['reason'] or '').startswith(REFRESH_REASON_PREFIX))


def catch_up(core, now: datetime | None = None) -> list[str]:
    """Write daily entries for every edit not yet logged. Returns titles written."""
    chain = entries(core)
    log_titles = {e['title'] for e in chain}
    covered = max((int(e['record'].get('log_last_event') or 0) for e in chain), default=0)
    new_events = core.events_since(covered)
    by_date: dict[str, list[dict]] = {}
    for e in new_events:
        if _loggable(e, log_titles):
            by_date.setdefault(e['changed_at'][:10], []).append(e)
    if not by_date:
        return []
    last_id = new_events[-1]['event_id']  # everything up to here is now covered
    changes, written, taken = [], [], set(log_titles)
    dates = sorted(by_date)
    for date in dates:
        events = by_date[date]
        last_of_day = last_id if date == dates[-1] else events[-1]['event_id']
        tip = chain[-1] if chain else None
        if tip and tip['kind'] == 'daily' and tip['record'].get('log_date') == date:
            # The day's entry is still the newest: rebuild it with the new events added.
            first = int(tip['record'].get('log_first_event') or events[0]['event_id'])
            day = [e for e in core.events_since(first - 1)
                   if e['event_id'] <= last_of_day and e['changed_at'][:10] == date
                   and _loggable(e, log_titles)]
            record = dict(tip['record'],
                          text=_daily_text(date, day, chain[-2] if len(chain) > 1 else None),
                          log_last_event=str(last_of_day))
            changes.append({'title': tip['title'], 'record': record,
                            'reason': f'Change log: {len(events)} more change(s) on {date}'})
            tip['record'] = record
            written.append(tip['title'])
            continue
        seq = (tip['seq'] if tip else 0) + 1
        # The sequence number keeps titles unique and sorts the list in chain order.
        title = _unique_title(core, f'{TITLE_PREFIX}{seq:04d} — {date} — edits', taken)
        record = _entry_record(title, 'daily', seq, date, _daily_text(date, events, tip), tip,
                               {'log_first_event': str(events[0]['event_id']),
                                'log_last_event': str(last_of_day)})
        changes += _append_changes(core, chain, record, f'Change log: {len(events)} change(s) on {date}')
        chain.append({'title': title, 'seq': seq, 'kind': 'daily', 'record': record})
        written.append(title)
    core.write_batch(changes)
    return written


def refresh_entry_changes(core, text: str, summary_fields: dict, now: datetime | None = None) -> tuple[str, list[dict]]:
    """Batch changes adding a PVS refresh entry (call catch_up first)."""
    now = now or datetime.now(timezone.utc)
    chain = entries(core)
    tip = chain[-1] if chain else None
    seq = (tip['seq'] if tip else 0) + 1
    stamp = now.strftime('%Y-%m-%d %H:%M:%S')
    title = _unique_title(core, f'{TITLE_PREFIX}{seq:04d} — {stamp} — PVS refresh', {e['title'] for e in chain})
    prev_line = f"Previous entry: [[{tip['title']}]]\n\n" if tip else 'First entry of this notebook.\n\n'
    record = _entry_record(title, 'pvs-refresh', seq, now.strftime('%Y-%m-%d'),
                           f'! PVS refresh — {stamp} UTC\n\n' + prev_line + text, tip, summary_fields)
    return title, _append_changes(core, chain, record, f'{REFRESH_REASON_PREFIX}: change log entry')


def verify(core) -> dict:
    """Walk the chain: order, links, digests and protection. Never raises."""
    chain = entries(core)
    problems = []
    for i, e in enumerate(chain):
        rec = e['record']
        if e['seq'] != i + 1:
            problems.append(f"{e['title']}: sequence {e['seq']} where {i + 1} was expected "
                            '(an entry is missing or duplicated)')
        if i == 0:
            if rec.get('log_prev'):
                problems.append(f"{e['title']}: first entry links a previous entry {rec['log_prev']!r}")
            continue
        prev = chain[i - 1]
        if rec.get('log_prev') != prev['title']:
            problems.append(f"{e['title']}: links {rec.get('log_prev')!r} but the previous entry is "
                            f"{prev['title']!r}")
        elif rec.get('log_prev_sha256') != record_sha256(prev['record']):
            problems.append(f"{e['title']}: the previous entry {prev['title']!r} changed after it was linked")
        if not core.is_protected(prev['title']):
            problems.append(f"{prev['title']}: should be protected (it is no longer the newest entry)")
    return {'entries': len(chain), 'tip': chain[-1]['title'] if chain else None,
            'verified': not problems, 'problems': problems}


def summary_json(data: dict) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True)
