"""Turn a PVS-01 snapshot (JSON) into wiki records. Never loads PVS code.

PVS data reaches the wiki only as a "pvs-snapshot" JSON document (see
tools/pvs_export.py). Either the wiki runs that exporter in a SEPARATE process
(``run_export``), or you give it a snapshot file exported elsewhere
(``load_snapshot``). This module then maps PVS's domain data onto posts for
the project kit (tags project/goal/milestone + ``pvs``), keeping every
original PVS value in ``pvs_*`` fields.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

EXPORTER = Path(__file__).resolve().parents[1] / 'tools' / 'pvs_export.py'
FORMAT, VERSION = 'pvs-snapshot', 1


class PVSBridgeError(RuntimeError):
    pass


GOAL_STATUS = {'PENDING': 'planned', 'ACTIVE': 'active', 'COMPLETE': 'done',
               'BLOCKED': 'blocked', 'DELETED': 'dropped'}
MILESTONE_STATUS = {'PENDING': 'planned', 'ACTIVE': 'active', 'COMPLETE': 'done',
                    'STOPPED': 'blocked'}


def project_status(project: dict) -> str:
    if project['decision'] == 'REJECTED':
        return 'dropped'
    if project['archived']:
        return 'done'
    if project['decision'] == 'ACCEPTED':
        return {'ACTIVE': 'active', 'STOPPED': 'blocked'}.get(project['work_status'], 'planned')
    return 'planned'


def run_export(workspace: str | Path, pvs_src: str | None = None, timeout: int = 300) -> dict:
    """Run tools/pvs_export.py in its own process and return the parsed snapshot."""
    root = Path(workspace).expanduser()
    if root.is_symlink() or not (root / 'objects').is_dir():
        raise PVSBridgeError(f'{root} is not a PVS workspace (no objects/ folder). '
                             'Choose the folder passed to PVSWorkspace(...), usually "db".')
    command = [sys.executable, str(EXPORTER), str(root)]
    src = pvs_src or os.environ.get('PVS_SRC')
    if src:
        command += ['--pvs-src', str(src)]
    try:
        done = subprocess.run(command, capture_output=True, text=True, encoding='utf-8', timeout=timeout)
    except subprocess.TimeoutExpired as exc:
        raise PVSBridgeError(f'The PVS export took longer than {timeout} s') from exc
    if done.returncode != 0:
        message = done.stderr.strip().removeprefix('pvs_export: ') or 'unknown error'
        if 'Cannot import PVS' in message:
            raise PVSBridgeError('Cannot import PVS. Choose the PVS "src" folder '
                                 '(the one containing fd_oop_reconstruction) or set PVS_SRC.')
        raise PVSBridgeError(message)
    return check_snapshot(json.loads(done.stdout))


def load_snapshot(path: str | Path) -> dict:
    """Read a snapshot file written by tools/pvs_export.py (possibly on another machine)."""
    try:
        return check_snapshot(json.loads(Path(path).read_text(encoding='utf-8')))
    except ValueError as exc:
        raise PVSBridgeError(f'{path} is not a PVS snapshot: {exc}') from exc


def check_snapshot(snapshot) -> dict:
    if not isinstance(snapshot, dict) or snapshot.get('format') != FORMAT:
        raise PVSBridgeError('Not a PVS snapshot (format must be "pvs-snapshot")')
    if snapshot.get('version') != VERSION:
        raise PVSBridgeError(f"Unsupported PVS snapshot version {snapshot.get('version')!r}; "
                             f'this wiki reads version {VERSION}')
    ws = snapshot.get('workspace')
    if not isinstance(ws, dict) or not isinstance(ws.get('id'), str) or not isinstance(snapshot.get('objects'), list):
        raise PVSBridgeError('PVS snapshot is missing its workspace id or objects')
    for o in snapshot['objects']:
        if not isinstance(o, dict) or not {'object_id', 'contract', 'revision', 'pin_seq', 'pin_digest',
                                           'verdict', 'data'} <= set(o):
            raise PVSBridgeError('PVS snapshot has a malformed object entry')
    return snapshot


def _argument_lines(args: list[dict], indent: str = '*') -> list[str]:
    lines = []
    for a in args:
        lines.append(f"{indent} ''{a.get('claim', '')}''" +
                     (f" //({a['qualifier']})//" if a.get('qualifier') else ''))
        for key in ('grounds', 'warrant', 'backing', 'rebuttal'):
            if a.get(key):
                lines.append(f"{indent}* {key.capitalize()}: {a[key]}")
    return lines or [f'{indent} //none recorded//']


def snapshot_records(pvs_root: str | Path, *, pvs_src: str | None = None,
                     prefix: str = 'PVS', timeless: bool = False) -> tuple[list[dict], dict]:
    """Export the workspace (separate process) and map it. See records_from_snapshot."""
    return records_from_snapshot(run_export(pvs_root, pvs_src), prefix=prefix, timeless=timeless)


def records_from_snapshot(snapshot: dict, *, prefix: str = 'PVS',
                          timeless: bool = False) -> tuple[list[dict], dict]:
    """Map a checked snapshot onto wiki records.

    ``timeless=True`` keeps time and folder paths out of the posts (the sync records
    them in the change log), so an unchanged PVS yields unchanged posts.
    """
    snapshot = check_snapshot(snapshot)
    root = snapshot['workspace'].get('root', '')
    taken = snapshot.get('exported_at', '')[:16].replace('T', ' ') + ' UTC'
    records: list[dict] = []
    index_lines = ['! PVS snapshot', '',
                   'Snapshot of a PVS workspace.' if timeless else f'Snapshot of `{root}` taken {taken}.',
                   ('Change projects in PVS, then refresh.' if timeless else
                    'Every post here is protected; change projects in PVS and take a new snapshot.'), '',
                   '|!Object |!Contract |!Event pin |!History |']
    versioners, targets = [], []
    for o in snapshot['objects']:
        info = {'pin_seq': o['pin_seq'], 'pin_digest': o['pin_digest'], 'revision': o['revision'],
                'verdict': o['verdict'], 'state': {'data': o['data']}}
        index_lines.append(f"|{o['object_id']} |{o['contract']} |{o['pin_seq']} "
                           f"(`{o['pin_digest'][:12]}`) |{o['verdict']} |")
        if o['contract'] == 'pvs.inspect@1.0':
            versioners.append((o['object_id'], info))
        elif o['contract'] == 'pvs.controlled.inspect@1.0':
            targets.append((o['object_id'], info))
    if not versioners:
        raise PVSBridgeError('No PVS versioning object found in this snapshot')
    index_title = f'{prefix} snapshot'
    project_links = []
    target_titles = {}
    for oid, info in targets:
        title = f'{prefix}/target/{oid}'
        target_titles[oid] = title
        records.append({
            'title': title, 'tags': 'pvs pvs-target',
            'pvs_object': oid, 'pvs_revision': str(info['revision']),
            'pvs_history': info['verdict'], 'pvs_pin': f"{info['pin_seq']}:{info['pin_digest']}",
            'text': '! Controlled object\n\nIndependent PVS object (its own revision and history).\n\n'
                    '```\n' + json.dumps(info['state']['data'], indent=2, ensure_ascii=False) + '\n```\n',
        })
    for vid, info in versioners:
        data = info['state']['data']
        common = {'pvs_object': vid, 'pvs_revision': str(info['revision']),
                  'pvs_history': info['verdict'], 'pvs_pin': f"{info['pin_seq']}:{info['pin_digest']}"}
        for project in data['projects']:
            pid = project['project_id']
            ptitle = f'{prefix}/{vid}/{pid}'
            project_links.append(ptitle)
            goal_titles = {}
            for side in ('acceptance', 'rejection'):
                for g in project['rfc'][side]['goal_plan']:
                    goal_titles[g['goal']['goal_id']] = f"{ptitle}/{g['goal']['goal_id']}"
            lines = [f'! Project {pid}', '',
                     f"Decision: ''{project['decision']}'' · Work: ''{project['work_status']}''"
                     + (' · archived' if project['archived'] else ''), '']
            target = project['target_object']
            lines.append(f'Controlled object: [[{target_titles[target]}]]' if target in target_titles
                         else f'Controlled object: {target} //(not in snapshot)//')
            for side, label in (('acceptance', 'Acceptance RFC'), ('rejection', 'Rejection RFC')):
                rfc = project['rfc'][side]
                lines += ['', f'!! {label}', ''] + _argument_lines(rfc['arguments'])
                if rfc['goal_plan']:
                    lines += ['', 'Goals:'] + [f"* [[{goal_titles[g['goal']['goal_id']]}]] — {g['goal']['text']}"
                                               for g in rfc['goal_plan']]
            if project['dependencies']:
                lines += ['', '!! Goal dependencies', '']
                for gid, needs in sorted(project['dependencies'].items()):
                    lines.append(f"* [[{goal_titles[gid]}]] needs " +
                                 (', '.join(f'[[{goal_titles[n]}]]' for n in needs) or '—'))
            if project['decisions']:
                lines += ['', '!! Decisions', ''] + [f"# ''{d['kind']}'' — {d['reason']}"
                                                     for d in project['decisions']]
            records.append({'title': ptitle, 'tags': 'project pvs', 'status': project_status(project),
                            'pvs_decision': project['decision'], 'pvs_work_status': project['work_status'],
                            'pvs_archived': 'yes' if project['archived'] else 'no',
                            'pvs_project': pid, **common, 'text': '\n'.join(lines) + '\n',
                            'pvs_arguments': json.dumps({side: project['rfc'][side]['arguments']
                                                         for side in ('acceptance', 'rejection')},
                                                        ensure_ascii=False, sort_keys=True)})
            for side in ('acceptance', 'rejection'):
                for g in project['rfc'][side]['goal_plan']:
                    goal = g['goal']
                    gtitle = goal_titles[goal['goal_id']]
                    needs = project['dependencies'].get(goal['goal_id'], [])
                    glines = [f"! {goal['text']}", '',
                              f"Branch: ''{side}''" + (' //(evidence for rejecting the project)//'
                                                       if side == 'rejection' else ''), '',
                              '!! Arguments for', ''] + _argument_lines(g['arguments']['for']) + \
                             ['', '!! Arguments against', ''] + _argument_lines(g['arguments']['against'])
                    if needs:
                        glines += ['', 'Depends on: ' + ', '.join(f'[[{goal_titles[n]}]]' for n in needs)]
                    # Rejection-branch goals are evidence for NOT doing the project, not
                    # planned work (PVS G3 finding R16), so they are not project items.
                    kind_tags = 'goal pvs' if side == 'acceptance' else 'pvs pvs-evidence'
                    records.append({'title': gtitle, 'tags': kind_tags, 'parent': ptitle,
                                    'status': GOAL_STATUS[goal['status']], 'pvs_status': goal['status'],
                                    'pvs_branch': side, 'pvs_goal': goal['goal_id'], **common,
                                    'pvs_project': pid, 'text': '\n'.join(glines) + '\n',
                                    'pvs_arguments': json.dumps({'for': g['arguments']['for'],
                                                                 'against': g['arguments']['against']},
                                                                ensure_ascii=False, sort_keys=True)})
                    for m in g['milestones']:
                        mtitle = f"{gtitle}/{m['milestone_id']}"
                        mlines = [f"! Milestone {m['milestone_id']}", '', '!! Recorded files', '']
                        for f in m['files'] or []:
                            mlines.append(f"* `{f['path']}` — sha256 `{f['sha256']}`")
                            mlines += _argument_lines(f['arguments'], '**')
                        if not m['files']:
                            mlines.append('//no files recorded//')
                        mlines += ['', '!! Stop arguments', ''] + _argument_lines(m['stop_arguments'])
                        mlines += ['', '!! Resume arguments', ''] + _argument_lines(m['resume_arguments'])
                        records.append({'title': mtitle, 'parent': gtitle,
                                        'tags': 'milestone pvs' if side == 'acceptance' else 'pvs pvs-evidence',
                                        'status': MILESTONE_STATUS[m['status']], 'pvs_status': m['status'],
                                        'pvs_milestone': m['milestone_id'],
                                        'pvs_files': str(len(m['files'])), **common,
                                        'text': '\n'.join(mlines) + '\n'})
    index_lines += ['', '!! Projects', ''] + [f'* [[{t}]]' for t in project_links] + \
                   ['', 'Open //View → Project Dashboard// for the tree. Goals on a project\'s '
                    'rejection branch are evidence, not work: they are tagged `pvs-evidence`, '
                    'are linked from the project post, and are not counted in progress.']
    records.insert(0, {'title': index_title, 'tags': 'pvs', 'text': '\n'.join(index_lines) + '\n',
                       'pvs_object': '(index)', **({} if timeless else {'pvs_root': root, 'pvs_taken': taken})})
    summary = {'root': root, 'workspace_id': snapshot['workspace']['id'], 'taken': taken,
               'index': index_title, 'projects': len(project_links), 'records': len(records),
               'objects': [{'object': o['object_id'], 'seq': o['pin_seq']} for o in snapshot['objects']]}
    return records, summary
