"""HTML views for posts and generated pages. Qt-free, no I/O beyond WikiCore reads.

All generated markup lives here: the fields panel, the Toulmin argument box,
project documents and children, the Kanban board, the Waterfall strip, the
project dashboard and the contracts page. Data comes from projects.py,
forms.py and field_schema.py; every user string is escaped here.

Layout uses tables rather than flexbox so the Qt-text fallback preview (no
WebEngine, e.g. on a Raspberry Pi) shows the same structure.
"""
from __future__ import annotations

from datetime import date
from html import escape
import json
from urllib.parse import quote

import field_schema as fs
import forms
import projects
from renderer import TiddlyRenderer, render_tiddler
from db import record_sha256

CSS = """
.pill { display:inline-block; padding:1px 8px; border-radius:10px; font-size:.8em; background:#eee; color:#555; }
.s-active { background:#e3f2fd; color:#1565c0; } .s-planned { background:#f3f3f3; color:#666; }
.s-blocked { background:#fdecea; color:#b71c1c; } .s-done { background:#e8f5e9; color:#2e7d32; }
.s-dropped { background:#f5f5f5; color:#999; text-decoration:line-through; } .s-unset { background:#fff3e0; color:#e65100; }
.due { font-size:.8em; color:#666; margin-left:6px; } .due.overdue { color:#b71c1c; font-weight:600; }
.due.soon { color:#e65100; } .due.invalid { color:#b71c1c; }
.kind { font-size:.75em; color:#888; text-transform:uppercase; letter-spacing:.04em; margin-right:6px; }
.bar { background:#eee; border-radius:4px; height:8px; width:160px; display:inline-block; vertical-align:middle; margin-left:8px; }
.bar span { display:block; height:8px; border-radius:4px; background:#43a047; }
ul.tree { list-style:none; padding-left:18px; margin:4px 0; } ul.tree li { margin:3px 0; }
.card { border:1px solid #e5e5e5; border-radius:6px; padding:10px 14px; margin:12px 0; }
.card h3 { margin:0 0 6px 0; }
.attention li { margin:2px 0; } .muted { color:#888; font-size:.9em; }
.fieldpanel { border:1px solid #e5e5e5; background:#fafafa; border-radius:6px; padding:8px 12px; margin:10px 0; }
.fieldpanel table { margin:4px 0; } .fieldpanel td, .fieldpanel th { border:none; padding:2px 10px 2px 0; background:none; }
.warn { color:#b71c1c; }
.toulmin { border-left:4px solid #7e57c2; background:#f6f3fb; padding:8px 14px; margin:10px 0; border-radius:4px; }
.toulmin .claim { font-size:1.08em; font-weight:600; }
.toulmin .row { margin:4px 0; } .toulmin .lbl { color:#7e57c2; font-size:.78em; text-transform:uppercase; letter-spacing:.05em; margin-right:6px; }
.board { border-collapse:separate; border-spacing:8px 0; table-layout:fixed; width:100%; margin:10px 0; }
.board td, .board th { border:none; } .board tr:nth-child(even) { background:none; }
.lane { background:#f4f5f7; border-radius:6px; padding:8px; vertical-align:top; }
.lane h4 { margin:0 0 6px 0; font-size:.9em; } .lane.over { background:#fdecea; }
.cardx { background:#fff; border:1px solid #e1e4e8; border-radius:5px; padding:6px 8px; margin:6px 0; font-size:.92em; }
.phases { border-collapse:separate; border-spacing:4px 0; table-layout:fixed; width:100%; margin:12px 0; }
.phases td { border:none; } .phases tr:nth-child(even) { background:none; }
.phase { text-align:center; padding:8px 4px; border-radius:4px; background:#eceff1; color:#78909c; font-size:.85em; }
.phase.past { background:#e8f5e9; color:#2e7d32; } .phase.now { background:#1565c0; color:#fff; font-weight:600; }
.phase.late { background:#b71c1c; color:#fff; font-weight:600; }
.phase small { display:block; font-weight:400; opacity:.9; }
.docs li { margin:2px 0; }
.frompvs { border:1px solid #c5cae9; background:#f5f6fc; border-radius:6px; padding:8px 12px; margin:10px 0; }
.frompvs .head { color:#3949ab; font-size:.85em; text-transform:uppercase; letter-spacing:.05em; }
.notice { border-left:4px solid #e65100; background:#fff8e1; padding:6px 12px; margin:8px 0; }
.notice.bad { border-color:#b71c1c; background:#fdecea; } .notice.ok { border-color:#2e7d32; background:#e8f5e9; }
"""
_PHASE_BG = {'past': '#e8f5e9', 'now': '#bbdefb', 'late': '#ffcdd2'}


# --- small helpers --------------------------------------------------------
def link(title: str, label: str | None = None) -> str:
    return (f'<a href="tw://tiddler/{quote(title, safe="")}">'
            f'{escape(label if label is not None else title)}</a>')


def pill(status: str | None) -> str:
    s = status or 'unset'
    return f'<span class="pill s-{escape(s)}">{escape(s)}</span>'


def due_label(due: str | None, status: str | None, today: date) -> str:
    state = projects.due_state(due, status, today)
    if state is None:
        return ''
    text = {'overdue': f'due {due} · overdue', 'invalid': f'due {due}?'}.get(state, f'due {due}')
    cls = state if state in ('overdue', 'soon', 'invalid') else ''
    return f' &nbsp;<span class="due {cls}">{escape(text)}</span>'


def with_css(document: str) -> str:
    return document if CSS in document else document.replace('</style>', CSS + '</style>', 1)


def page(title: str, inner_html: str) -> str:
    """A full generated document (dashboard, contracts…) in the post style."""
    doc = with_css(render_tiddler({'title': title, 'text': ''}))
    start = doc.index('<div class="content">')
    end = doc.rindex('</div>\n</body>')
    return doc[:start] + '<div class="content">' + inner_html + doc[end:]


def item_line(ov: dict, title: str) -> str:
    it = ov['items'][title]
    today = date.fromisoformat(ov['today'])
    prio = f' &nbsp;<span class="muted">{escape(it["priority"])} priority</span>' if it['priority'] else ''
    lock = ' <span class="muted">🔒</span>' if it['protected'] else ''
    return (f'<span class="kind">{escape(it["kind"])}</span>&nbsp; {link(title)} &nbsp;{pill(it["status"])}'
            f'{due_label(it["due"], it["status"], today)}{prio}{lock}')


# --- panels shown above a post's text ---------------------------------------
def toulmin_box(fields: dict) -> str:
    def g(key):
        value = fields.get(key)
        return escape(value) if isinstance(value, str) and value else ''
    if not any(g(k) for k in forms.TOULMIN):
        return ''
    rows = [f'<div class="row claim"><span class="lbl">Claim</span>&nbsp; {g("claim") or "<i>missing</i>"}'
            + (f' &nbsp;<span class="lbl">qualifier</span>&nbsp; <i>{g("qualifier")}</i>' if g('qualifier') else '')
            + '</div>']
    for key, label in (('grounds', 'because'), ('warrant', 'since'), ('backing', 'on account of'),
                       ('rebuttal', 'unless')):
        if g(key):
            rows.append(f'<div class="row"><span class="lbl">{label}</span>&nbsp; {g(key)}</div>')
    return '<div class="toulmin">' + ''.join(rows) + '</div>'


def field_panel(core, post: dict, hide: frozenset = frozenset()) -> str:
    """Fields table, contract status and (for project items) children."""
    all_fields = post.get('fields') or {}
    fields = {k: v for k, v in all_fields.items() if k not in hide}
    kind = projects.kind_of(post)
    try:
        schemas = core.field_schemas()
    except fs.SchemaError as exc:
        return f'<div class="fieldpanel warn">{escape(str(exc))}</div>'
    governed = [t for t in post.get('tags') or [] if t in schemas]
    if not fields and not governed and kind is None:
        return ''
    first = ('status', 'parent', 'due', 'priority')
    rows = []
    for name in sorted(fields, key=lambda n: (first.index(n) if n in first else 9, n)):
        value = fields[name]
        if name == 'status' and isinstance(value, str):
            cell = pill(value)
        elif name == 'parent' and isinstance(value, str) and value:
            cell = link(value) if core.get_tiddler(value) else f'{escape(value)} <span class="warn">(missing)</span>'
        else:
            cell = escape(value if isinstance(value, str) else json.dumps(value, ensure_ascii=False))
        rows.append(f'<tr><th>{escape(name)}</th><td>{cell}</td></tr>')
    status = []
    for t in governed:
        label = link(fs.schema_title(t), 'contract ' + t)
        try:
            fs.validate(dict(all_fields), schemas[t])
            status.append(f'{label} ✓')
        except fs.SchemaError as exc:
            status.append(f'<span class="warn">{label}: {escape(str(exc))}</span>')
    kids = ''
    if kind is not None:
        children = projects.children_of(core, post['title'])
        if children:
            today = date.today()
            kids = ('<div><b>Children</b><ul class="tree">' + ''.join(
                f'<li><span class="kind">{escape(c["kind"])}</span>&nbsp; {link(c["title"])} &nbsp;'
                f'{pill(c["status"])}{due_label(c["due"], c["status"], today)}</li>' for c in children) +
                '</ul></div>')
    table = f'<table>{"".join(rows)}</table>' if rows else ''
    contract = f'<div class="muted">{" · ".join(status)}</div>' if status else ''
    return f'<div class="fieldpanel">{table}{contract}{kids}</div>'


def documents_panel(core, title: str) -> str:
    rows = forms.documents(core, title)
    if not rows:
        return ''
    return ('<div class="fieldpanel"><b>Documents</b><ul class="docs">' +
            ''.join(f'<li><span class="kind">{escape(k)}</span>&nbsp; {link(t)}</li>' for k, t in rows) +
            '</ul></div>')


def kanban_board(core, post: dict, today: date | None = None) -> str:
    data = forms.board(core, post, today)
    if data['error']:
        return f'<p class="warn">{escape(data["error"])}</p>'
    ov, cells = data['overview'], []
    for lane in data['lanes']:
        count = f'{len(lane["cards"])}' + (f' / {lane["limit"]}' if lane['limit'] is not None else '')
        body = ''.join(f'<div class="cardx">{item_line(ov, t)}</div>' for t in lane['cards']) or \
            '<div class="muted">—</div>'
        warn = ' <span class="warn">over WIP limit</span>' if lane['over'] else ''
        bg = '#fdecea' if lane['over'] else '#f4f5f7'
        cells.append(f'<td class="lane{" over" if lane["over"] else ""}" bgcolor="{bg}" valign="top">'
                     f'<h4>{escape(lane["label"])} ({count}){warn}</h4>{body}</td>')
    note = f'<p class="muted">{data["dropped"]} dropped card(s) hidden.</p>' if data['dropped'] else ''
    return (f'<h2>Board — {link(data["scope"])}</h2><table class="board" width="100%"><tr>' +
            ''.join(cells) + '</tr></table>' + note)


def waterfall_strip(post: dict, today: date | None = None) -> str:
    cells = []
    for p in forms.phases(post, today):
        label = p['phase'].capitalize() + (' ✓' if p['state'] == 'past' else '')
        when = (f'<small>ends {escape(p["end"])}{" · late" if p["state"] == "late" else ""}</small>'
                if p['end'] else '')
        cls = '' if p['state'] == 'future' else p['state']
        cells.append(f'<td class="phase {cls}" bgcolor="{_PHASE_BG.get(cls, "#eceff1")}" align="center">'
                     f'{escape(label)}{when}</td>')
    scope = (post.get('fields') or {}).get('scope')
    head = f'<h2>Phases — {link(scope)}</h2>' if isinstance(scope, str) and scope else '<h2>Phases</h2>'
    return head + '<table class="phases" width="100%"><tr>' + ''.join(cells) + '</tr></table>'


def _json(value, default):
    try:
        return json.loads(value) if isinstance(value, str) and value else default
    except ValueError:
        return default


def pvs_panel(post: dict) -> str:
    """For a PVS-managed post: notices plus the current PVS content when it moved on."""
    f = post.get('fields') or {}
    parts = []
    if f.get('pvs_presence') == 'missing':
        parts.append('<div class="notice bad">No longer in PVS. It stays here, with your text, until you '
                     'delete it (allowed now) or a later refresh finds it again.</div>')
    conflict = _json(f.get('pvs_conflict'), {}).get('status')
    base = _json(f.get('pvs_base'), {}).get('status')
    if conflict:
        parts.append(f'<div class="notice bad"><b>Status conflict</b>: you set {pill(conflict["wiki"])}, '
                     f'PVS now says {pill(conflict["pvs"])}. Resolve it in <b>File → PVS Sync…</b>.</div>')
    elif base is not None and f.get('status') != base:
        import pvs_sync
        kind = projects.kind_of(post)
        parts.append(f'<div class="notice">To enter in PVS: status {pill(f.get("status"))} '
                     f'(PVS: {pill(base)}) — <code>{escape(pvs_sync.suggestion(kind, f.get("status")))}</code></div>')
    meta = ' · '.join(escape(x) for x in (
        f'revision {f.get("pvs_revision")}' if f.get('pvs_revision') else '',
        f'history {f.get("pvs_history")}' if f.get('pvs_history') else '',
        f'branch {f.get("pvs_branch")}' if f.get('pvs_branch') else '') if x)
    view = f.get('pvs_view')
    changed = isinstance(view, str) and f.get('pvs_seed_sha256') != record_sha256({'text': view})
    body = ''
    if changed:
        body = ('<div class="muted">PVS content changed since this post was created from it:</div>' +
                TiddlyRenderer().render(view))
    elif view:
        body = '<div class="muted">Your text started from this PVS content; PVS has not changed it since.</div>'
    parts.append(f'<div class="frompvs"><div class="head">From PVS{" — " + meta if meta else ""}</div>{body}</div>')
    return ''.join(parts)


def pvs_argument_notice(core, post: dict) -> str:
    f = post.get('fields') or {}
    if not f.get('pvs_target'):
        return ''
    import pvs_sync
    row = next((r for r in pvs_sync.reasoning_state(core) if r['title'] == post['title']), None)
    if row is None:
        return ''
    target = link(row['target']) if core.get_tiddler(row['target'] or '') else escape(str(row['target']))
    if row['problem']:
        return f'<div class="notice bad">PVS target {target}: {escape(row["problem"])}</div>'
    if row['entered']:
        return f'<div class="notice ok">Entered in PVS: this argument is on {target} ({escape(row["side"])}).</div>'
    return (f'<div class="notice">To enter in PVS on {target}: <code>{escape(row["operation"])}</code> '
            'with this claim, grounds and warrant.</div>')


def post_panels(core, post: dict) -> str:
    """Everything shown between a post's header and its text."""
    title = post['title']
    fields = post.get('fields') or {}
    tags = post.get('tags') or []
    hide = set(forms.TOULMIN)
    managed = 'pvs' in tags and 'pvs_object' in fields
    if managed:
        hide.update(k for k in fields if k.startswith('pvs_'))
    if title.startswith(forms.TEMPLATE_PREFIX):
        hide.update(k for k in fields if k.startswith('template_'))
    html = (pvs_panel(post) if managed else '') + pvs_argument_notice(core, post) + \
        toulmin_box(fields) + field_panel(core, post, hide=frozenset(hide))
    if projects.kind_of(post) is not None:
        html += documents_panel(core, title)
    if 'kanban' in tags:
        html += kanban_board(core, post)
    if 'waterfall' in tags:
        html += waterfall_strip(post)
    return html


def render_post(core, post: dict) -> str:
    """A post's full HTML document, with panels inserted before its text."""
    document = render_tiddler(post)
    panels = post_panels(core, post)
    if panels:
        document = with_css(document).replace('<div class="content">', panels + '<div class="content">', 1)
    return document


# --- generated pages -------------------------------------------------------
def _attention(ov: dict, key: str, heading: str) -> str:
    rows = ov[key]
    if not rows:
        return ''
    return (f'<h3>{escape(heading)} ({len(rows)})</h3><ul class="attention">' +
            ''.join(f'<li>{item_line(ov, t)}</li>' for t in rows) + '</ul>')


def _tree(ov: dict, title: str, seen: set) -> str:
    kids = [k for k in ov['children'].get(title, []) if k not in seen]
    if not kids:
        return ''
    parts = []
    for k in kids:
        seen.add(k)
        parts.append(f'<li>{item_line(ov, k)}{_tree(ov, k, seen)}</li>')
    return '<ul class="tree">' + ''.join(parts) + '</ul>'


def dashboard(ov: dict) -> str:
    parts = [f'<p class="muted">Today: {escape(ov["today"])} · {len(ov["items"])} items · '
             f'{len(ov["projects"])} projects</p>']
    if not ov['items']:
        parts.append('<p>No project items yet. Use <b>Tiddler → New Project Item…</b> '
                     'to create a project, then add goals, milestones and tasks under it.</p>')
    if ov['contract_error']:
        parts.append(f'<p class="warn">Contract problem: {escape(ov["contract_error"])}</p>')
    attention = (_attention(ov, 'overdue', 'Overdue') + _attention(ov, 'due_soon', 'Due in the next 7 days') +
                 _attention(ov, 'blocked', 'Blocked'))
    if ov['violations']:
        attention += (f'<h3 class="warn">Contract violations ({len(ov["violations"])})</h3><ul>' +
                      ''.join(f'<li>{link(v["title"])} — {escape(v["problem"])}</li>'
                              for v in ov['violations'][:50]) + '</ul>')
    if ov['orphans']:
        attention += ('<h3>Missing parent</h3><ul>' +
                      ''.join(f'<li>{item_line(ov, t)} → <span class="warn">'
                              f'{escape(ov["items"][t]["parent"])}</span> not found</li>'
                              for t in ov['orphans']) + '</ul>')
    if ov['cycles']:
        attention += ('<h3 class="warn">Parent cycles</h3><ul>' +
                      ''.join(f'<li>{link(t)}</li>' for t in ov['cycles']) + '</ul>')
    if attention:
        parts.append('<div class="card"><h2 style="margin-top:0">Needs attention</h2>' + attention + '</div>')
    if ov.get('pvs'):
        parts.append(pvs_sync_card(ov['pvs']))
    for p in ov['projects']:
        pct = '' if p['progress'] is None else (
            f' &nbsp;<span class="bar"><span style="width:{round(p["progress"] * 100)}%"></span></span> '
            f'<span class="muted">{round(p["progress"] * 100)}% done</span>')
        summary = ' · '.join(f'{n} {s}' for s, n in p['counts'].items() if n)
        parts.append(f'<div class="card"><h3>{item_line(ov, p["title"])} {pct}</h3>'
                     f'<div class="muted">{p["total"]} items{": " + escape(summary) if summary else ""}</div>'
                     f'{_tree(ov, p["title"], {p["title"]})}</div>')
    if ov['unfiled']:
        parts.append('<div class="card"><h3>Not under a project</h3><ul class="tree">' +
                     ''.join(f'<li>{item_line(ov, t)}</li>' for t in ov['unfiled']) + '</ul></div>')
    return page('Project Dashboard', ''.join(parts))


def pvs_sync_card(st: dict) -> str:
    if not st.get('configured'):
        return ''
    rows = []
    if st['conflicts']:
        rows.append(f'<h3 class="warn">Conflicts ({len(st["conflicts"])})</h3><ul>' + ''.join(
            f'<li>{link(c["title"])}: wiki {pill(c["wiki"])} / PVS {pill(c["pvs"])}</li>' for c in st['conflicts']) +
            '</ul><p class="muted">Resolve them in File → PVS Sync…</p>')
    if st['to_enter'] or st['reasoning_pending']:
        items = [f'<li>{link(t["title"])}: status {pill(t["wiki"])} (PVS {pill(t["pvs"])}) — '
                 f'<code>{escape(t["operation"])}</code></li>' for t in st['to_enter']]
        items += [f'<li>{link(r["title"])} → {link(r["target"])}: <code>{escape(r["operation"])}</code></li>'
                  for r in st['reasoning_pending']]
        rows.append(f'<h3>To enter in PVS ({len(items)})</h3><ul>' + ''.join(items) + '</ul>')
    if st['reasoning_problems']:
        rows.append('<h3 class="warn">Arguments with a bad PVS target</h3><ul>' + ''.join(
            f'<li>{link(r["title"])}: {escape(r["problem"])}</li>' for r in st['reasoning_problems']) + '</ul>')
    if st['missing']:
        rows.append(f'<h3>No longer in PVS ({len(st["missing"])})</h3><ul>' +
                    ''.join(f'<li>{link(t)}</li>' for t in st['missing']) + '</ul>')
    head = (f'<h2 style="margin-top:0">PVS sync</h2><p class="muted">Last refresh: '
            f'{escape(st.get("last_refresh") or "never")} · {len(st["reasoning_entered"])} argument(s) entered</p>')
    body = ''.join(rows) or '<p>In sync: nothing to enter in PVS, no conflicts.</p>'
    return f'<div class="card">{head}{body}</div>'


def pvs_sync_page(st: dict) -> str:
    if not st.get('configured'):
        return page('PVS Sync', '<p>This notebook does not follow a PVS workspace yet. Use '
                                '<b>File → Refresh from PVS…</b> and choose the workspace folder.</p>')
    return page('PVS Sync', f'<p class="muted">Workspace: <code>{escape(st["root"])}</code></p>' + pvs_sync_card(st))


def contracts(core) -> str:
    try:
        schemas, error = core.field_schemas(), None
    except fs.SchemaError as exc:
        schemas, error = {}, str(exc)
    parts = ['<p>Each contract types the custom fields of posts carrying its tag. '
             'Tightening is accepted; loosening or removing asks you to acknowledge.</p>']
    if error:
        parts.append(f'<p class="warn">{escape(error)}</p>')
    if not schemas and not error:
        parts.append('<p>No contracts yet. <b>View → Install Project Kit</b> adds contracts for '
                     'project, goal, milestone and task.</p>')
    for tag, schema in sorted(schemas.items()):
        rows = ''.join(f'<tr><td>{escape(n)}</td><td>{escape(c)}</td><td>{"yes" if r else ""}</td></tr>'
                       for n, c, r in fs.describe(schema))
        closed = ' · no other fields allowed' if schema.get('additionalProperties') is False else ''
        parts.append(f'<div class="card"><h3>{link(fs.schema_title(tag), tag)}</h3>'
                     f'<table><tr><th>Field</th><th>Allowed</th><th>Required</th></tr>{rows}</table>'
                     f'<div class="muted">{closed}</div></div>')
    return page('Field Contracts', ''.join(parts))
