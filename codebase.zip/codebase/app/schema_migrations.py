"""Explicit, non-destructive PERSONAL.WIKI SQLite schema transition contract.

Portable JSON remains the research authority. Never upgrade a source DB in place.
`plan` is read-only; `migrate` backs up a consistent SQLite snapshot, upgrades
only that private file transactionally, verifies it, and publishes a new DB.
"""
from __future__ import annotations

import hashlib
from contextlib import closing
import json
import os
import re
from pathlib import Path
import sqlite3
import sys
import tempfile
from typing import Callable, Optional

TARGET_VERSION = 2
FROZEN_C5_SHA256 = '125e401913338a83293012aee7384c7d07894930c75321d1b52c7ce874252b77'
FROZEN_C5_PATH = Path(__file__).resolve().parent.parent/'data'/'C5_REFERENCE_DO_NOT_EDIT.db'
SCRIPT = Path(__file__).resolve().parent / 'migrations' / '0000_or_0001_to_0002.sql'
CORE_COLUMNS = {'title', 'text', 'created', 'modified', 'tags_json', 'fields_json'}
V2_COLUMNS = CORE_COLUMNS | {'raw_json'}
V2_OBJECTS = {
    'tiddlers': 'table', 'tiddler_tags': 'table',
    'protected_titles': 'table', 'tiddlers_fts': 'table',
    'idx_tiddler_tags_tag': 'index',
    'tiddlers_ai': 'trigger', 'tiddlers_ad': 'trigger',
    'tiddlers_au': 'trigger',
}


class SchemaCompatibilityError(RuntimeError):
    """The database must not be opened or altered by this app version."""


def _connect_existing(path: Path, *, readonly: bool = True) -> sqlite3.Connection:
    if not path.is_file():
        raise FileNotFoundError(str(path))
    # Mode=ro refuses creation; immutable=1 is ONLY safe for the frozen,
    # byte-verified, non-live project reference. Ordinary WAL databases must
    # use an online read-only connection to see uncheckpointed transactions.
    frozen_reference=(readonly and path.resolve()==FROZEN_C5_PATH.resolve())
    if frozen_reference:
        wal=Path(str(path)+'-wal')
        if wal.exists() and wal.stat().st_size:
            raise SchemaCompatibilityError('Nonempty WAL beside frozen C5 source; refuse immutable snapshot access')
        hash=hashlib.sha256()
        with path.open('rb') as src:
            for chunk in iter(lambda:src.read(1024*1024),b''):hash.update(chunk)
        if hash.hexdigest()!=FROZEN_C5_SHA256:
            raise SchemaCompatibilityError('Frozen C5 reference hash differs; refusing read')
    uri = path.resolve().as_uri() + ('?mode=ro&immutable=1' if frozen_reference else
                                     '?mode=ro' if readonly else '?mode=rw')
    connection = sqlite3.connect(uri, uri=True, timeout=15)
    connection.execute('PRAGMA busy_timeout=15000')
    connection.execute('PRAGMA foreign_keys=ON')
    return connection


def _objects(connection: sqlite3.Connection) -> dict[str, str]:
    return dict(connection.execute("SELECT name,type FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'"))


def _columns(connection: sqlite3.Connection, table: str) -> set[str]:
    return {row[1] for row in connection.execute(f'PRAGMA table_info({table})')}


def _schema_fingerprint(connection: sqlite3.Connection) -> str:
    rows = connection.execute("SELECT type,name,tbl_name,sql FROM sqlite_master "
                              "WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name").fetchall()
    data = json.dumps([list(row) for row in rows], ensure_ascii=False, separators=(',', ':'))
    return hashlib.sha256(data.encode('utf-8')).hexdigest()


def _normalized_ddl(sql: str) -> str:
    """Compare the deployed, known-safe v2 FTS DDL, not a few keywords.

    These definitions contain no whitespace-bearing string literals. Reject
    unknown variants rather than guessing at trigger behavior; an explicit
    reviewed migration is needed to support additional trigger definitions.
    """
    sql = re.sub(r'\bIF\s+NOT\s+EXISTS\b', '', sql, flags=re.I)
    return re.sub(r'\s+', '', sql).rstrip(';').casefold()


def _expected_fts_definitions() -> dict[str, str]:
    expected = {}
    for statement in _statements(SCRIPT.read_text(encoding='utf-8')):
        match = re.match(r'\s*CREATE\s+(?:VIRTUAL\s+TABLE|TRIGGER)\s+(?:IF\s+NOT\s+EXISTS\s+)?'
                         r'(tiddlers_fts|tiddlers_ai|tiddlers_ad|tiddlers_au)\b', statement, re.I)
        if match:
            expected[match.group(1).lower()] = _normalized_ddl(statement)
    if len(expected) != 4:
        raise SchemaCompatibilityError('Migration script lacks required known-safe FTS definitions')
    return expected


def inspect_connection(connection: sqlite3.Connection, *, deep: bool = False) -> dict:
    """Read-only compatibility check; unknown or later schema always fails closed."""
    try:
        version = int(connection.execute('PRAGMA user_version').fetchone()[0])
        objects = _objects(connection)
        if version > TARGET_VERSION:
            raise SchemaCompatibilityError(f'Future schema v{version}: this app supports up to v{TARGET_VERSION}; no downgrade')
        if version not in (0, 1, TARGET_VERSION):
            raise SchemaCompatibilityError(f'Unsupported schema version {version}')
        if objects.get('tiddlers') != 'table':
            raise SchemaCompatibilityError('Missing or invalid tiddlers table (including empty/uninitialized DB)')
        columns = _columns(connection, 'tiddlers')
        if not CORE_COLUMNS.issubset(columns):
            raise SchemaCompatibilityError(f'Unrecognized legacy tiddlers columns: missing {sorted(CORE_COLUMNS - columns)}')
        missing = {name for name, kind in V2_OBJECTS.items() if objects.get(name) != kind}
        v2_layout = not missing and V2_COLUMNS.issubset(columns)
        if version == TARGET_VERSION:
            if not v2_layout:
                raise SchemaCompatibilityError(f'v2 schema mismatch; missing objects {sorted(missing)}; columns {sorted(V2_COLUMNS - columns)}')
            ddl = dict(connection.execute("SELECT name,sql FROM sqlite_master WHERE name IN "
                       "('tiddlers_fts','tiddlers_ai','tiddlers_ad','tiddlers_au')"))
            expected = _expected_fts_definitions()
            for name, safe_definition in expected.items():
                if _normalized_ddl(ddl.get(name) or '') != safe_definition:
                    raise SchemaCompatibilityError(
                        f'v2 schema mismatch: incompatible trigger {name}; unknown FTS definition'
                        if name != 'tiddlers_fts' else
                        'v2 schema mismatch: incompatible FTS definition tiddlers_fts')
        for name in ('tiddler_tags', 'protected_titles'):
            if name in objects and objects[name] != 'table':
                raise SchemaCompatibilityError(f'Unexpected object type for {name}')
        if 'tiddlers_fts' in objects and objects['tiddlers_fts'] != 'table':
            raise SchemaCompatibilityError('Unexpected FTS object type')
        status = connection.execute('PRAGMA quick_check').fetchone()[0]
        if status != 'ok':
            raise SchemaCompatibilityError(f'SQLite quick_check failed: {status}')
        fk = connection.execute('PRAGMA foreign_key_check').fetchall()
        if fk:
            raise SchemaCompatibilityError(f'{len(fk)} foreign-key violations')
        count = connection.execute('SELECT count(*) FROM tiddlers').fetchone()[0]
        result = {
            'schema_version': version, 'target_version': TARGET_VERSION,
            'records': count, 'columns': sorted(columns),
            'protected_records': (connection.execute('SELECT COUNT(*) FROM protected_titles').fetchone()[0]
                                  if objects.get('protected_titles') == 'table' else 0),
            'migration_required': version < TARGET_VERSION,
            'readable_v2_layout': v2_layout,
            'planned_steps': (['online SQLite snapshot (source unchanged)',
                               f'v{version} -> v2: add missing raw_json, index/tables/triggers, rebuild FTS',
                               'transactional user_version=2 and validation',
                               'atomic no-clobber destination publish']
                              if version < TARGET_VERSION else []),
            'schema_sql_sha256': hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),
            'schema_fingerprint_sha256': _schema_fingerprint(connection),
        }
        if deep:
            full = connection.execute('PRAGMA integrity_check').fetchone()[0]
            if full != 'ok':
                raise SchemaCompatibilityError(f'SQLite integrity_check failed: {full}')
            result['integrity'] = full
        return result
    except sqlite3.DatabaseError as exc:
        raise SchemaCompatibilityError(f'Invalid or corrupt SQLite database: {exc}') from exc


def plan(source: str | Path) -> dict:
    path = Path(source)
    with closing(_connect_existing(path)) as db:
        details = inspect_connection(db, deep=True)
    return {'source': str(path.resolve()), **details,
            'warning': ('Read-only inspection; an online backup during migrate defines the '
                        'consistent input snapshot. No raw-file hash claimed for live WAL sources.')}


def _statements(sql: str):
    current = ''
    for line in sql.splitlines(keepends=True):
        current += line
        if sqlite3.complete_statement(current):
            if current.strip():
                yield current
            current = ''
    if current.strip():
        raise SchemaCompatibilityError('Incomplete migration SQL script')


def _record_fingerprint(connection: sqlite3.Connection, column_names: list[str]) -> str:
    """Stable ordered hash of core stored row values, avoiding derived FTS content."""
    digest = hashlib.sha256()
    query = 'SELECT ' + ', '.join(column_names) + ' FROM tiddlers ORDER BY title'
    for row in connection.execute(query):
        blob = json.dumps(list(row), ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        digest.update(len(blob).to_bytes(8, 'big'))
        digest.update(blob)
    return digest.hexdigest()


def _table_fingerprint(connection: sqlite3.Connection, table: str) -> str:
    if _objects(connection).get(table) != 'table':
        return 'absent'
    digest = hashlib.sha256()
    sql = {'tiddler_tags': 'SELECT title,tag FROM tiddler_tags ORDER BY title,tag',
           'protected_titles': 'SELECT title,record_sha256 FROM protected_titles ORDER BY title'}[table]
    for row in connection.execute(sql):
        value = json.dumps(list(row), ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        digest.update(len(value).to_bytes(8, 'big'))
        digest.update(value)
    return digest.hexdigest()


def _apply_to_staging(connection: sqlite3.Connection, current: int,
                      fault_hook: Optional[Callable[[str], None]] = None) -> None:
    """Upgrade in one explicit transaction; supports controlled fault injection."""
    if current not in (0, 1):
        raise SchemaCompatibilityError(f'No v{current}->v2 migration script')
    connection.execute('PRAGMA foreign_keys=ON')
    connection.execute('BEGIN IMMEDIATE')
    try:
        existing_tables = _objects(connection)
        if 'raw_json' not in _columns(connection, 'tiddlers'):
            connection.execute('ALTER TABLE tiddlers ADD COLUMN raw_json TEXT')
        if fault_hook:
            fault_hook('after_add_column')
        for statement in _statements(SCRIPT.read_text(encoding='utf-8')):
            connection.execute(statement)
        # Old personal wiki DBs can have tags_json but no tiddler_tags table.
        # Materialize the derived tag index only in that documented case.
        if 'tiddler_tags' not in existing_tables:
            for title, tags_json in connection.execute('SELECT title,tags_json FROM tiddlers'):
                tags = json.loads(tags_json)
                if not isinstance(tags, list) or any(not isinstance(t, str) for t in tags):
                    raise SchemaCompatibilityError('Invalid tags_json in legacy record '+title)
                connection.executemany('INSERT INTO tiddler_tags(title,tag) VALUES(?,?)',
                                       ((title,tag) for tag in dict.fromkeys(tags)))
        # Rebuild all legacy/stale/empty external FTS indexes, including C5 v0.
        connection.execute("INSERT INTO tiddlers_fts(tiddlers_fts) VALUES('rebuild')")
        if fault_hook:
            fault_hook('after_fts_rebuild')
        connection.execute('PRAGMA user_version=2')
        # FTS external-content consistency, not merely row count.
        connection.execute("INSERT INTO tiddlers_fts(tiddlers_fts,rank) VALUES('integrity-check',1)")
        if fault_hook:
            fault_hook('before_commit')
        connection.commit()
    except BaseException:
        connection.rollback()
        raise


def _fsync_dir(parent: Path) -> None:
    if hasattr(os, 'O_DIRECTORY'):
        dfd = os.open(str(parent), os.O_RDONLY | os.O_DIRECTORY)
        try: os.fsync(dfd)
        finally: os.close(dfd)


def migrate(source: str | Path, destination: str | Path,
            *, fault_hook: Optional[Callable[[str], None]] = None) -> dict:
    """Create a fully verified v2 DB at a *new* path; no source changes.

    Refuses existing destinations. Does not copy raw WAL or update in place.
    The no-clobber hard link is atomic on local filesystems, subject to OS support.
    """
    src, dest = Path(source), Path(destination)
    if src.resolve() == dest.resolve():
        raise ValueError('Migration destination must differ from source')
    if dest.exists() or dest.is_symlink():
        raise FileExistsError(f'Refusing to overwrite destination: {dest}')
    with closing(_connect_existing(src)) as original:
        details = inspect_connection(original, deep=True)
        if not details['migration_required']:
            raise SchemaCompatibilityError('Schema already v2; no migration needed')
        dest.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix='.' + dest.name + '.', suffix='.migration.tmp', dir=dest.parent)
        os.close(fd)
        staged = Path(temp_name)
        try:
            with closing(sqlite3.connect(staged)) as staging:
                original.backup(staging, pages=256, sleep=0.01)
            with closing(_connect_existing(staged)) as snapshot:
                copied = inspect_connection(snapshot, deep=True)
                if copied['schema_version'] != details['schema_version']:
                    raise SchemaCompatibilityError('Input schema changed during snapshot; retry')
                core_cols = sorted(CORE_COLUMNS | ({'raw_json'} if 'raw_json' in copied['columns'] else set()))
                before_rows = _record_fingerprint(snapshot, core_cols)
                before_tags = _table_fingerprint(snapshot, 'tiddler_tags')
                before_protection = _table_fingerprint(snapshot, 'protected_titles')
            # Keep output self-contained. The staged file has no active reader/writer.
            with closing(sqlite3.connect(staged, timeout=15)) as out:
                out.execute('PRAGMA journal_mode=DELETE')
                _apply_to_staging(out, copied['schema_version'], fault_hook)
                result = inspect_connection(out, deep=True)
                if result['migration_required'] or result['records'] != copied['records']:
                    raise SchemaCompatibilityError('Post-migration schema/count mismatch')
                if _record_fingerprint(out, core_cols) != before_rows:
                    raise SchemaCompatibilityError('Stored source record values changed during migration')
                if before_tags != 'absent' and _table_fingerprint(out, 'tiddler_tags') != before_tags:
                    raise SchemaCompatibilityError('Existing tag index changed during migration')
                if before_protection != 'absent' and _table_fingerprint(out, 'protected_titles') != before_protection:
                    raise SchemaCompatibilityError('Protected record digests changed during migration')
                # Every persisted tag projection must agree with the normalized
                # tags_json, including when old schema lacked the tag index.
                for title, tags_json in out.execute('SELECT title,tags_json FROM tiddlers'):
                    tags = json.loads(tags_json)
                    if not isinstance(tags, list) or any(not isinstance(t, str) for t in tags):
                        raise SchemaCompatibilityError('Invalid tags_json for '+title)
                    actual = {r[0] for r in out.execute('SELECT tag FROM tiddler_tags WHERE title=?', (title,))}
                    if actual != set(tags):
                        raise SchemaCompatibilityError('Tag index inconsistent for '+title)
                # Verify generated FTS entries against underlying content.
                out.execute("INSERT INTO tiddlers_fts(tiddlers_fts,rank) VALUES('integrity-check',1)")
                if out.execute('PRAGMA foreign_key_check').fetchall():
                    raise SchemaCompatibilityError('Foreign key integrity check failed')
            # Independently check protected raw objects, row projections and
            # tag index using the existing v0.6 protection verifier.
            from db import TiddlerDB
            with TiddlerDB(str(staged), readonly=True) as check:
                protections = check.protection_report()
                if protections['violation_count']:
                    raise SchemaCompatibilityError('Protection violations: ' + str(protections['violations']))
            for sidecar in ('-wal', '-shm', '-journal'):
                if Path(str(staged) + sidecar).exists():
                    raise SchemaCompatibilityError('Staging sidecar remains; refusing to publish')
            with staged.open('rb') as f:
                os.fsync(f.fileno())
            with staged.open('rb') as f:
                digest = hashlib.file_digest(f, 'sha256').hexdigest()
            # Hard-link creation is atomic and refuses concurrent overwrite.
            os.link(staged, dest)
            _fsync_dir(dest.parent)
            return {'source': str(src.resolve()), 'destination': str(dest.resolve()),
                    'source_version': details['schema_version'], 'destination_version': TARGET_VERSION,
                    'records': result['records'], 'protected_records': result['protected_records'],
                    'snapshot_core_sha256': before_rows, 'migration_sql_sha256': result['schema_sql_sha256'],
                    'tag_index_materialized': before_tags == 'absent',
                    'source_schema_fingerprint_sha256': copied['schema_fingerprint_sha256'],
                    'destination_schema_fingerprint_sha256': result['schema_fingerprint_sha256'],
                    'destination_sha256': digest, 'validation': 'PASS',
                    'source_untouched': 'read-only online backup; original never opened writable'}
        finally:
            if staged.exists(): staged.unlink()
            for sidecar in ('-wal','-shm','-journal'):
                Path(str(staged) + sidecar).unlink(missing_ok=True)


def main(argv=None) -> int:
    if sys.version_info < (3, 11):
        raise RuntimeError('Python 3.11+ required for safe migration, cutover and GUI startup')
    import argparse
    parser = argparse.ArgumentParser(description='PERSONAL.WIKI explicit schema migration (source preserved)')
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('plan', help='read-only preflight').add_argument('source')
    go = commands.add_parser('migrate', help='snapshot/upgrade/verify to NEW file only')
    go.add_argument('source'); go.add_argument('destination')
    args = parser.parse_args(argv)
    try:
        result = plan(args.source) if args.command == 'plan' else migrate(args.source, args.destination)
        print(json.dumps({'status': 'PASS', **result}, indent=2))
        return 0
    except (OSError, sqlite3.DatabaseError, ValueError, SchemaCompatibilityError) as exc:
        print(json.dumps({'status': 'REFUSED', 'reason': str(exc)}, indent=2))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
