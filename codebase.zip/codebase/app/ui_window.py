"""Main window: browse panel, preview, menus, and every user action.

All notebook access goes through WikiCore; this module never touches SQLite.
"""
import json
import os
from pathlib import Path
from urllib.parse import unquote

from PySide6.QtCore import Qt, QUrl, Slot, QTimer, QThread, QObject, Signal
from PySide6.QtGui import QAction, QKeySequence, QDesktopServices
from PySide6.QtWidgets import (
    QComboBox, QDialog, QDialogButtonBox, QFileDialog, QHBoxLayout, QInputDialog, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMessageBox, QPlainTextEdit,
    QSplitter, QStackedWidget, QStatusBar, QTextBrowser, QToolBar, QToolButton, QVBoxLayout,
    QWidget,
)

from wiki_core import WikiCore, ContractAcknowledgementRequired, SchemaError
from ui_preview import WEBENGINE_AVAILABLE, QWebEngineView, QWebEngineSettings, TiddlerPage
from ui_dialogs import TiddlerEditor, ProjectItemDialog, TemplateDialog

BROWSE_VIEWS = (("Posts", "posts"), ("Projects", "projects"), ("Forms", "forms"),
                ("Tags", "tags"), ("System ($:/)", "system"), ("All", "all"))


class ImportWorker(QObject):
    finished = Signal(int)
    failed = Signal(str)
    needs_ack = Signal(str)

    def __init__(self, db_path: str, json_path: str, overwrite: bool, protect: bool, reason: str | None,
                 acknowledge: bool = False):
        super().__init__()
        self.db_path, self.json_path, self.overwrite, self.protect = db_path, json_path, overwrite, protect
        self.reason = reason
        self.acknowledge = acknowledge

    @Slot()
    def run(self):
        try:
            # Open connection within worker thread; never share Qt/SQLite connections.
            with WikiCore(self.db_path) as db:
                count = db.import_json(
                    self.json_path,
                    on_conflict='overwrite' if self.overwrite else 'reject',
                    protect_imported=self.protect,
                    reason=self.reason,
                    acknowledge_contract_change=self.acknowledge,
                )
            self.finished.emit(count)
        except ContractAcknowledgementRequired as exc:
            self.needs_ack.emit(str(exc))
        except Exception as exc:
            self.failed.emit(str(exc))


class _Declined(Exception):
    """The owner declined a contract change; keep the draft."""


class TiddlyViewer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.db: WikiCore | None = None
        self.current_tiddler: str | None = None  # Currently displayed tiddler
        self.history: list[str] = []  # Navigation history
        self.history_pos: int = -1  # Current position in history
        self._navigating_history = False  # Flag to prevent history duplication
        self._offset = 0
        self._page_size = 200
        self._import_thread = None
        self._import_worker = None
        self._force_compat_preview = not WEBENGINE_AVAILABLE
        self._preview_load_pending = False
        self._preview_generation = 0
        self._showing = None  # 'dashboard' / 'contracts' when a generated page is shown
        self.setWindowTitle("PERSONAL.WIKI")
        self.setGeometry(100, 100, 1200, 800)

        self._setup_menu()
        self._setup_toolbar()
        self._setup_ui()
        self._setup_statusbar()

    def _setup_menu(self):
        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu("&File")

        open_action = QAction("&Open Database...", self)
        open_action.setShortcut(QKeySequence.Open)
        open_action.triggered.connect(self._open_database)
        file_menu.addAction(open_action)

        import_action = QAction("&Import JSON...", self)
        import_action.setShortcut(QKeySequence("Ctrl+I"))
        import_action.triggered.connect(self._import_json)
        file_menu.addAction(import_action)

        backup_action = QAction("&Snapshot Database...", self)
        backup_action.triggered.connect(self._backup_database)
        file_menu.addAction(backup_action)

        bundle_out = QAction("Export Notebook &Bundle...", self)
        bundle_out.triggered.connect(self._export_bundle)
        file_menu.addAction(bundle_out)
        bundle_in = QAction("&Restore Notebook Bundle...", self)
        bundle_in.triggered.connect(self._restore_bundle)
        file_menu.addAction(bundle_in)

        verify_action = QAction("&Verify Post History", self)
        verify_action.triggered.connect(self._verify_post_history)
        file_menu.addAction(verify_action)

        export_action = QAction("&Export JSON...", self)
        export_action.setShortcut(QKeySequence("Ctrl+Shift+E"))
        export_action.triggered.connect(self._export_json)
        file_menu.addAction(export_action)

        file_menu.addSeparator()
        refresh_pvs = QAction("&Refresh from PVS...", self)
        refresh_pvs.setShortcut(QKeySequence("Ctrl+Shift+R"))
        refresh_pvs.triggered.connect(self._refresh_from_pvs)
        file_menu.addAction(refresh_pvs)
        refresh_file = QAction("Refresh from PVS Snapshot &File...", self)
        refresh_file.triggered.connect(self._refresh_from_pvs_file)
        file_menu.addAction(refresh_file)
        sync_action = QAction("PVS S&ync...", self)
        sync_action.triggered.connect(self._show_pvs_sync)
        file_menu.addAction(sync_action)
        pvs_action = QAction("Export PVS &Archive Notebook...", self)
        pvs_action.triggered.connect(self._new_pvs_notebook)
        file_menu.addAction(pvs_action)
        log_action = QAction("Update &Change Log", self)
        log_action.triggered.connect(self._update_change_log)
        file_menu.addAction(log_action)
        file_menu.addSeparator()

        new_action = QAction("New &Database...", self)
        new_action.setShortcut(QKeySequence("Ctrl+Shift+N"))
        new_action.triggered.connect(self._new_database)
        file_menu.addAction(new_action)

        file_menu.addSeparator()

        quit_action = QAction("&Quit", self)
        quit_action.setShortcut(QKeySequence.Quit)
        quit_action.triggered.connect(self.close)
        file_menu.addAction(quit_action)

        # View menu
        view_menu = menubar.addMenu("&View")

        all_tiddlers = QAction("Show &All Posts", self)
        all_tiddlers.setShortcut(QKeySequence("Ctrl+Shift+A"))
        all_tiddlers.triggered.connect(self._show_all_tiddlers)
        view_menu.addAction(all_tiddlers)

        all_tags = QAction("Show All &Tags", self)
        all_tags.setShortcut(QKeySequence("Ctrl+Shift+T"))
        all_tags.triggered.connect(self._show_all_tags)
        view_menu.addAction(all_tags)

        view_menu.addSeparator()
        dashboard = QAction("&Project Dashboard", self)
        dashboard.setShortcut(QKeySequence("Ctrl+D"))
        dashboard.triggered.connect(self._show_dashboard)
        view_menu.addAction(dashboard)
        contracts = QAction("Field &Contracts", self)
        contracts.triggered.connect(self._show_contracts)
        view_menu.addAction(contracts)
        kit = QAction("&Install Project Kit", self)
        kit.triggered.connect(self._install_project_kit)
        view_menu.addAction(kit)
        forms_kit = QAction("Install &Forms Kit", self)
        forms_kit.triggered.connect(self._install_forms_kit)
        view_menu.addAction(forms_kit)
        view_menu.addSeparator()

        self.compat_preview_action = QAction("Use &Compatibility Preview (Qt Text)", self)
        self.compat_preview_action.setCheckable(True)
        self.compat_preview_action.setChecked(self._force_compat_preview)
        self.compat_preview_action.setEnabled(WEBENGINE_AVAILABLE)
        self.compat_preview_action.toggled.connect(self._toggle_compat_preview)
        view_menu.addAction(self.compat_preview_action)

        # Navigate menu
        nav_menu = menubar.addMenu("&Navigate")

        self.back_action = QAction("&Back", self)
        self.back_action.setShortcut(QKeySequence("Alt+Left"))
        self.back_action.triggered.connect(self._go_back)
        self.back_action.setEnabled(False)
        nav_menu.addAction(self.back_action)

        self.forward_action = QAction("&Forward", self)
        self.forward_action.setShortcut(QKeySequence("Alt+Right"))
        self.forward_action.triggered.connect(self._go_forward)
        self.forward_action.setEnabled(False)
        nav_menu.addAction(self.forward_action)

        # Tiddler menu
        tiddler_menu = menubar.addMenu("&Tiddler")

        new_tiddler = QAction("&New Tiddler", self)
        new_tiddler.setShortcut(QKeySequence("Ctrl+N"))
        new_tiddler.triggered.connect(self._new_tiddler)
        tiddler_menu.addAction(new_tiddler)

        from_template = QAction("New from &Template...", self)
        from_template.setShortcut(QKeySequence("Ctrl+T"))
        from_template.triggered.connect(self._new_from_template)
        tiddler_menu.addAction(from_template)

        new_item = QAction("New Project &Item...", self)
        new_item.setShortcut(QKeySequence("Ctrl+Shift+P"))
        new_item.triggered.connect(self._new_project_item)
        tiddler_menu.addAction(new_item)

        edit_tiddler = QAction("&Edit Tiddler", self)
        edit_tiddler.setShortcut(QKeySequence("Ctrl+E"))
        edit_tiddler.triggered.connect(self._edit_current_tiddler)
        tiddler_menu.addAction(edit_tiddler)

        tiddler_menu.addSeparator()

        delete_tiddler = QAction("&Delete Tiddler", self)
        delete_tiddler.setShortcut(QKeySequence("Ctrl+Shift+D"))
        delete_tiddler.triggered.connect(self._delete_current_tiddler)
        tiddler_menu.addAction(delete_tiddler)

        history_action = QAction("View &Post History...", self)
        history_action.triggered.connect(self._show_post_history)
        tiddler_menu.addAction(history_action)

    def _setup_toolbar(self):
        toolbar = QToolBar("Navigation")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)

        # Back button
        self.back_btn = QToolButton()
        self.back_btn.setText("◀")
        self.back_btn.setToolTip("Back (Alt+Left)")
        self.back_btn.clicked.connect(self._go_back)
        self.back_btn.setEnabled(False)
        toolbar.addWidget(self.back_btn)

        # Forward button
        self.forward_btn = QToolButton()
        self.forward_btn.setText("▶")
        self.forward_btn.setToolTip("Forward (Alt+Right)")
        self.forward_btn.clicked.connect(self._go_forward)
        self.forward_btn.setEnabled(False)
        toolbar.addWidget(self.forward_btn)

        toolbar.addSeparator()

        # New tiddler button
        new_btn = QToolButton()
        new_btn.setText("+ New")
        new_btn.setToolTip("New Tiddler (Ctrl+N)")
        new_btn.clicked.connect(self._new_tiddler)
        toolbar.addWidget(new_btn)

        # Edit button
        edit_btn = QToolButton()
        edit_btn.setText("✎ Edit")
        edit_btn.setToolTip("Edit Current Tiddler (Ctrl+E)")
        edit_btn.clicked.connect(self._edit_current_tiddler)
        toolbar.addWidget(edit_btn)

        toolbar.addSeparator()
        item_btn = QToolButton()
        item_btn.setText("+ Item")
        item_btn.setToolTip("New project item (Ctrl+Shift+P)")
        item_btn.clicked.connect(self._new_project_item)
        toolbar.addWidget(item_btn)
        dash_btn = QToolButton()
        dash_btn.setText("▦ Projects")
        dash_btn.setToolTip("Project dashboard (Ctrl+D)")
        dash_btn.clicked.connect(self._show_dashboard)
        toolbar.addWidget(dash_btn)

    def _setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(10, 10, 10, 10)

        # Search bar
        search_layout = QHBoxLayout()

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search tiddlers...")
        self.search_timer = QTimer(self)
        self.search_timer.setSingleShot(True)
        self.search_timer.setInterval(220)
        self.search_timer.timeout.connect(self._reset_search)
        self.search_input.textChanged.connect(lambda: self.search_timer.start())
        self.search_input.returnPressed.connect(self._reset_search)
        search_layout.addWidget(self.search_input, stretch=1)

        self.search_mode = QComboBox()
        self.search_mode.addItems(["Title", "Text", "Tag"])
        self.search_mode.setFixedWidth(100)
        self.search_mode.currentIndexChanged.connect(self._reset_search)
        search_layout.addWidget(self.search_mode)

        layout.addLayout(search_layout)

        # Splitter: results list | preview
        splitter = QSplitter(Qt.Horizontal)

        # Results list
        self.results_list = QListWidget()
        self.results_list.setMinimumWidth(250)
        self.results_list.itemClicked.connect(self._on_result_clicked)
        self.results_list.itemActivated.connect(self._on_result_clicked)
        self.results_list.itemDoubleClicked.connect(self._on_result_double_clicked)

        # Pager must exist before loading any database. The previous pilot
        # updated these attributes in _populate_results but never created them.
        results_panel = QWidget()
        results_layout = QVBoxLayout(results_panel)
        results_layout.setContentsMargins(0, 0, 0, 0)
        view_row = QHBoxLayout()
        view_row.addWidget(QLabel("Show:"))
        self.view_picker = QComboBox()
        for label, key in BROWSE_VIEWS:
            self.view_picker.addItem(label, key)
        self.view_picker.setToolTip("Posts hides $:/ system posts (contracts, templates); "
                                    "System shows only those.")
        self.view_picker.currentIndexChanged.connect(self._on_view_changed)
        view_row.addWidget(self.view_picker, stretch=1)
        results_layout.addLayout(view_row)
        results_layout.addWidget(self.results_list)
        pager = QHBoxLayout()
        self.prev_page = QToolButton()
        self.prev_page.setText("◀ Previous")
        self.prev_page.setToolTip("Previous 200 results")
        self.prev_page.setEnabled(False)
        self.prev_page.clicked.connect(self._previous_page)
        pager.addWidget(self.prev_page)
        self.page_label = QLabel("No results")
        pager.addWidget(self.page_label, stretch=1)
        self.next_page = QToolButton()
        self.next_page.setText("Next ▶")
        self.next_page.setToolTip("Next 200 results")
        self.next_page.setEnabled(False)
        self.next_page.clicked.connect(self._next_page)
        pager.addWidget(self.next_page)
        results_layout.addLayout(pager)
        splitter.addWidget(results_panel)

        # Two independent rendering paths: WebEngine plus a built-in Qt fallback.
        # The fallback is kept ready for failed loads (or can be chosen in View).
        self.preview_stack = QStackedWidget()
        self.preview = None
        self.tiddler_page = None
        if WEBENGINE_AVAILABLE:
            self.preview = QWebEngineView()
            self.preview.settings().setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, False)
            self.preview.settings().setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, False)
            self.preview.settings().setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, False)
            self.preview.setMinimumWidth(500)
            self.tiddler_page = TiddlerPage(self.preview)
            self.tiddler_page.link_clicked_callback = self._show_tiddler
            self.tiddler_page.linkHovered.connect(self._on_link_hovered)
            self.preview.setPage(self.tiddler_page)
            self.preview.loadFinished.connect(self._preview_loaded)
            self.preview_stack.addWidget(self.preview)

        self.compat_preview = QTextBrowser()
        self.compat_preview.setOpenLinks(False)
        self.compat_preview.setOpenExternalLinks(False)
        self.compat_preview.anchorClicked.connect(self._on_compat_link_clicked)
        self.preview_stack.addWidget(self.compat_preview)
        if not WEBENGINE_AVAILABLE:
            self.compat_preview.setMinimumWidth(500)
        splitter.addWidget(self.preview_stack)
        self._show_welcome()

        # Set initial sizes (30% list, 70% preview)
        splitter.setSizes([300, 700])
        layout.addWidget(splitter)

    def _setup_statusbar(self):
        self.statusbar = QStatusBar()
        self.setStatusBar(self.statusbar)
        self._update_status()

    def _update_status(self):
        if self.db:
            count = self.db.count()
            self.statusbar.showMessage(f"Loaded: {count} tiddlers")
        else:
            self.statusbar.showMessage("No database loaded. Use File → Import JSON or Open Database.")

    # --- Menu actions ---

    @Slot()
    def _open_database(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Database", "", "SQLite Database (*.db);;All Files (*)"
        )
        if path:
            self._load_database(path)

    @Slot()
    def _new_database(self):
        if self._import_thread is not None:
            QMessageBox.information(self, 'Import active',
                'Finish the import before creating or switching databases. No file was created.')
            return
        # Suggest the current working folder, but never replace an existing DB.
        suggested = str(Path(self.db.db_path).parent / 'new_wiki.db') if self.db else 'tiddlers.db'
        path, _ = QFileDialog.getSaveFileName(
            self, "New Database", suggested, "SQLite Database (*.db)"
        )
        if path:
            # The save dialog runs a nested event loop; recheck before any I/O.
            if self._import_thread is not None:
                QMessageBox.information(self, 'Import active',
                    'Finish the import before creating another database. No file was created.')
                return
            try:
                WikiCore.create_database(path)
            except Exception as exc:
                QMessageBox.critical(self, "New Database Error", str(exc))
                return
            self._load_database(path)

    @Slot()
    def _import_json(self):
        if not self.db:
            QMessageBox.warning(self, 'No Database', 'Create or open a database first.')
            return
        if self._import_thread is not None:
            QMessageBox.information(self, 'Import busy', 'An import is running.')
            return
        path, _ = QFileDialog.getOpenFileName(self, 'Import TiddlyWiki JSON', '', 'JSON Files (*.json)')
        if not path:return
        reply = QMessageBox.question(self, 'Import conflict handling',
            'Different existing titles will cause the ENTIRE import to roll back.\n'
            'Choose Yes only if you explicitly want to replace conflicting records.\n'
            'No rejects the import if any differing title exists; Cancel aborts.',
            QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel, QMessageBox.No)
        if reply == QMessageBox.Cancel:return
        reason = None
        if reply == QMessageBox.Yes:
            reason = self._request_reason('Reason for imported changes')
            if reason is None:return
        protection = QMessageBox.question(self,'Protect evidence',
            'Make imported records read-only inside this application?\n'
            'YES is recommended for Research Provenance Wiki.\n'
            'NO allows editing imported records in personal-wiki mode.',
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        self._start_import(path, reply == QMessageBox.Yes, protection == QMessageBox.Yes, reason, False)

    def _start_import(self, path: str, overwrite: bool, protect: bool, reason: str | None, acknowledge: bool):
        self._import_request = (path, overwrite, protect, reason)
        self._import_thread = QThread(self)
        self._import_worker = ImportWorker(self.db.db_path, path, overwrite, protect, reason, acknowledge)
        self._import_worker.moveToThread(self._import_thread)
        self._import_worker.needs_ack.connect(self._import_needs_ack)
        self._import_worker.needs_ack.connect(self._import_thread.quit)
        self._import_thread.started.connect(self._import_worker.run)
        self._import_worker.finished.connect(self._import_done)
        self._import_worker.failed.connect(self._import_failed)
        self._import_worker.finished.connect(self._import_thread.quit)
        self._import_worker.failed.connect(self._import_thread.quit)
        self._import_thread.finished.connect(self._import_worker.deleteLater)
        self._import_thread.finished.connect(self._import_thread.deleteLater)
        self._import_thread.finished.connect(self._clear_import_worker)
        self.statusbar.showMessage('Importing in background. Existing data remains readable.')
        self._import_thread.start()

    @Slot()
    def _clear_import_worker(self):
        self._import_thread = None
        self._import_worker = None

    @Slot(int)
    def _import_done(self, count):
        self._update_status();self._reset_search()
        QMessageBox.information(self, 'Import committed', f'{count} new/changed records committed atomically.')

    @Slot(str)
    def _import_needs_ack(self, message):
        answer = QMessageBox.question(self, 'Contract change in import',
            message + '\n\nNothing has been imported yet. Import anyway and record that you '
            'acknowledged this contract change?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer != QMessageBox.Yes:
            self.statusbar.showMessage('Import cancelled; nothing changed.', 8000)
            return
        request = self._import_request
        # The previous worker thread is finishing; start the retry once it is cleared.
        def retry():
            if self._import_thread is not None:
                QTimer.singleShot(50, retry)
                return
            self._start_import(*request, True)
        QTimer.singleShot(0, retry)

    @Slot(str)
    def _import_failed(self, message):
        QMessageBox.critical(self, 'Import rolled back', message)

    @Slot()
    def _verify_post_history(self):
        if not self.db:return
        if self._import_thread is not None:
            QMessageBox.information(self, 'Import active','Finish the import before verification.')
            return
        try:
            result=self.db.verify_history()
            log=self.db.verify_change_log()
            chain=(f"Change log: {log['entries']} entries, chain intact." if log['verified'] else
                   'Change log chain BROKEN:\n' + '\n'.join(log['problems'][:8]))
            (QMessageBox.information if log['verified'] else QMessageBox.warning)(
                self,'Post history verified',
                f"{result['active_posts']} current posts and {result['events']} "
                'historical events checked against their hashes.\n\n' + chain)
        except Exception as exc:
            QMessageBox.critical(self,'History verification failed',str(exc))

    @Slot()
    def _backup_database(self):
        if not self.db:return
        if self._import_thread is not None:
            QMessageBox.information(self, 'Import active', 'Finish importing before backing up.')
            return
        path, _ = QFileDialog.getSaveFileName(self, 'Snapshot SQLite database', 'wiki_backup.db', 'SQLite (*.db)')
        if not path:return
        try:
            result=self.db.snapshot_pair(path)
            QMessageBox.information(self, 'Backup pair verified',
                f"Content: {result['content']}\nHistory: {result['history']}\n"
                "Keep BOTH SQLite files together when copying or restoring.")
        except Exception as exc:QMessageBox.critical(self, 'Snapshot failed', str(exc))

    @Slot()
    def _export_json(self):
        if not self.db:
            QMessageBox.warning(self, "No Database", "No database loaded.")
            return

        path, _ = QFileDialog.getSaveFileName(
            self, "Export TiddlyWiki JSON", "tiddlers.json", "JSON Files (*.json)"
        )
        if path:
            try:
                count = self.db.export_json(path)
                QMessageBox.information(
                    self, "Export Complete", f"Exported {count} tiddlers to:\n{path}"
                )
            except Exception as e:
                QMessageBox.critical(self, "Export Error", str(e))

    def _load_database(self, path: str):
        if self._import_thread is not None:
            QMessageBox.warning(self,'Import active','Finish the import before changing databases.')
            return
        # Explicit consent is required when assigning a first history baseline
        # to an existing database. Earlier untracked versions cannot be recovered.
        if Path(path).is_file() and not WikiCore.has_history(path):
            answer = QMessageBox.question(self, 'Initialize post history?',
                'This database has no companion post-history file. Create an initial '
                'snapshot of its CURRENT posts? Earlier edits cannot be reconstructed. '
                'The original database content will not be replaced.',
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if answer != QMessageBox.Yes:return
            try: WikiCore.initialize_history(path)
            except Exception as exc:
                QMessageBox.critical(self, 'History initialization failed',str(exc))
                return
        # Prepare the candidate completely before modifying the active session.
        candidate = None
        try:
            if not Path(path).is_file():
                raise FileNotFoundError('No database exists at '+path)
            candidate = WikiCore(path)
            report = candidate.integrity_report()
            if report['integrity'] != 'ok' or report['foreign_key_violations'] or not report['fts_matches']:
                raise ValueError('Database integrity or search index check failed: '+str(report))
            evidence = candidate.protection_report()
            if evidence['violation_count']:
                raise ValueError('Protected evidence audit failed: '+str(evidence['violations']))
        except Exception as exc:
            if candidate is not None: candidate.close()
            QMessageBox.critical(self, "Database Error", str(exc))
            return
        old = self.db
        self.db = candidate
        self.history = []
        self.history_pos = -1
        self._navigating_history = False
        self.current_tiddler = None
        self._offset = 0
        self.search_input.clear()
        self._update_nav_buttons()
        self._update_status()
        self._show_all_tiddlers()
        self._show_welcome()
        if old is not None: old.close()
        self._catch_up_change_log()

    @Slot()
    def _show_all_tiddlers(self):
        """Show every post in the current view (menu: Show All Posts)."""
        if not self.db:
            return
        if self._current_view() == 'tags':
            self._set_view('posts')
        self._browse('')

    def _current_view(self) -> str:
        return self.view_picker.currentData()

    def _set_view(self, key: str):
        """Select a view without triggering a reload."""
        self.view_picker.blockSignals(True)
        self.view_picker.setCurrentIndex(self.view_picker.findData(key))
        self.view_picker.blockSignals(False)

    @Slot()
    def _on_view_changed(self):
        self._offset = 0
        if self._current_view() == 'tags':
            self._show_all_tags()
        else:
            self._on_search()

    def _browse(self, query: str):
        items = self.db.browse(self._current_view(), query, mode=self.search_mode.currentText(),
                               limit=self._page_size + 1, offset=self._offset)
        self._populate_results(items)

    @Slot()
    def _show_all_tags(self, query: str = ''):
        """List tags (the Tags view); a search filters tag names."""
        if not self.db:
            return
        self._set_view('tags')
        tags = [t for t in self.db.all_tags() if query.lower() in t.lower()]
        self._offset = 0
        self.results_list.clear()
        self.prev_page.setEnabled(False)
        self.next_page.setEnabled(False)
        self.page_label.setText(f"{len(tags)} tags (unpaged)")
        for tag in tags:
            item = QListWidgetItem(f"🏷 {tag}")
            item.setData(Qt.UserRole, ("tag", tag))
            self.results_list.addItem(item)

    # --- Search ---

    @Slot()
    def _reset_search(self):
        self._offset = 0
        self._on_search()

    @Slot()
    def _next_page(self):
        if self.next_page.isEnabled():
            self._offset += self._page_size
            self._on_search()

    @Slot()
    def _previous_page(self):
        self._offset = max(0, self._offset - self._page_size)
        self._on_search()

    @Slot()
    def _on_search(self):
        if not self.db:
            return

        query = self.search_input.text().strip()
        if self._current_view() == 'tags':
            self._show_all_tags(query)
            return
        self._browse(query)

    def _populate_results(self, items: list[dict]):
        self.results_list.clear()
        self.prev_page.setEnabled(self._offset > 0)
        self.next_page.setEnabled(len(items) > self._page_size)
        items = items[:self._page_size]
        self.page_label.setText(f'Items {self._offset+1}–{self._offset+len(items)}' if items else 'No matches')
        for entry in items:
            item = QListWidgetItem(entry['label'])
            item.setData(Qt.UserRole, ("tiddler", entry['title']))
            item.setToolTip(entry['title'])
            self.results_list.addItem(item)

    # --- Preview ---

    @Slot(QListWidgetItem)
    def _on_result_clicked(self, item: QListWidgetItem):
        data = item.data(Qt.UserRole)
        if not data:
            return

        type_, value = data
        if type_ == "tiddler":
            self._show_tiddler(value)
        elif type_ == "tag":
            # Show every post with this tag (system posts included).
            self._set_view('all')
            self.search_mode.blockSignals(True)
            self.search_mode.setCurrentText("Tag")
            self.search_mode.blockSignals(False)
            self.search_input.blockSignals(True)
            self.search_input.setText(value)
            self.search_input.blockSignals(False)
            self._reset_search()

    @Slot(QListWidgetItem)
    def _on_result_double_clicked(self, item: QListWidgetItem):
        """Double-click opens a document for reading; Edit is an explicit action.

        Previously double-clicking popped up a raw markup editor, which looked
        like a failed document render and invited edits to protected evidence.
        """
        data = item.data(Qt.UserRole)
        if data and data[0] == "tiddler":
            self._show_tiddler(data[1])

    def _show_tiddler(self, title: str):
        if not self.db:
            return

        document = self.db.render(title)
        if document is None:
            from html import escape
            self._display_html(f"<h1>Not Found</h1><p>Tiddler '{escape(title)}' not found.</p>")
            self.current_tiddler = None
            return

        # UI-only navigation history.
        if not self._navigating_history:
            if self.history_pos < len(self.history) - 1:
                self.history = self.history[:self.history_pos + 1]
            if not self.history or self.history[-1] != title:
                self.history.append(title)
                self.history_pos = len(self.history) - 1
        self._update_nav_buttons()
        self.current_tiddler = title
        self._showing = None
        html = document
        self._display_html(html)

    def _update_nav_buttons(self):
        """Update back/forward button enabled state."""
        can_back = self.history_pos > 0
        can_forward = self.history_pos < len(self.history) - 1
        self.back_action.setEnabled(can_back)
        self.forward_action.setEnabled(can_forward)
        self.back_btn.setEnabled(can_back)
        self.forward_btn.setEnabled(can_forward)

    @Slot()
    def _go_back(self):
        if self.history_pos > 0:
            self.history_pos -= 1
            self._navigating_history = True
            self._show_tiddler(self.history[self.history_pos])
            self._navigating_history = False
            self._select_in_list(self.history[self.history_pos])

    @Slot()
    def _go_forward(self):
        if self.history_pos < len(self.history) - 1:
            self.history_pos += 1
            self._navigating_history = True
            self._show_tiddler(self.history[self.history_pos])
            self._navigating_history = False
            self._select_in_list(self.history[self.history_pos])

    def _show_welcome(self):
        """Show welcome/empty state in preview."""
        html = """<!DOCTYPE html>
<html>
<head>
<style>
body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    margin: 0;
    color: #888;
    background: #fafafa;
}
.welcome {
    text-align: center;
}
h1 { color: #666; font-weight: 300; }
p { margin: 0.5em 0; }
kbd {
    background: #eee;
    border: 1px solid #ddd;
    border-radius: 3px;
    padding: 2px 6px;
    font-family: inherit;
}
</style>
</head>
<body>
<div class="welcome">
<h1>PERSONAL.WIKI</h1>
<p>Open or create a database to get started</p>
<p><kbd>Ctrl+Shift+N</kbd> New database · <kbd>Ctrl+O</kbd> Open · <kbd>Ctrl+I</kbd> Import JSON</p>
</div>
</body>
</html>"""
        self._display_html(html)

    def _display_html(self, document: str):
        """Populate both renderers so a WebEngine failure never hides content."""
        self._preview_generation += 1
        generation = self._preview_generation
        self._preview_load_pending = True
        self.compat_preview.setHtml(document)
        if self._force_compat_preview or self.preview is None:
            self.preview_stack.setCurrentWidget(self.compat_preview)
            self._preview_load_pending = False
            return
        self.preview_stack.setCurrentWidget(self.preview)
        self.tiddler_page.set_document_html(document)
        QTimer.singleShot(6000, lambda: self._preview_timeout(generation))

    @Slot(bool)
    def _preview_loaded(self, ok: bool):
        if not self._preview_load_pending:
            return  # Denied hyperlink navigation is not an HTML-load failure.
        self._preview_load_pending = False
        if not ok:
            self._use_fallback('WebEngine document load failed')

    def _preview_timeout(self, generation: int):
        if generation == self._preview_generation and self._preview_load_pending:
            self._preview_load_pending = False
            self._use_fallback('WebEngine document load timed out')

    def _use_fallback(self, reason: str):
        self.preview_stack.setCurrentWidget(self.compat_preview)
        if hasattr(self, 'statusbar'):
            self.statusbar.showMessage(reason + '; compatibility preview is showing the page.', 10000)

    @Slot(bool)
    def _toggle_compat_preview(self, enabled: bool):
        self._force_compat_preview = enabled or self.preview is None
        self.preview_stack.setCurrentWidget(self.compat_preview if self._force_compat_preview else self.preview)
        if not self._force_compat_preview and self.db and self.current_tiddler:
            self._show_tiddler(self.current_tiddler)

    @Slot(QUrl)
    def _on_compat_link_clicked(self, url: QUrl):
        if url.scheme() == 'tw' and url.host() == 'tiddler':
            title = unquote(url.path().lstrip('/'))
            if title:
                self._show_tiddler(title)
        elif url.scheme() in ('https', 'http', 'mailto'):
            QDesktopServices.openUrl(url)

    @Slot(str)
    def _on_link_hovered(self, url: str):
        if url:
            self.statusbar.showMessage(url, 3000)

    # --- Projects, contracts, PVS ---

    @Slot()
    def _show_dashboard(self):
        if not self.db:
            QMessageBox.warning(self, "No Database", "Please create or open a database first.")
            return
        try:
            document = self.db.render_dashboard()
        except Exception as exc:
            QMessageBox.critical(self, 'Dashboard unavailable', str(exc))
            return
        self.current_tiddler = None
        self._showing = 'dashboard'
        self._display_html(document)

    @Slot()
    def _show_contracts(self):
        if not self.db:
            return
        try:
            document = self.db.render_contracts()
        except Exception as exc:
            QMessageBox.critical(self, 'Contracts unavailable', str(exc))
            return
        self.current_tiddler = None
        self._showing = 'contracts'
        self._display_html(document)

    @Slot()
    def _install_project_kit(self):
        if not self.db:
            QMessageBox.warning(self, "No Database", "Please create or open a database first.")
            return
        if self.db.readonly:
            return
        try:
            created = self.db.install_project_kit()
        except Exception as exc:
            QMessageBox.critical(self, 'Project kit not installed', str(exc))
            return
        self._update_status();self._refresh_results()
        if created:
            QMessageBox.information(self, 'Project kit installed', 'Added:\n' + '\n'.join(created))
            self._show_tiddler(created[-1])
        else:
            QMessageBox.information(self, 'Project kit', 'Already installed; nothing was changed.')

    @Slot()
    def _install_forms_kit(self):
        if not self.db:
            QMessageBox.warning(self, "No Database", "Please create or open a database first.")
            return
        try:
            created = self.db.install_forms_kit()
        except Exception as exc:
            QMessageBox.critical(self, 'Forms kit not installed', str(exc))
            return
        self._update_status();self._refresh_results()
        if created:
            QMessageBox.information(self, 'Forms kit installed',
                f'Added {len(created)} posts: a template and a contract for each form, and a guide.')
            self._show_tiddler(created[-1])
        else:
            QMessageBox.information(self, 'Forms kit', 'Already installed; nothing was changed.')

    @Slot()
    def _new_from_template(self):
        if not self.db:
            QMessageBox.warning(self, "No Database", "Please create or open a database first.")
            return
        try:
            if not self.db.list_templates():
                answer = QMessageBox.question(self, 'Forms kit',
                    'This notebook has no templates yet. Install the forms kit (5W1H, 5 Whys, A3, '
                    'ADR, PDCA, daily log, kanban, waterfall and argument)?',
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
                if answer != QMessageBox.Yes:
                    return
                self.db.install_forms_kit()
                self._refresh_results()
            chooser = TemplateDialog(self, self.db, self.current_tiddler)
            if chooser.exec() != QDialog.Accepted:
                return
            template, project = chooser.choice()
            preset = self.db.preset_from_template(template, project=project)
        except Exception as exc:
            QMessageBox.critical(self, 'Template', str(exc))
            return
        self._new_tiddler(preset)

    @Slot()
    def _export_bundle(self):
        if not self.db:
            return
        if self._import_thread is not None:
            QMessageBox.information(self, 'Import active', 'Finish the import first.')
            return
        from datetime import date
        self._catch_up_change_log()
        suggested = str(Path(self.db.db_path).with_name(
            f'{Path(self.db.db_path).stem}-{date.today().isoformat()}.pwbundle'))
        path, _ = QFileDialog.getSaveFileName(self, 'Export notebook bundle', suggested,
                                              'Notebook bundle (*.pwbundle)')
        if not path:
            return
        try:
            result = self.db.export_bundle(path)
        except Exception as exc:
            QMessageBox.critical(self, 'Bundle not written', str(exc))
            return
        QMessageBox.information(self, 'Bundle written',
            f"{result['bundle']}\n\n{result['posts']} posts, {result['events']} history events, "
            f"change log {result['change_log']['entries']} entries.\n"
            'Keep copies on another disk or machine.')

    @Slot()
    def _restore_bundle(self):
        if self._import_thread is not None:
            QMessageBox.information(self, 'Import active', 'Finish the import first.')
            return
        source, _ = QFileDialog.getOpenFileName(self, 'Restore notebook bundle', '',
                                                'Notebook bundle (*.pwbundle);;All Files (*)')
        if not source:
            return
        dest, _ = QFileDialog.getSaveFileName(self, 'Restore as new notebook', str(Path(source).with_suffix('.db')),
                                              'SQLite Database (*.db)')
        if not dest:
            return
        try:
            result = WikiCore.restore_bundle(source, dest)
        except Exception as exc:
            QMessageBox.critical(self, 'Not restored', str(exc))
            return
        QMessageBox.information(self, 'Notebook restored',
            f"{result['notebook']}\n\n{result['posts']} posts and {result['events']} history events verified; "
            f"change log {result['change_log']} entries intact." +
            (f"\n\n{result['pvs_note']}" if result['pvs_note'] else ''))
        self._load_database(dest)

    def _catch_up_change_log(self, announce: bool = False) -> list:
        """Log edits not yet in the change log. Quiet unless asked; never blocks."""
        if not self.db or self.db.readonly or self._import_thread is not None:
            return []
        try:
            written = self.db.update_change_log()
        except Exception as exc:
            self.statusbar.showMessage(f'Change log not updated: {exc}', 10000)
            return []
        if written and announce:
            self._refresh_results()
        return written

    @Slot()
    def _update_change_log(self):
        if not self.db:
            return
        written = self._catch_up_change_log(announce=True)
        if written:
            QMessageBox.information(self, 'Change log', 'Updated:\n' + '\n'.join(written))
            self._show_tiddler(written[-1])
        else:
            QMessageBox.information(self, 'Change log', 'Nothing new to log.')

    @Slot()
    def _refresh_from_pvs(self):
        if not self.db:
            QMessageBox.warning(self, "No Database", "Please create or open a database first.")
            return
        if self._import_thread is not None:
            QMessageBox.information(self, 'Import active', 'Finish the import first.')
            return
        try:
            state = self.db.pvs_state()
        except Exception as exc:
            QMessageBox.critical(self, 'PVS', str(exc))
            return
        root = None
        if not state['configured']:
            root = QFileDialog.getExistingDirectory(self, 'Choose the PVS workspace folder (contains objects/)')
            if not root:
                return
        self._run_refresh(root=root)

    @Slot()
    def _refresh_from_pvs_file(self):
        if not self.db:
            QMessageBox.warning(self, "No Database", "Please create or open a database first.")
            return
        path, _ = QFileDialog.getOpenFileName(self, 'PVS snapshot file (from tools/pvs_export.py)', '',
                                              'PVS snapshot (*.json);;All Files (*)')
        if path:
            self._run_refresh(snapshot_file=path)

    def _run_refresh(self, root=None, snapshot_file=None):
        import pvs_sync
        pvs_src = os.environ.get('PVS_SRC')
        while True:
            try:
                report = self.db.refresh_from_pvs(root, pvs_src=pvs_src, snapshot_file=snapshot_file)
                break
            except pvs_sync.WorkspaceMissing as exc:
                QMessageBox.information(self, 'PVS workspace moved', str(exc))
                root = QFileDialog.getExistingDirectory(self, 'Where is the PVS workspace now? (contains objects/)')
                if not root:
                    return
                continue
            except Exception as exc:
                if 'Cannot import PVS' in str(exc):
                    src = QFileDialog.getExistingDirectory(self,
                        'Choose the PVS "src" folder (contains fd_oop_reconstruction)')
                    if src:
                        pvs_src = src
                        os.environ['PVS_SRC'] = src
                        continue
                QMessageBox.critical(self, 'Refresh from PVS failed', str(exc))
                return
        self._update_status(); self._refresh_results()
        pending = len(report['to_enter']) + sum(1 for r in report['reasoning']
                                                 if not r['entered'] and not r['problem'])
        QMessageBox.information(self, 'Refreshed from PVS',
            f"New: {len(report['new'])} · status from PVS: {len(report['from_pvs'])} · "
            f"content changed: {len(report['content'])}\n"
            f"Now in sync: {len(report['in_sync'])} · to enter in PVS: {pending} · "
            f"conflicts: {len(report['conflicts'])} · no longer in PVS: {len(report['missing'])}\n\n"
            f"Recorded in: {report['log']}")
        self._show_pvs_sync()

    @Slot()
    def _show_pvs_sync(self):
        if not self.db:
            return
        try:
            state = self.db.pvs_state()
            self.current_tiddler = None
            self._showing = 'pvs'
            self._display_html(self.db.render_pvs_sync())
        except Exception as exc:
            QMessageBox.critical(self, 'PVS Sync', str(exc))
            return
        if state['conflicts']:
            self._resolve_conflicts(state['conflicts'])

    def _resolve_conflicts(self, conflicts: list):
        dlg = QDialog(self)
        dlg.setWindowTitle('PVS status conflicts')
        dlg.resize(640, 360)
        layout = QVBoxLayout(dlg)
        layout.addWidget(QLabel('Both you and PVS changed these statuses since the last refresh. '
                                'Choose which value stands. "Keep wiki" lists it to enter in PVS.'))
        lst = QListWidget(dlg)
        for c in conflicts:
            item = QListWidgetItem(f"{c['title']}   —   wiki: {c['wiki']}   ·   PVS: {c['pvs']}")
            item.setData(Qt.UserRole, c['title'])
            lst.addItem(item)
        lst.setCurrentRow(0)
        layout.addWidget(lst, stretch=1)
        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        take_pvs = buttons.addButton('Take PVS', QDialogButtonBox.ActionRole)
        keep_wiki = buttons.addButton('Keep wiki', QDialogButtonBox.ActionRole)
        buttons.rejected.connect(dlg.reject)
        layout.addWidget(buttons)

        def settle(choice):
            item = lst.currentItem()
            if item is None:
                return
            reason = self._request_reason('Reason for this resolution')
            if reason is None:
                return
            try:
                self.db.resolve_pvs_conflict(item.data(Qt.UserRole), choice, reason=reason)
            except Exception as exc:
                QMessageBox.warning(dlg, 'Not resolved', str(exc))
                return
            lst.takeItem(lst.row(item))
            self._display_html(self.db.render_pvs_sync())
            if lst.count() == 0:
                dlg.accept()
        take_pvs.clicked.connect(lambda: settle('pvs'))
        keep_wiki.clicked.connect(lambda: settle('wiki'))
        dlg.exec()

    @Slot()
    def _new_pvs_notebook(self):
        if self._import_thread is not None:
            QMessageBox.information(self, 'Import active', 'Finish the import first.')
            return
        root = QFileDialog.getExistingDirectory(self, 'Choose the PVS workspace folder (contains objects/)')
        if not root:
            return
        pvs_src = os.environ.get('PVS_SRC')
        suggested = str(Path(root).parent / 'pvs_snapshot.db')
        path, _ = QFileDialog.getSaveFileName(self, 'New snapshot notebook', suggested, 'SQLite Database (*.db)')
        if not path:
            return
        while True:
            try:
                summary = WikiCore.create_pvs_notebook(path, root, pvs_src=pvs_src)
                break
            except Exception as exc:
                if 'Cannot import PVS' in str(exc):
                    src = QFileDialog.getExistingDirectory(self,
                        'Choose the PVS "src" folder (contains fd_oop_reconstruction)')
                    if src:
                        pvs_src = src
                        os.environ['PVS_SRC'] = src
                        continue
                QMessageBox.critical(self, 'PVS snapshot failed', str(exc))
                return
        QMessageBox.information(self, 'PVS snapshot notebook created',
            f"{summary['projects']} project(s), {summary['records']} protected posts.\n"
            f"History verified: {summary['verified']}. Contract violations: {summary['violations']}.\n\n"
            'The snapshot is read-only. Take a new snapshot after changing PVS.')
        self._load_database(path)
        if self.db and self.db.db_path == path:
            self._show_dashboard()

    # --- Tiddler CRUD ---

    def _request_reason(self, heading: str) -> str | None:
        reason, accepted = QInputDialog.getText(self, heading,
            'Why are you making this change? (Required for history)')
        if not accepted:return None
        if not reason.strip():
            QMessageBox.warning(self, 'Reason required', 'Please describe the reason for the change.')
            return None
        return reason.strip()

    @Slot()
    def _show_post_history(self):
        if not self.db:return
        if self._import_thread is not None:
            QMessageBox.information(self,'Import active','Finish importing before inspecting history.')
            return
        try:
            posts=self.db.history_posts()
            if not posts:
                QMessageBox.information(self, 'Post history','No versions recorded yet.')
                return
            dlg=QDialog(self)
            dlg.setWindowTitle('Post History')
            dlg.resize(900,650)
            layout=QVBoxLayout(dlg)
            selector=QComboBox(dlg)
            for post in posts:
                label=('[Deleted] ' if post['deleted'] else '') + post['last_title']
                selector.addItem(label,post['post_id'])
            layout.addWidget(QLabel('Post:'))
            layout.addWidget(selector)
            versions=QListWidget(dlg)
            layout.addWidget(versions)
            details=QPlainTextEdit(dlg)
            details.setReadOnly(True)
            layout.addWidget(details)
            btn=QDialogButtonBox(QDialogButtonBox.Close)
            restore_btn=btn.addButton('Restore This Version…', QDialogButtonBox.ActionRole)
            btn.rejected.connect(dlg.reject)
            layout.addWidget(btn)
            entries=[]
            def restore_selected():
                idx=versions.currentRow()
                if idx<0 or idx>=len(entries):return
                row=entries[idx]
                post_id=selector.currentData()
                reason=self._request_reason('Reason for restoring this version')
                if reason is None:return
                try:
                    result=self._with_ack(lambda ack: self.db.restore_version(
                        post_id, row['event_id'], reason=reason, acknowledge_contract_change=ack))
                except _Declined:
                    return
                except Exception as exc:
                    QMessageBox.warning(dlg,'Not restored',str(exc))
                    return
                where=('as a new version of the post' if result['mode']=='edit' else
                       'as a NEW post (the deleted post\'s history stays closed)')
                QMessageBox.information(dlg,'Version restored',
                    f"Restored {result['title']!r} {where}. History was not rewritten.")
                dlg.accept()
                self._update_status();self._refresh_results()
                self._show_tiddler(result['title']);self._select_in_list(result['title'])
            restore_btn.clicked.connect(restore_selected)
            def select_version():
                idx=versions.currentRow()
                if idx<0 or idx>=len(entries):return
                row=entries[idx]
                before=json.loads(row['before_json']) if row['before_json'] else None
                after=json.loads(row['after_json']) if row['after_json'] else None
                details.setPlainText(
                    f"When (UTC): {row['changed_at']}\n"
                    f"Change: {row['change_type']}\nWhy: {row['reason']}\n"
                    f"Title: {row['title']}\nPrevious: {row['old_title']}\n"
                    f"Before SHA-256: {row['before_sha256']}\n"
                    f"After SHA-256: {row['after_sha256']}\n\n"
                    "ORIGINAL / BEFORE:\n" + json.dumps(before,ensure_ascii=False,indent=2) +
                    "\n\nVERSION AFTER:\n" + json.dumps(after,ensure_ascii=False,indent=2))
            def select_post():
                nonlocal entries
                entries=self.db.post_history(selector.currentData())
                versions.clear()
                for row in entries:
                    versions.addItem(f"{row['changed_at']} — {row['change_type']} — {row['reason']}")
                if entries:versions.setCurrentRow(len(entries)-1)
            versions.currentRowChanged.connect(lambda _:select_version())
            selector.currentIndexChanged.connect(lambda _:select_post())
            if self.current_tiddler:
                ix=selector.findText(self.current_tiddler)
                if ix>=0:selector.setCurrentIndex(ix)
            select_post()
            dlg.exec()
        except Exception as exc:
            QMessageBox.critical(self,'History unavailable',str(exc))

    def _with_ack(self, operation):
        """Run ``operation(acknowledge)``; ask the owner if a contract change needs it."""
        try:
            return operation(False)
        except ContractAcknowledgementRequired as exc:
            answer = QMessageBox.question(self, 'Contract change',
                str(exc) + '\n\nApply this contract change anyway? The history reason will be '
                'marked as acknowledged by you.', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if answer != QMessageBox.Yes:
                raise _Declined() from exc
            return operation(True)

    @Slot()
    def _new_project_item(self):
        if not self.db:
            QMessageBox.warning(self, "No Database", "Please create or open a database first.")
            return
        try:
            if not self.db.field_schemas():
                answer = QMessageBox.question(self, 'Project kit',
                    'This notebook has no project contracts yet. Install the project kit '
                    '(contracts for project, goal, milestone, task and a guide post)?',
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
                if answer == QMessageBox.Yes:
                    self.db.install_project_kit()
                    self._refresh_results()
            chooser = ProjectItemDialog(self, self.db, self.current_tiddler)
        except Exception as exc:
            QMessageBox.critical(self, 'Project item', str(exc))
            return
        if chooser.exec() != QDialog.Accepted:
            return
        self._new_tiddler(chooser.preset())

    @Slot()
    def _new_tiddler(self, preset: dict | None = None):
        if not isinstance(preset, dict):
            preset = None
        if not self.db:
            QMessageBox.warning(
                self,
                "No Database",
                "Please create or open a database first.",
            )
            return

        if self._import_thread is not None:
            QMessageBox.information(self, 'Import active',
                'Finish the import before saving a note.')
            return
        dialog = TiddlerEditor(self, core=self.db, preset=preset)
        # Reuse the SAME editor after a save failure so the user's draft is
        # still visible, editable and cancellable; never silently retry writes.
        while dialog.exec() == QDialog.Accepted:
            data = dialog.get_tiddler_data()
            if self._import_thread is not None:
                QMessageBox.warning(self, 'Import active',
                    'Your draft has NOT been saved. Finish the import, then try Save again.')
                continue
            try:
                if self.db.get_tiddler(data['title']):
                    QMessageBox.warning(self, 'Title Exists',
                        'That title already exists. Your draft is unchanged; choose a different title.')
                    continue
                self._with_ack(lambda ack: self.db.save_tiddler(
                    data['title'], data['text'], data['tags'], fields=data['fields'],
                    acknowledge_contract_change=ack))
            except _Declined:
                continue
            except SchemaError as exc:
                QMessageBox.warning(self, 'Fields do not match the contract',
                    'Not saved — the editor will reopen with your draft.\n\n' + str(exc))
                continue
            except Exception as exc:
                QMessageBox.critical(self, 'Note not saved',
                    'SQLite could not save this note. The editor will reopen with your '
                    'draft intact. Resolve any concurrent import or database lock '
                    'before trying Save again.\n\n'+str(exc))
                continue
            self._update_status()
            self._refresh_results()
            self._show_tiddler(data['title'])
            self._select_in_list(data['title'])
            break

    @Slot()
    def _edit_current_tiddler(self):
        if self._import_thread is not None:
            QMessageBox.information(self, 'Import active',
                'Finish the import before editing a note.')
            return
        if not self.db:
            QMessageBox.warning(self, "No Database", "No database loaded.")
            return

        if not self.current_tiddler:
            QMessageBox.information(
                self, "No Tiddler Selected", "Please select a tiddler to edit."
            )
            return

        tiddler = self.db.get_tiddler(self.current_tiddler)
        if not tiddler:
            return
        if self.db.is_protected(self.current_tiddler):
            QMessageBox.information(
                self, "Protected research record",
                "This historical source record is protected against editing. "
                "To add a correction or interpretation, create a new versioned note."
            )
            return

        dialog = TiddlerEditor(self, tiddler, core=self.db)
        while dialog.exec() == QDialog.Accepted:
            data = dialog.get_tiddler_data()
            old_title = data['original_title']
            new_title = data['title']
            if self._import_thread is not None:
                QMessageBox.warning(self, 'Import active',
                    'Your changes have NOT been saved. The editor will reopen with the draft.')
                continue
            reason = self._request_reason('Reason for edit')
            if reason is None:continue  # preserve draft for correction or cancel
            try:
                if not self._with_ack(lambda ack: self.db.update_tiddler(
                        old_title, new_title, data['text'], data['tags'], reason=reason,
                        fields=data['fields'], acknowledge_contract_change=ack)):
                    QMessageBox.warning(self, 'Edit failed',
                        'Original record no longer exists. The editor will reopen with your text.')
                    continue
            except _Declined:
                continue
            except SchemaError as exc:
                QMessageBox.warning(self, 'Fields do not match the contract',
                    'Not saved — the editor will reopen with your draft.\n\n' + str(exc))
                continue
            except Exception as exc:
                QMessageBox.critical(self, 'Edit rolled back',
                    'Your changes have NOT been saved. The editor will reopen with your '
                    'draft intact. Resolve any database lock and retry, or copy your text.\n\n'+str(exc))
                continue
            self._update_status()
            self._refresh_results()
            self._show_tiddler(new_title)
            self._select_in_list(new_title)
            break

    @Slot()
    def _delete_current_tiddler(self):
        if self._import_thread is not None:
            QMessageBox.information(self, 'Import active',
                'Finish the import before deleting a note.')
            return
        if not self.db or not self.current_tiddler:
            return

        reply = QMessageBox.question(
            self,
            "Delete Tiddler",
            f"Are you sure you want to delete '{self.current_tiddler}'?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )

        if reply == QMessageBox.Yes:
            if self._import_thread is not None:
                QMessageBox.warning(self, 'Import active',
                    'Finish the import before deleting a note.')
                return
            reason=self._request_reason('Reason for deletion')
            if reason is None:return
            title = self.current_tiddler
            try:self._with_ack(lambda ack: self.db.delete_tiddler(
                    title, reason=reason, acknowledge_contract_change=ack))
            except _Declined:
                return
            except Exception as exc:
                QMessageBox.warning(self, 'Protected record', str(exc))
                return
            self.current_tiddler = None
            self._update_status()
            self._refresh_results()
            self._show_welcome()

    def _refresh_results(self):
        """Refresh the results list, keeping the current view and search."""
        self._on_search()

    def _select_in_list(self, title: str):
        """Select a tiddler in the results list."""
        for i in range(self.results_list.count()):
            item = self.results_list.item(i)
            data = item.data(Qt.UserRole)
            if data and data[0] == "tiddler" and data[1] == title:
                self.results_list.setCurrentItem(item)
                break

    # --- Cleanup ---

    def closeEvent(self, event):
        if self._import_thread is not None:
            QMessageBox.warning(self, 'Import active', 'Finish the atomic import before closing.')
            event.ignore()
            return
        if self.db:
            self._catch_up_change_log()
            self.db.close()
        event.accept()
