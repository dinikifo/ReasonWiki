"""Post preview: optional Qt WebEngine page that only loads app-generated HTML.

A Raspberry Pi or restricted Linux desktop may have QtWidgets but no
QtWebEngine; WIKI_PREVIEW_MODE=qt avoids importing it at all, and the window
then uses its QTextBrowser fallback.
"""
import os

from PySide6.QtCore import QUrl, Slot
from PySide6.QtGui import QDesktopServices
from urllib.parse import unquote

__all__ = ['WEBENGINE_AVAILABLE', 'QWebEngineView', 'QWebEnginePage', 'QWebEngineSettings', 'TiddlerPage']

WEBENGINE_AVAILABLE = False
QWebEngineView = QWebEnginePage = QWebEngineSettings = None
if os.environ.get('WIKI_PREVIEW_MODE', 'auto').lower() != 'qt':
    try:
        from PySide6.QtWebEngineWidgets import QWebEngineView
        from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineSettings
        WEBENGINE_AVAILABLE = True
    except (ImportError, OSError, RuntimeError):
        pass


class TiddlerPage(QWebEnginePage if WEBENGINE_AVAILABLE else object):
    """Page that admits only application HTML loads and delegates clicked links.

    Rejecting every URL prevents QWebEnginePage.setHtml() from displaying *any*
    content, because Qt loads the supplied document through a data: navigation.
    Keep this exception scoped to a programmatic document load and deny links
    into arbitrary data:, file:, about:, or remote embedded pages.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.link_clicked_callback = None
        self._loading_internal_document = False
        self.loadFinished.connect(self._end_internal_load)

    def set_document_html(self, document: str):
        self._loading_internal_document = True
        self.setHtml(document, QUrl("about:blank"))

    @Slot(bool)
    def _end_internal_load(self, ok: bool):
        self._loading_internal_document = False

    def acceptNavigationRequest(self, url: QUrl, nav_type, is_main_frame: bool) -> bool:
        scheme = url.scheme().lower()
        # TiddlyWiki links are handled by the app, not opened as webpages.
        if scheme == "tw":
            if nav_type == QWebEnginePage.NavigationType.NavigationTypeLinkClicked:
                if url.host() == "tiddler" and self.link_clicked_callback:
                    title = unquote(url.path().lstrip('/'))
                    if title:
                        self.link_clicked_callback(title)
            return False

        # Allow only the document load *we* initiated. setHtml() uses data:
        # internally; blocking it produced the observed empty white viewer.
        if (self._loading_internal_document and is_main_frame
                and scheme in ("data", "about")
                and nav_type in (QWebEnginePage.NavigationType.NavigationTypeOther,
                                 QWebEnginePage.NavigationType.NavigationTypeTyped)):
            return True

        # Open external hyperlinks only following a user click. Never allow the
        # embedded renderer to navigate away from its isolated document.
        if (nav_type == QWebEnginePage.NavigationType.NavigationTypeLinkClicked
                and scheme in ("https", "http", "mailto")):
            QDesktopServices.openUrl(url)
        return False
