"""PERSONAL.WIKI post versions, held in a separate, per-folder SQLite file.

Content schema v2 is unchanged. The history file is a separate SQLite database;
SQLite ATTACH is connection-local, used only to commit both files together.
"""
from __future__ import annotations

from contextlib import closing, contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import uuid

from db import (TiddlerDB, _valid_record, parse_tags, encode_tags, _utc_stamp, _publish_temp,
                record_sha256, custom_fields, CORE_KEYS as _CORE_KEYS)
import field_schema as fs

ACK_NOTE = ' [contract change acknowledged by owner]'
MANAGED_TAG = 'pvs'


class ManagedPostError(PermissionError):
    """A PVS-managed post was changed in a way only 'Refresh from PVS' may make."""


def is_managed(record: dict | None) -> bool:
    return bool(record) and MANAGED_TAG in parse_tags(record.get('tags', []))


def _pvs_owned(record: dict) -> dict:
    """The parts of a managed post that belong to PVS: pvs_* fields and parent."""
    return {k: v for k, v in record.items() if k.startswith('pvs_') or k == 'parent'}


class HistoryError(RuntimeError):
    pass


class HistoryMissingError(HistoryError):
    pass


def history_path(db_path: str) -> Path:
    p = Path(db_path)
    return p.with_name(p.stem + '.history.sqlite')


def _json(record: dict | None) -> str | None:
    if record is None:
        return None
    return json.dumps(record, ensure_ascii=False, separators=(',', ':'))


# Stable digest of the complete post object, including unknown TW fields.
post_sha256 = record_sha256


def _when() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='microseconds')


HISTORY_SCHEMA = """
CREATE TABLE posts (
  post_id TEXT PRIMARY KEY,
  current_title TEXT UNIQUE,
  last_title TEXT NOT NULL,
  current_sha256 TEXT,
  deleted INTEGER NOT NULL DEFAULT 0 CHECK(deleted IN (0,1))
);
CREATE TABLE events (
  event_id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id TEXT NOT NULL REFERENCES posts(post_id),
  changed_at TEXT NOT NULL,
  change_type TEXT NOT NULL CHECK(change_type IN
    ('first_version','edit','rename','delete','import_overwrite')),
  reason TEXT NOT NULL CHECK(length(trim(reason)) > 0),
  old_title TEXT,
  title TEXT NOT NULL,
  before_json TEXT,
  before_sha256 TEXT,
  after_json TEXT,
  after_sha256 TEXT
);
CREATE INDEX events_by_post ON events(post_id,event_id);
PRAGMA user_version=1;
"""


def _init_history(conn: sqlite3.Connection) -> None:
    conn.executescript(HISTORY_SCHEMA)
    conn.commit()


def _append(conn: sqlite3.Connection, *, before: dict | None, after: dict | None,
            change_type: str, reason: str, previous_title: str | None = None) -> None:
    """Record an event inside the caller's same cross-file transaction."""
    if not isinstance(reason, str) or not reason.strip():
        raise ValueError('A reason is required for this change')
    if before is None and after is None:
        raise ValueError('History event requires a before or after record')
    old_title = before['title'] if before else None
    new_title = after['title'] if after else old_title
    if before is None:
        if change_type != 'first_version':
            raise HistoryError('New posts must start with a first_version event')
        if conn.execute('SELECT 1 FROM hist.posts WHERE current_title=?', (new_title,)).fetchone():
            raise HistoryError('History already tracks this title')
        post_id = uuid.uuid4().hex
        conn.execute('INSERT INTO hist.posts(post_id,current_title,last_title,current_sha256,deleted) '
                     'VALUES(?,?,?,?,0)', (post_id,new_title,new_title,post_sha256(after)))
    else:
        post = conn.execute('SELECT post_id,current_sha256 FROM hist.posts '
                            'WHERE current_title=? AND deleted=0', (old_title,)).fetchone()
        if post is None or post['current_sha256'] != post_sha256(before):
            raise HistoryError(f'History mismatch for {old_title!r}; refusing change')
        post_id = post['post_id']
        if after is None:
            conn.execute('UPDATE hist.posts SET current_title=NULL,current_sha256=NULL,deleted=1 '
                         'WHERE post_id=?', (post_id,))
        else:
            conn.execute('UPDATE hist.posts SET current_title=?,last_title=?,current_sha256=? '
                         'WHERE post_id=?', (new_title,new_title,post_sha256(after),post_id))
    conn.execute('''INSERT INTO hist.events
        (post_id,changed_at,change_type,reason,old_title,title,
         before_json,before_sha256,after_json,after_sha256)
         VALUES (?,?,?,?,?,?,?,?,?,?)''',
         (post_id,_when(),change_type,reason.strip(),previous_title or old_title,new_title,
          _json(before),post_sha256(before) if before else None,
          _json(after),post_sha256(after) if after else None))


def initialize_history(db_path: str) -> Path:
    """Explicit one-time baseline. No claims about edits predating this snapshot.

    Holds the content writer lock until the complete new sidecar is published.
    Existing history is NEVER replaced (including symlinks).
    """
    db_file = Path(db_path)
    sidecar = history_path(db_path)
    if sidecar.exists() or sidecar.is_symlink():
        raise FileExistsError(f'History already exists: {sidecar}')
    if db_file.is_symlink() or not db_file.is_file():
        raise HistoryError('Content database must be a regular existing file')
    with TiddlerDB(str(db_file),journal_mode='DELETE') as db:
        mode = db.conn.execute('PRAGMA journal_mode=DELETE').fetchone()[0]
        if mode.lower() != 'delete':
            raise HistoryError('Cannot safely initialize history while SQLite WAL is active')
        db.conn.execute('PRAGMA synchronous=EXTRA')
        with tempfile.TemporaryDirectory(prefix='.pw_history_init_', dir=db_file.parent) as tmpdir:
            staged = Path(tmpdir) / 'baseline.history.sqlite'
            with closing(sqlite3.connect(staged)) as hist:
                hist.row_factory=sqlite3.Row
                hist.execute('PRAGMA foreign_keys=ON')
                hist.execute('PRAGMA journal_mode=DELETE')
                hist.execute('PRAGMA synchronous=EXTRA')
                _init_history(hist)
                db.conn.execute('BEGIN IMMEDIATE')
                try:
                    # Do not create a schema relation to the content database.
                    # This is a one-time independent inventory of complete objects.
                    rows = db.conn.execute('SELECT title FROM tiddlers ORDER BY title').fetchall()
                    hist.execute('BEGIN IMMEDIATE')
                    try:
                        for (title,) in rows:
                            obj=db._get_raw(title)
                            pid=uuid.uuid4().hex
                            digest=post_sha256(obj)
                            hist.execute('INSERT INTO posts VALUES(?,?,?,?,0)',
                                         (pid,title,title,digest))
                            hist.execute('''INSERT INTO events
                                (post_id,changed_at,change_type,reason,old_title,title,
                                 before_json,before_sha256,after_json,after_sha256)
                                 VALUES(?,?,?,?,?,?,?,?,?,?)''',
                                (pid,_when(),'first_version',
                                 'First recorded version (history enabled; earlier edits unknown)',
                                 None,title,None,None,_json(obj),digest))
                        hist.commit()
                    except BaseException:
                        hist.rollback()
                        raise
                    if hist.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                        raise HistoryError('History baseline failed integrity check')
                    if os.name=='posix': os.chmod(staged, 0o600)
                    _publish_temp(str(staged),sidecar,overwrite=False)
                finally:
                    db.conn.rollback()  # release writer lock; no main content changes
    return sidecar


class HistoryTiddlerDB(TiddlerDB):
    """TiddlerDB with atomic, per-post audit history for write operations."""
    def __init__(self, db_path: str='tiddlers.db', readonly: bool=False):
        self.history_file=history_path(db_path)
        if not readonly and (not self.history_file.is_file() or self.history_file.is_symlink()):
            raise HistoryMissingError(
                f'No history file for {db_path}. Initialize a first snapshot explicitly.')
        super().__init__(db_path,readonly=readonly,journal_mode='DELETE')
        try:
            if (not self.history_file.is_file() or self.history_file.is_symlink()):
                raise HistoryMissingError(
                    f'No history file for {db_path}. Initialize the first snapshot explicitly.')
            if readonly:
                # An existing history file is attached read-only. URI mode=ro
                # refuses to create a missing file and does not need Qt.
                uri = self.history_file.resolve().as_uri() + '?mode=ro'
                self.conn.execute('ATTACH DATABASE ? AS hist', (uri,))
                if self.conn.execute('PRAGMA hist.user_version').fetchone()[0] != 1:
                    raise HistoryError('Unsupported history schema; refusing read-only history access')
                return
            # SQLite multi-file commit is crash-atomic only if main is a disk DB
            # and rollback journaling is used, not WAL.
            mode=self.conn.execute('PRAGMA main.journal_mode=DELETE').fetchone()[0]
            if mode.lower()!='delete':
                raise HistoryError('History requires rollback-journal mode (DELETE); close other connections')
            self.conn.execute('PRAGMA main.synchronous=EXTRA')
            self.conn.execute('ATTACH DATABASE ? AS hist', (str(self.history_file),))
            if self.conn.execute('PRAGMA hist.user_version').fetchone()[0]!=1:
                raise HistoryError('Unsupported history schema; refusing writable open')
            if self.conn.execute('PRAGMA hist.journal_mode=DELETE').fetchone()[0].lower()!='delete':
                raise HistoryError('History is not in rollback-journal mode')
            self.conn.execute('PRAGMA hist.synchronous=EXTRA')
            self.verify_history()
        except BaseException:
            self.close()
            raise

    def _projection_matches(self, title: str, raw: dict) -> bool:
        """Audit searchable columns and tag index, not only raw_json."""
        return not self._projection_problems(title, raw)

    def verify_history(self) -> dict:
        """Check every event digest and the exact current-post inventory."""
        problems=[]
        try:
            if self.conn.execute('PRAGMA hist.integrity_check').fetchone()[0]!='ok':
                problems.append('History SQLite integrity failure')
            if self.conn.execute('PRAGMA hist.foreign_key_check').fetchone():
                problems.append('History foreign-key failure')
            for row in self.conn.execute('SELECT event_id,before_json,before_sha256,after_json,after_sha256 '
                                         'FROM hist.events'):
                for field in ('before','after'):
                    raw=row[field+'_json']; digest=row[field+'_sha256']
                    if (raw is None) != (digest is None):
                        problems.append(f'Event {row["event_id"]}: incomplete {field} snapshot')
                    elif raw is not None:
                        try:
                            if post_sha256(json.loads(raw)) != digest:
                                problems.append(f'Event {row["event_id"]}: invalid {field} hash')
                        except (ValueError,TypeError):
                            problems.append(f'Event {row["event_id"]}: unreadable {field} snapshot')
            tracked=0
            for row in self.conn.execute('SELECT post_id,current_title,current_sha256,deleted FROM hist.posts'):
                sequence=self.conn.execute('SELECT change_type,before_sha256,after_sha256,old_title,title '
                    'FROM hist.events WHERE post_id=? ORDER BY event_id',
                    (row['post_id'],)).fetchall()
                if not sequence:
                    problems.append('Post without recorded first version')
                    continue
                first=sequence[0]
                if (first['change_type'] != 'first_version' or
                        first['before_sha256'] is not None or first['after_sha256'] is None):
                    problems.append('Post missing a valid first_version snapshot')
                for previous,current in zip(sequence,sequence[1:]):
                    if (previous['after_sha256'] is None or
                            current['before_sha256']!=previous['after_sha256'] or
                            current['old_title']!=previous['title'] or
                            current['change_type']=='first_version'):
                        problems.append('Broken version sequence for post '+row['post_id'])
                last=sequence[-1]
                if row['deleted']:
                    if row['current_title'] is not None or row['current_sha256'] is not None or last['change_type']!='delete':
                        problems.append('Inconsistent deletion in history')
                    continue
                tracked+=1
                title=row['current_title']
                raw=self._get_raw(title)
                if (raw is None or post_sha256(raw)!=row['current_sha256'] or
                        not self._projection_matches(title,raw) or
                        last['after_sha256']!=row['current_sha256'] or
                        last['title']!=title):
                    problems.append('Content/history disagreement: '+str(title))
            if tracked!=self.count():
                problems.append(f'History tracks {tracked} active posts; content has {self.count()}')
        except (sqlite3.DatabaseError,ValueError,TypeError) as exc:
            problems.append('History query failed: '+str(exc))
        if problems:
            raise HistoryError('History verification failed; changes refused: '+'; '.join(problems[:6]))
        return {'active_posts':tracked,'events':self.conn.execute('SELECT COUNT(*) FROM hist.events').fetchone()[0],
                'verified':True}

    # ------------------------------------------------------------------
    # Typed fields: contracts are $:/schema/<tag> posts (see field_schema)
    # ------------------------------------------------------------------
    def field_schemas(self) -> dict[str, dict]:
        """Every readable contract keyed by tag. A broken contract post raises."""
        result = {}
        for (title,) in self.conn.execute(
                "SELECT title FROM tiddlers WHERE substr(title,1,?)=? ORDER BY title",
                (len(fs.SCHEMA_PREFIX), fs.SCHEMA_PREFIX)):
            tag = fs.schema_tag(title)
            if tag is None:
                continue
            raw = self._get_raw(title)
            try:
                result[tag] = fs.parse_schema_text(raw.get('text', ''))
            except fs.SchemaError as exc:
                raise fs.SchemaError(f'Contract post {title!r} is unreadable: {exc}') from exc
        return result

    def contract_violations(self, tag: str | None = None, schemas: dict | None = None) -> list[dict]:
        """Posts whose fields do not satisfy the contract of one of their tags."""
        schemas = self.field_schemas() if schemas is None else schemas
        found = []
        for t, schema in sorted(schemas.items()):
            if tag is not None and t != tag:
                continue
            for (title,) in self.conn.execute('SELECT title FROM tiddler_tags WHERE tag=? ORDER BY title', (t,)):
                raw = self._get_raw(title)
                try:
                    fs.validate(custom_fields(raw), schema)
                except fs.SchemaError as exc:
                    found.append({'title': title, 'tag': t, 'problem': str(exc)})
        return found

    @contextmanager
    def managed_writes(self):
        """Allow writes to PVS-managed posts (used only by the PVS refresh)."""
        previous = getattr(self, '_managed_ok', False)
        self._managed_ok = True
        try:
            yield
        finally:
            self._managed_ok = previous

    def _ownership_gate(self, before: dict | None, after: dict | None) -> None:
        """PVS owns parent and pvs_* on managed posts; the user owns text, tags, status."""
        if getattr(self, '_managed_ok', False):
            return
        if before is None:
            if is_managed(after):
                raise ManagedPostError('Only Refresh from PVS creates posts tagged "pvs".')
            return
        if not is_managed(before):
            if is_managed(after):
                raise ManagedPostError('Only Refresh from PVS can add the "pvs" tag.')
            return
        name = before['title']
        if after is None:
            if before.get('pvs_presence') == 'missing':
                return  # PVS dropped it; deleting the wiki copy is the user's call
            raise ManagedPostError(f'{name!r} comes from PVS. Remove it in PVS, then refresh.')
        if after.get('title') != name:
            raise ManagedPostError(f'{name!r} comes from PVS; its title is its PVS identity and cannot change.')
        if not is_managed(after):
            raise ManagedPostError(f'{name!r} comes from PVS; the "pvs" tag cannot be removed.')
        old, new = _pvs_owned(before), _pvs_owned(after)
        changed = sorted(k for k in set(old) | set(new) if old.get(k) != new.get(k))
        if changed:
            raise ManagedPostError(f'{name!r}: {", ".join(changed)} belong(s) to PVS. Change it in PVS, '
                                   'then refresh. (Text, tags and status are yours to edit.)')

    def _typing_gate(self, before: dict | None, after: dict | None, acknowledge: bool) -> bool:
        """Run inside the write transaction, AFTER the new state is stored.

        Returns True when an acknowledgement was actually needed and given,
        so the caller can mark the history reason. Raises to roll back.
        """
        self._ownership_gate(before, after)
        acknowledged = False
        old_tag = fs.schema_tag(before['title']) if before else None
        new_tag = fs.schema_tag(after['title']) if after else None
        if old_tag is not None or new_tag is not None:
            old_schema = None
            if old_tag is not None:
                try:
                    old_schema = fs.parse_schema_text(before.get('text', ''))
                except fs.SchemaError:
                    old_schema = None  # repairing a broken contract is not a relaxation
            new_schema = fs.parse_schema_text(after.get('text', '')) if new_tag is not None else None
            if old_tag is not None and old_tag != new_tag and old_schema is not None:
                if not acknowledge:
                    raise fs.ContractAcknowledgementRequired(
                        f'This removes the field contract for tag {old_tag!r}; posts tagged '
                        f'{old_tag!r} will no longer be checked.', tag=old_tag)
                acknowledged = True
            if new_tag is not None:
                prior = old_schema if old_tag == new_tag else None
                if prior is not None and not fs.narrows_or_equals(new_schema, prior):
                    if not acknowledge:
                        raise fs.ContractAcknowledgementRequired(
                            f'The new contract for {new_tag!r} loosens the old one (or the wiki '
                            'cannot prove it is a tightening).', tag=new_tag)
                    acknowledged = True
                violations = self.contract_violations(new_tag, {new_tag: new_schema})
                if violations:
                    if not acknowledge:
                        names = ', '.join(v['title'] for v in violations[:8])
                        raise fs.ContractAcknowledgementRequired(
                            f'{len(violations)} existing post(s) tagged {new_tag!r} do not satisfy '
                            f'the new contract: {names}. They will be listed as violations.',
                            tag=new_tag, violations=[v['title'] for v in violations])
                    acknowledged = True
        if after is not None and new_tag is None:
            tags = parse_tags(after.get('tags', []))
            if tags:
                schemas = self.field_schemas()
                for tag in tags:
                    if tag in schemas:
                        try:
                            fs.validate(custom_fields(after), schemas[tag])
                        except fs.SchemaError as exc:
                            raise fs.SchemaError(f'Contract {fs.schema_title(tag)!r}: {exc}') from exc
        return acknowledged

    @staticmethod
    def _reason(reason: str, acknowledged: bool) -> str:
        return reason.strip() + (ACK_NOTE if acknowledged else '')

    # ------------------------------------------------------------------
    # Writes. Every path: store, typing gate, history event, one transaction.
    # ------------------------------------------------------------------
    def save_tiddler(self, title: str, text: str, tags: list[str], fields: dict | None=None,
                     created: str | None=None, reason: str | None=None,
                     acknowledge_contract_change: bool=False) -> None:
        if self.readonly: raise PermissionError('Read-only database')
        if not title: raise ValueError('Title required')
        with self.conn:
            if self.is_protected(title): raise PermissionError('Historical source is protected')
            before=self._get_raw(title)
            if before is not None and not (reason or '').strip():
                raise ValueError('A reason is required to change an existing post')
            item=dict(before) if before else {'title':title}
            item.update(fields or {})
            item['title']=title;item['text']=text
            item['tags']=encode_tags(tags) if isinstance(item.get('tags'),str) else list(tags)
            item['created']=created or item.get('created') or _utc_stamp()
            item['modified']=_utc_stamp()
            self._store(item)
            ack=self._typing_gate(before,item,acknowledge_contract_change)
            _append(self.conn,before=before,after=item,
                    change_type='edit' if before else 'first_version',
                    reason=self._reason(reason or 'First version — new post created',ack))

    def update_tiddler(self,old_title: str,new_title: str,text: str,tags: list[str],
                       reason: str | None=None, fields: dict | None=None,
                       acknowledge_contract_change: bool=False) -> bool:
        """Edit/rename. ``fields`` (if given) REPLACES the custom field set."""
        if self.readonly:raise PermissionError('Read-only database')
        if not new_title: raise ValueError('Title required')
        if not (reason or '').strip(): raise ValueError('A reason is required for editing')
        with self.conn:
            before=self._get_raw(old_title)
            if before is None:return False
            after={k:v for k,v in before.items() if k in _CORE_KEYS} if fields is not None else dict(before)
            if fields is not None:
                bad=set(fields) & _CORE_KEYS
                if bad: raise ValueError(f'Reserved field name(s): {sorted(bad)}')
                after.update(fields)
            after['title']=new_title;after['text']=text
            after['tags']=encode_tags(tags) if isinstance(before.get('tags'),str) else list(tags)
            self._replace(before,after,reason,acknowledge_contract_change)
        return True

    def replace_tiddler(self, old_title: str, record: dict, *, reason: str,
                        acknowledge_contract_change: bool=False) -> bool:
        """Replace a post with a complete record (used by restore)."""
        if self.readonly:raise PermissionError('Read-only database')
        if not (reason or '').strip(): raise ValueError('A reason is required')
        with self.conn:
            before=self._get_raw(old_title)
            if before is None:return False
            self._replace(before,dict(record),reason,acknowledge_contract_change)
        return True

    def _replace(self, before: dict, after: dict, reason: str, acknowledge: bool) -> None:
        old_title=before['title']; new_title=after.get('title')
        if not isinstance(new_title,str) or not new_title: raise ValueError('Title required')
        if self.is_protected(old_title):raise PermissionError('Historical record is protected')
        if old_title!=new_title and self._get_raw(new_title) is not None:
            raise ValueError('Destination title already exists')
        if 'created' in before and 'created' not in after: after['created']=before['created']
        after['modified']=_utc_stamp()
        if old_title!=new_title:
            self.conn.execute('DELETE FROM tiddlers WHERE title=?',(old_title,))
        self._store(after)
        ack=self._typing_gate(before,after,acknowledge)
        _append(self.conn,before=before,after=after,
                change_type='rename' if old_title!=new_title else 'edit',
                reason=self._reason(reason,ack))

    def rename_tiddler(self, old_title: str,new_title: str, reason: str | None=None,
                       acknowledge_contract_change: bool=False) -> bool:
        if self.readonly:raise PermissionError('Read-only database')
        if old_title==new_title:return self._get_raw(old_title) is not None
        before=self._get_raw(old_title)
        if before is None:return False
        return self.update_tiddler(old_title,new_title,before.get('text',''),
                                   parse_tags(before.get('tags',[])), reason=reason,
                                   acknowledge_contract_change=acknowledge_contract_change)

    def delete_tiddler(self,title: str,reason: str | None=None,
                       acknowledge_contract_change: bool=False) -> bool:
        if self.readonly:raise PermissionError('Read-only database')
        if not (reason or '').strip():raise ValueError('A reason is required to delete a post')
        with self.conn:
            before=self._get_raw(title)
            if before is None:return False
            if self.is_protected(title):raise PermissionError('Historical record is protected')
            self.conn.execute('DELETE FROM tiddlers WHERE title=?',(title,))
            ack=self._typing_gate(before,None,acknowledge_contract_change)
            _append(self.conn,before=before,after=None,change_type='delete',
                    reason=self._reason(reason,ack))
        return True

    def import_json(self,json_path: str,on_conflict: str='reject',
                    protect_imported: bool=False,reason: str | None=None,
                    acknowledge_contract_change: bool=False) -> int:
        if self.readonly:raise PermissionError('Read-only database')
        if on_conflict not in ('reject','overwrite'):raise ValueError('Unknown conflict policy')
        with open(json_path,'r',encoding='utf-8') as f:payload=json.load(f)
        return self.import_records(payload,on_conflict=on_conflict,protect_imported=protect_imported,
                                   reason=reason,acknowledge_contract_change=acknowledge_contract_change)

    def import_records(self,payload: list,on_conflict: str='reject',
                       protect_imported: bool=False,reason: str | None=None,
                       acknowledge_contract_change: bool=False,
                       first_version_reason: str | None=None) -> int:
        """Atomic batch import of TiddlyWiki records (all or nothing)."""
        if self.readonly:raise PermissionError('Read-only database')
        if on_conflict not in ('reject','overwrite'):raise ValueError('Unknown conflict policy')
        if not isinstance(payload,list):raise ValueError('Expected JSON array')
        seen=set()
        for obj in payload:
            _valid_record(obj)
            if obj['title'] in seen:raise ValueError('Duplicate source title '+obj['title'])
            seen.add(obj['title'])
        changed=0
        with self.conn:
            written=[]
            for obj in payload:
                before=self._get_raw(obj['title'])
                if before==obj:
                    if protect_imported:self._protect(obj)
                    continue
                if before is not None and self.is_protected(obj['title']):
                    raise PermissionError('Protected historical record '+repr(obj['title']))
                if before is not None and on_conflict=='reject':
                    raise ValueError('Import conflict for '+repr(obj['title'])+'; rolled back')
                if before is not None and not (reason or '').strip():
                    raise ValueError('A reason is required to overwrite imported posts')
                self._store(obj)
                written.append((before,obj))
            # Check contracts against the complete post-import state, so a
            # batch may carry its own contracts in any order.
            for before,obj in written:
                ack=self._typing_gate(before,obj,acknowledge_contract_change)
                _append(self.conn,before=before,after=obj,
                        change_type='import_overwrite' if before else 'first_version',
                        reason=self._reason(reason if before else
                                            (first_version_reason or
                                             'First version — imported from TiddlyWiki JSON'),ack))
                if protect_imported:self._protect(obj)
                changed+=1
        return changed

    # ------------------------------------------------------------------
    # Restore a recorded version
    # ------------------------------------------------------------------
    def restore_version(self, post_id: str, event_id: int, *, reason: str,
                        acknowledge_contract_change: bool=False) -> dict:
        """Write a recorded version back as the current post.

        Active post: a new edit/rename event whose after-state equals the
        chosen version. Deleted post: the history sequence of a deleted post
        is closed, so the version comes back as a NEW post (first_version)
        whose reason names the source post and event. Nothing is rewritten.
        """
        if self.readonly:raise PermissionError('Read-only database')
        if not (reason or '').strip(): raise ValueError('A reason is required to restore a version')
        post=self.conn.execute('SELECT post_id,current_title,deleted FROM hist.posts WHERE post_id=?',
                               (post_id,)).fetchone()
        if post is None: raise ValueError('Unknown post history')
        event=self.conn.execute('SELECT event_id,change_type,before_json,after_json FROM hist.events '
                                'WHERE post_id=? AND event_id=?',(post_id,event_id)).fetchone()
        if event is None: raise ValueError('That version does not belong to this post')
        snapshot_json = event['after_json'] or event['before_json']
        snapshot=json.loads(snapshot_json)
        which='after' if event['after_json'] else 'before (deleted state)'
        note=f'{reason.strip()} — restored from event {event_id} ({which}) of post {post_id}'
        if not post['deleted']:
            if self.is_protected(post['current_title']):
                raise PermissionError('Historical record is protected; it cannot be restored over')
            current=self._get_raw(post['current_title'])
            target=dict(snapshot)
            if current is not None and custom_fields(current)==custom_fields(target) and \
                    {k:current.get(k) for k in ('title','text','tags')}=={k:target.get(k) for k in ('title','text','tags')}:
                raise ValueError('The current post already matches that version')
            self.replace_tiddler(post['current_title'],target,reason=note,
                                 acknowledge_contract_change=acknowledge_contract_change)
            return {'title':target['title'],'mode':'edit','source_event':event_id}
        title=snapshot['title']
        with self.conn:
            if self._get_raw(title) is not None:
                raise ValueError(f'A post titled {title!r} already exists; rename it first')
            item=dict(snapshot); item['modified']=_utc_stamp()
            self._store(item)
            ack=self._typing_gate(None,item,acknowledge_contract_change)
            _append(self.conn,before=None,after=item,change_type='first_version',
                    reason=self._reason(note,ack))
        return {'title':title,'mode':'new_post','source_event':event_id}

    def write_batch(self, changes: list[dict], *, managed: bool = False) -> int:
        """Apply several complete-record writes in ONE transaction.

        Each change: {'title': current title or None for a new post,
        'record': the complete new record, 'reason': str, 'protect': bool,
        'link_prev': title whose current digest goes into log_prev_sha256},
        or {'title': t, 'protect_only': True} to protect an existing post.
        Every write passes the contract and ownership gates and gets a history
        event; ``managed=True`` is the PVS refresh's permission to touch PVS-owned
        parts. All or nothing.
        """
        if self.readonly: raise PermissionError('Read-only database')
        previous = getattr(self, '_managed_ok', False)
        self._managed_ok = previous or managed
        try:
            with self.conn:
                for change in changes:
                    if change.get('protect_only'):
                        raw = self._get_raw(change['title'])
                        if raw is None: raise ValueError(f"No post titled {change['title']!r}")
                        self._protect(raw)
                        continue
                    reason = change.get('reason') or ''
                    if not reason.strip(): raise ValueError('Every batch write needs a reason')
                    before = self._get_raw(change['title']) if change.get('title') else None
                    if change.get('title') and before is None:
                        raise ValueError(f"No post titled {change['title']!r}")
                    after = dict(change['record'])
                    if before is not None and self.is_protected(before['title']):
                        raise PermissionError('Historical record is protected: ' + before['title'])
                    if before is None and self._get_raw(after['title']) is not None:
                        raise ValueError(f"A post titled {after['title']!r} already exists")
                    if before is not None and before['title'] != after['title']:
                        if self._get_raw(after['title']) is not None:
                            raise ValueError('Destination title already exists')
                        self.conn.execute('DELETE FROM tiddlers WHERE title=?', (before['title'],))
                    if change.get('link_prev'):
                        # Digest of the previous entry exactly as stored now (its final state).
                        prev = self._get_raw(change['link_prev'])
                        if prev is None: raise ValueError(f"No post titled {change['link_prev']!r}")
                        after['log_prev_sha256'] = record_sha256(prev)
                    after.setdefault('created', (before or {}).get('created') or _utc_stamp())
                    after['modified'] = _utc_stamp()
                    self._store(after)
                    ack = self._typing_gate(before, after, False)
                    kind = 'first_version' if before is None else (
                        'rename' if before['title'] != after['title'] else 'edit')
                    _append(self.conn, before=before, after=after, change_type=kind,
                            reason=self._reason(reason, ack))
                    if change.get('protect'):
                        self._protect(after)
        finally:
            self._managed_ok = previous
        return len(changes)

    def events_since(self, event_id: int = 0) -> list[dict]:
        """History events after ``event_id``, oldest first, across all posts."""
        return [dict(row) for row in self.conn.execute(
            'SELECT event_id,post_id,changed_at,change_type,reason,old_title,title '
            'FROM hist.events WHERE event_id>? ORDER BY event_id', (event_id,))]

    def history_posts(self):
        return [dict(row) for row in self.conn.execute('SELECT post_id,last_title,deleted FROM hist.posts '
                                                    'ORDER BY last_title,post_id')]

    def post_history(self, post_id: str) -> list[dict]:
        return [dict(row) for row in self.conn.execute('SELECT event_id,changed_at,change_type,reason,'
                     'old_title,title,before_json,before_sha256,after_json,after_sha256 '
                     'FROM hist.events WHERE post_id=? ORDER BY event_id', (post_id,))]

    def snapshot_pair(self,path: str) -> dict:
        """Publish a verified, no-overwrite backup of the matching SQLite pair.

        Verify under an immediate SQLite writer lock before copying. Reopen and
        independently verify the staged pair before publishing either file.
        This is not an alternative to an external/offline backup.
        """
        if self.readonly: raise PermissionError('Read-only database')
        dest=Path(path); other=history_path(str(dest))
        if dest.resolve() == Path(self.db_path).resolve() or other.resolve() == self.history_file.resolve():
            raise ValueError('Choose a different backup filename')
        if dest.exists() or dest.is_symlink() or other.exists() or other.is_symlink():
            raise FileExistsError('One of the backup filenames already exists')
        if not dest.parent.is_dir(): raise FileNotFoundError('Backup folder does not exist')
        made=[]
        with tempfile.TemporaryDirectory(prefix='.pw_pair_backup_',dir=dest.parent) as work:
            # Naming the staged files as a normal pair permits exactly the same
            # read-only verification used for any ordinary wiki folder.
            main_tmp=Path(work)/'pair.db'
            hist_tmp=history_path(str(main_tmp))
            self.conn.execute('BEGIN IMMEDIATE')
            try:
                # Reject an externally modified content file rather than
                # certifying a pair whose history no longer matches its posts.
                self.verify_history()
                for original,staged in [(self.db_path,main_tmp),(str(self.history_file),hist_tmp)]:
                    uri=Path(original).resolve().as_uri()+'?mode=ro'
                    with closing(sqlite3.connect(uri,uri=True,timeout=15)) as source:
                        with closing(sqlite3.connect(str(staged))) as copy:
                            source.backup(copy,pages=256,sleep=.01)
                    if os.name=='posix': os.chmod(staged,0o600)
                # A pair of individually sound databases can still disagree.
                # Validate their relationship before making either visible.
                with HistoryTiddlerDB(str(main_tmp),readonly=True) as checked:
                    integrity=checked.integrity_report()
                    if (integrity['integrity']!='ok' or
                            integrity['foreign_key_violations'] or
                            not integrity['fts_matches']):
                        raise HistoryError('Backup content integrity failed')
                    protection=checked.protection_report()
                    if protection['violation_count']:
                        raise HistoryError('Backup protected-record audit failed')
                    checked.verify_history()
                content_hash=hashlib.sha256(main_tmp.read_bytes()).hexdigest()
                history_hash=hashlib.sha256(hist_tmp.read_bytes()).hexdigest()
                for staged,out in [(main_tmp,dest),(hist_tmp,other)]:
                    # Track identity before attempting publication, because
                    # _publish_temp can link successfully and then fail fsync.
                    identity = staged.stat()
                    made.append((out, identity.st_dev, identity.st_ino))
                    _publish_temp(str(staged),out,overwrite=False)
            except BaseException:
                for out,device,inode in reversed(made):
                    try:
                        published = out.stat(follow_symlinks=False)
                        if (published.st_dev,published.st_ino)==(device,inode):
                            out.unlink()
                    except FileNotFoundError:
                        pass
                raise
            finally:
                self.conn.rollback()
        return {'content':str(dest),'history':str(other),
                'content_sha256':content_hash,'history_sha256':history_hash}
