"""Dialogs: post editor (text, fields, Toulmin argument), project item and template choosers."""
import json
from html import escape

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox, QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout, QHeaderView, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QPlainTextEdit, QSplitter,
    QTableWidget, QTableWidgetItem, QToolButton, QVBoxLayout, QWidget,
)

from wiki_core import WikiCore
from projects import KINDS as PROJECT_KINDS, STATUSES as PROJECT_STATUSES, PRIORITIES as PROJECT_PRIORITIES
from forms import TOULMIN as TOULMIN_FIELDS, TOULMIN_REQUIRED

RESERVED_FIELDS = frozenset({"title", "text", "tags", "created", "modified"})
TOULMIN_HINTS = (("claim", "What do you conclude?"), ("grounds", "What facts or evidence support it?"),
                 ("warrant", "Why do those grounds support the claim?"),
                 ("backing", "What supports the warrant? (optional)"),
                 ("qualifier", "How sure? e.g. provisional, likely, certain"),
                 ("rebuttal", "When would the claim not hold? (optional)"))


def _field_display(value) -> str:
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)


class TiddlerEditor(QDialog):
    """Dialog for creating/editing posts, including typed custom fields."""

    def __init__(self, parent=None, tiddler: dict = None, *, core: WikiCore | None = None,
                 preset: dict | None = None):
        super().__init__(parent)
        self.core = core
        self.original_title = tiddler.get("title", "") if tiddler else ""
        self.original_fields = dict((tiddler or {}).get("fields") or {})
        # On a PVS-managed post, PVS owns parent and pvs_*: keep them out of the
        # table and pass them through unchanged (only a refresh may change them).
        managed = bool(tiddler) and "pvs" in (tiddler.get("tags") or []) and "pvs_object" in self.original_fields
        self.pvs_owned = {k: v for k, v in self.original_fields.items()
                          if managed and (k.startswith("pvs_") or k == "parent")}
        self.setWindowTitle("Edit Post" if tiddler else "New Post")
        self.setMinimumSize(760, 620)
        self._setup_ui(tiddler, preset or {})

    def _setup_ui(self, tiddler: dict = None, preset: dict | None = None):
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Post title")
        if tiddler:
            self.title_edit.setText(tiddler.get("title", ""))
        elif preset.get("title"):
            self.title_edit.setText(preset["title"])
        form.addRow("Title:", self.title_edit)
        self.tags_edit = QLineEdit()
        self.tags_edit.setPlaceholderText("tag1 [[tag with spaces]] tag2")
        tags = tiddler.get("tags") if tiddler else preset.get("tags")
        if tags:
            self.tags_edit.setText(self._tags_to_string(tags))
        form.addRow("Tags:", self.tags_edit)
        layout.addLayout(form)

        splitter = QSplitter(Qt.Vertical)
        text_box = QWidget(); text_layout = QVBoxLayout(text_box); text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.addWidget(QLabel("Content:"))
        self.text_edit = QPlainTextEdit()
        self.text_edit.setPlaceholderText("Enter TiddlyWiki markup here...")
        self.text_edit.setStyleSheet("QPlainTextEdit { font-family: 'SF Mono', Monaco, 'Courier New', monospace; font-size: 13px; }")
        if tiddler:
            self.text_edit.setPlainText(tiddler.get("text", ""))
        elif preset.get("text"):
            self.text_edit.setPlainText(preset["text"])
        text_layout.addWidget(self.text_edit)
        splitter.addWidget(text_box)

        fields_box = QWidget(); fields_layout = QVBoxLayout(fields_box); fields_layout.setContentsMargins(0, 0, 0, 0)
        head = QHBoxLayout()
        head.addWidget(QLabel("Fields:"))
        head.addStretch(1)
        add_btn = QToolButton(); add_btn.setText("+ Field"); add_btn.clicked.connect(lambda: self._add_field_row("", ""))
        del_btn = QToolButton(); del_btn.setText("− Remove"); del_btn.clicked.connect(self._remove_field_row)
        head.addWidget(add_btn); head.addWidget(del_btn)
        fields_layout.addLayout(head)
        self.fields_table = QTableWidget(0, 2)
        self.fields_table.setHorizontalHeaderLabels(["Field", "Value"])
        self.fields_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.fields_table.verticalHeader().setVisible(False)
        fields_layout.addWidget(self.fields_table)
        self.contract_label = QLabel()
        self.contract_label.setWordWrap(True)
        self.contract_label.setTextFormat(Qt.RichText)
        fields_layout.addWidget(self.contract_label)
        splitter.addWidget(fields_box)

        # Toulmin argument: multi-line boxes instead of single-line table cells.
        self.argument_box = QWidget()
        arg_form = QFormLayout(self.argument_box)
        arg_form.setContentsMargins(0, 4, 0, 0)
        self.argument_edits = {}
        for name, hint in TOULMIN_HINTS:
            if name in ("claim", "qualifier"):
                edit = QLineEdit()
                edit.setPlaceholderText(hint)
            else:
                edit = QPlainTextEdit()
                edit.setPlaceholderText(hint)
                edit.setFixedHeight(46)
            self.argument_edits[name] = edit
            arg_form.addRow(name.capitalize() + (" *" if name in TOULMIN_REQUIRED else "") + ":", edit)
        splitter.addWidget(self.argument_box)
        splitter.setSizes([260, 170, 250])
        layout.addWidget(splitter, stretch=1)

        initial = ({k: v for k, v in self.original_fields.items() if k not in self.pvs_owned}
                   if tiddler else dict(preset.get("fields") or {}))
        if self.pvs_owned:
            note = QLabel(f"{len(self.pvs_owned)} PVS field(s) are managed by Refresh from PVS and hidden "
                          "here. Text, tags and status are yours.")
            note.setStyleSheet("color:#3949ab")
            note.setWordWrap(True)
            layout.insertWidget(1, note)
        for name, edit in self.argument_edits.items():
            value = initial.pop(name, None)
            if value is not None:
                text = _field_display(value)
                edit.setText(text) if isinstance(edit, QLineEdit) else edit.setPlainText(text)
        self._has_argument = any(n in (tiddler or {}).get("fields", {}) for n in TOULMIN_FIELDS)
        for name in initial:
            self._add_field_row(name, _field_display(initial[name]))
        self.tags_edit.textChanged.connect(self._refresh_contract)
        self._refresh_contract()

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._on_save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        if tiddler:
            self.text_edit.setFocus()
        else:
            self.title_edit.setFocus()

    def _add_field_row(self, name: str, value: str):
        row = self.fields_table.rowCount()
        self.fields_table.insertRow(row)
        self.fields_table.setItem(row, 0, QTableWidgetItem(name))
        self.fields_table.setItem(row, 1, QTableWidgetItem(value))

    def _remove_field_row(self):
        row = self.fields_table.currentRow()
        if row >= 0:
            self.fields_table.removeRow(row)

    def _field_names(self) -> set[str]:
        names = set()
        for r in range(self.fields_table.rowCount()):
            item = self.fields_table.item(r, 0)
            if item and item.text().strip():
                names.add(item.text().strip())
        return names

    def _refresh_contract(self):
        if self.core is None:
            self.contract_label.setText("")
            self.argument_box.setVisible(self._has_argument)
            return
        try:
            hints = self.core.contract_hints(self._parse_tags(self.tags_edit.text()))
        except Exception as exc:
            self.contract_label.setText(f"<span style='color:#b71c1c'>{escape(str(exc))}</span>")
            return
        if not hints:
            self.contract_label.setText("<span style='color:#888'>No field contract for these tags.</span>")
            self.argument_box.setVisible(self._has_argument)
            return
        present = self._field_names()
        wants_argument = self._has_argument or any(
            row[0] in TOULMIN_FIELDS for hint in hints for row in hint["rows"])
        self.argument_box.setVisible(wants_argument)
        parts = []
        for hint in hints:
            bits = []
            for name, allowed, required in hint["rows"]:
                if name in TOULMIN_FIELDS:
                    continue  # edited in the Argument section
                if required and name not in present:
                    self._add_field_row(name, "")
                    present.add(name)
                bits.append(f"<b>{escape(name)}</b>{'*' if required else ''}: {escape(allowed)}")
            closed = " · no other fields" if hint["closed"] else ""
            parts.append(f"Contract <i>{escape(hint['tag'])}</i> — " + "; ".join(bits) + closed)
        self.contract_label.setText("<br>".join(parts) + "<br><span style='color:#888'>* required</span>")

    def _tags_to_string(self, tags: list[str]) -> str:
        """Convert tag list to TW tag string format."""
        parts = []
        for tag in tags:
            if " " in tag:
                parts.append(f"[[{tag}]]")
            else:
                parts.append(tag)
        return " ".join(parts)

    def _parse_tags(self, tags_str: str) -> list[str]:
        """Parse TW tag string to list."""
        tags = []
        i = 0
        while i < len(tags_str):
            if tags_str[i : i + 2] == "[[":
                end = tags_str.find("]]", i + 2)
                if end != -1:
                    tags.append(tags_str[i + 2 : end])
                    i = end + 2
                else:
                    i += 2
            elif tags_str[i].isspace():
                i += 1
            else:
                end = i
                while end < len(tags_str) and not tags_str[end].isspace():
                    end += 1
                tag = tags_str[i:end].strip()
                if tag:
                    tags.append(tag)
                i = end
        return tags

    def _fields(self) -> dict:
        result = {}
        for r in range(self.fields_table.rowCount()):
            k_item, v_item = self.fields_table.item(r, 0), self.fields_table.item(r, 1)
            name = k_item.text().strip() if k_item else ""
            value = v_item.text() if v_item else ""
            if not name:
                continue
            if name in result:
                raise ValueError(f"Field {name!r} appears twice")
            if name in RESERVED_FIELDS:
                raise ValueError(f"{name!r} is a built-in field; use the title, tags or content boxes")
            if value == "" and name not in self.original_fields:
                continue  # an untouched placeholder row
            original = self.original_fields.get(name)
            # Keep non-string imported values unless the user changed their text.
            result[name] = original if (original is not None and value == _field_display(original)) else value
        for name in self.pvs_owned:
            if name in result:
                raise ValueError(f"{name!r} belongs to PVS on this post; change it in PVS and refresh")
        result.update(self.pvs_owned)
        for name, edit in self.argument_edits.items():
            if name in result:
                raise ValueError(f"{name!r} belongs in the Argument section, not the Fields table")
            text = (edit.text() if isinstance(edit, QLineEdit) else edit.toPlainText()).strip()
            original = self.original_fields.get(name)
            if text:
                result[name] = original if (original is not None and text == _field_display(original).strip()) else text
        return result

    def _on_save(self):
        title = self.title_edit.text().strip()
        if not title:
            QMessageBox.warning(self, "Missing Title", "Please enter a title.")
            self.title_edit.setFocus()
            return
        try:
            self._fields()
        except ValueError as exc:
            QMessageBox.warning(self, "Fields", str(exc))
            return
        self.accept()

    def get_tiddler_data(self) -> dict:
        """Return the edited post data."""
        return {
            "original_title": self.original_title,
            "title": self.title_edit.text().strip(),
            "text": self.text_edit.toPlainText(),
            "tags": self._parse_tags(self.tags_edit.text()),
            "fields": self._fields(),
        }


class ProjectItemDialog(QDialog):
    """Choose the kind, title, parent and first fields of a project item."""

    def __init__(self, parent, core: WikiCore, suggested_parent: str | None):
        super().__init__(parent)
        self.setWindowTitle("New Project Item")
        self.setMinimumWidth(460)
        form = QFormLayout(self)
        self.kind = QComboBox(); self.kind.addItems(list(PROJECT_KINDS))
        self.title = QLineEdit(); self.title.setPlaceholderText("What is it?")
        self.parent_box = QComboBox(); self.parent_box.setEditable(True)
        self.parent_box.addItem("")
        self._items = core.project_overview()["items"]
        for t, it in sorted(self._items.items(), key=lambda kv: (PROJECT_KINDS.index(kv[1]["kind"]), kv[0].lower())):
            if it["kind"] != "task":
                self.parent_box.addItem(t)
        self.status = QComboBox(); self.status.addItems(list(PROJECT_STATUSES))
        self.due = QLineEdit(); self.due.setPlaceholderText("YYYY-MM-DD (optional)")
        self.priority = QComboBox(); self.priority.addItems([""] + list(PROJECT_PRIORITIES))
        form.addRow("Kind:", self.kind); form.addRow("Title:", self.title)
        form.addRow("Parent:", self.parent_box); form.addRow("Status:", self.status)
        form.addRow("Due:", self.due); form.addRow("Priority:", self.priority)
        if suggested_parent and suggested_parent in self._items:
            self.parent_box.setCurrentText(suggested_parent)
            nxt = {"project": "goal", "goal": "milestone", "milestone": "task", "task": "task"}
            self.kind.setCurrentText(nxt[self._items[suggested_parent]["kind"]])
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._ok); buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def _ok(self):
        if not self.title.text().strip():
            QMessageBox.warning(self, "Missing Title", "Please enter a title.")
            return
        self.accept()

    def preset(self) -> dict:
        fields = {"status": self.status.currentText()}
        if self.parent_box.currentText().strip():
            fields["parent"] = self.parent_box.currentText().strip()
        if self.due.text().strip():
            fields["due"] = self.due.text().strip()
        if self.priority.currentText():
            fields["priority"] = self.priority.currentText()
        return {"title": self.title.text().strip(), "tags": [self.kind.currentText()], "fields": fields}


class TemplateDialog(QDialog):
    """Pick a form template and (optionally) the project it documents."""

    def __init__(self, parent, core: WikiCore, current: str | None):
        super().__init__(parent)
        self.setWindowTitle("New from Template")
        self.setMinimumSize(560, 420)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Form:"))
        self.templates = core.list_templates()
        self.list = QListWidget()
        for t in self.templates:
            item = QListWidgetItem(t["name"])
            item.setToolTip(t["description"])
            self.list.addItem(item)
        layout.addWidget(self.list, stretch=1)
        self.description = QLabel()
        self.description.setWordWrap(True)
        self.description.setStyleSheet("color:#555")
        layout.addWidget(self.description)
        form = QFormLayout()
        self.project = QComboBox()
        self.project.setEditable(True)
        self.project.addItem("")
        items = core.project_overview()["items"]
        for title, it in sorted(items.items(), key=lambda kv: (PROJECT_KINDS.index(kv[1]["kind"]), kv[0].lower())):
            if it["kind"] != "task":
                self.project.addItem(title)
        if current and current in items:
            self.project.setCurrentText(current)
        form.addRow("Project (optional):", self.project)
        layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._ok)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.list.currentRowChanged.connect(self._describe)
        self.list.itemDoubleClicked.connect(lambda _: self._ok())
        if self.templates:
            self.list.setCurrentRow(0)

    def _describe(self, row: int):
        if 0 <= row < len(self.templates):
            self.description.setText(self.templates[row]["description"])

    def _ok(self):
        if self.list.currentRow() < 0:
            return
        self.accept()

    def choice(self) -> tuple[str, str | None]:
        return (self.templates[self.list.currentRow()]["title"],
                self.project.currentText().strip() or None)
